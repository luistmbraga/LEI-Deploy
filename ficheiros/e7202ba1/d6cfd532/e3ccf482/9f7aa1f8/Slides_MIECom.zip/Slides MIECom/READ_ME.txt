Investiga��o Operacional  
Aula1.pdf (1,429 MB) 
Slides para a Apresenta��o da Investiga��o Operacional
V�deo recomendado:
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/1 (primeiros 8 minutos)



Modelos de Programa��o Linear  
Aula2.pdf (1,748 MB) 
Slides de Modelos de Programa��o Linear
Videos recomendados:
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/1
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/2 (primeiros 28 minutos)


M�todos de Programa��o Linear
Aula3.pdf (798,288 KB) 
Slides sobre M�todos de Programa��o Linear: Gr�fica
Video recomendado:
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/3



M�todos de Programa��o Linear  
Aula4.pdf (576,768 KB) 
Slides sobre M�todos de Programa��o Linear: Simplex
Video recomendado:
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/4


Simplex Dual, Revisto e Matricial 
Aula5.pdf (578,934 KB) 
Slides de M�todos de Programa��o Linear: Simplex Dual, Revisto e Matricial
Video recomendado:
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/10 (depois do minuto 20)
http://freevideolectures.com/Course/2365/Fundamentals-of-Operations-Research/11