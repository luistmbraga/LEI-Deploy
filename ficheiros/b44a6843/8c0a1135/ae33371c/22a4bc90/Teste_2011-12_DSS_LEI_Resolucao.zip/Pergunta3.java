public class Whiteboard {
	
	private String nome;
	private static boolean created;
	private List<Docente> docentes;
	private List<Aluno> alunos;
	private Map<String,UC> ucs;
	
	public int notaTPAluno(String cod_aluno, String uc);
	public int notaTAluno(String ca, String uc);
}
