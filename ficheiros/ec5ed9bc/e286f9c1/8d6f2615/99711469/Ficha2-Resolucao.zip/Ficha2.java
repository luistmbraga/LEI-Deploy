
/**
 * Write a description of class Ficha2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
import static java.lang.Math.pow;
import static java.lang.System.out;

public class Ficha2
{
    private int x;
  
    public static int calcPos(int[] l, int x)
    {
        int i,res=0;
        for(i=0;i<l.length;i++)
        {
            if(x<=l[i]) res=i;
            else i++;
        }
        return res;
    }
    
    public static int[] insere(int[] l, int x, int a)
    {
        int i;
        
        for(i=a;i<l.length;i++)
        {
            l[i+1]=l[i];
        }
        l[i]=x;
        return l;
    }
    
    public static int[] ordInsert(int n)
    {
        int i;
        int[] lista= new int[n];
        out.println("Insere");
        for(i=0;i<n;i++)
        { 
        Scanner input= new Scanner(System.in);
        int elem = input.nextInt();
        input.close();
        int ind= calcPos(lista,elem);
        lista = insere(lista,elem,ind);
        }  
      
       return lista;
    }
    
    
    
}
