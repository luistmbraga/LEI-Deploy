PROGRAMAS TEXAS
4� MINI-TESTE T�PICOS F�SICA MODERNA

-------------------------------
INSTALAR:
-------------------------------

Para poderem p�r estes programas precisam de uma m�quina TEXAS, cabo de conex�o ao pc, e o TI Connect. Podem fazer download do TI CONNECT aqui: http://education.ti.com/pt/portugal/software/details/en/14D11109C9F44D55B9BBF65E5A62E7F1/swticonnectsoftwareforwindows
Se me conseguirem apanhar durante as aulas, tamb�m vos posso meter os programas directamente na vossa m�quina a partir da minha (tenho cabo).
Fiz os programas numa TI 84-PLUS, mas em princ�pio devem funcionar todos nas mais antigas. Nas TI-NSPIRE tanto quanto sei, n�o funcionam, sorry.

Aos amigos que t�m m�quinas CASIO, apenas posso recomendar que comprem uma m�quina como deve ser xD

-------------------------------
IMPORTANTE - ANTES DE USAR:
-------------------------------

- Estes programas usam, e mudam os valores de algumas vari�veis da m�quina. Se tiverem colocado um valor numa vari�vel qualquer e est�o habituados a usar essa vari�vel a fazer contas, tenham cuidado redrobrado e verifiquem se depois de usar o programa o valor da vari�vel se mantem o mesmo, i.e, se o programa a usou ou n�o. Para facilitar, neste mesmo documento indico as vari�veis que cada programa usa e o que faz com elas, para que tenham essa informa��o antes de instalar/usar os programas.
- Os programas n�o est�o protegidos, ou seja, s�o livres de os alterar de modo a ir mais de encontro ao que pessoalmente preferem. No menu dos programas, no separador EDIT podem escolher o programa a editar. Isto permite ver o c�digo de cada programa e o que ele faz.
- Usem o programas antes de os usarem num teste ou em algo importante. Tentem resolver exerc�cios j� resolvidos com eles. Isto ajuda a familizariar com o uso do programa e a saber as potencialidades e limita��es de cada um.

DICA: Os programas al�m de mostrarem resultados no ecr�, tamb�m guardam o(s) resultado(s) nas vari�veis A,B,C,D...Z da m�quina. Se souberem a vari�vel que est� associada a um determinado resultado (indico neste documento as vari�veis), podem depois usar a vari�vel fora do programa nas expess�es. 
EXEMPLO: O programa CNEGRO recebe uma temperatura de um corpo negro e um dos resultados que devolve � a frequ�ncia da radia��o emitida por esse corpo. O programa mostra a frequ�ncia no ecr� mas ao mesmo tempo guarda esse resultado na vari�vel F. Depois de sairem do programa, essa vari�vel pode ser usada em qualquer express�o. Supondo que fora do programa, querem o dobro da frequ�ncia que o programa vos deu. Basta escrever 2F -> ENTER e a m�quina devolve o dobro da frequ�ncia.

Os programas foram feitos por mim, n�o s� como forma de estudo, mas tamb�m como forma de ajudar a resolver os exerc�cios mais rapidamente. Como os testes s�o de escolha m�ltipla e n�o obrigam a apresenta��o de todos os c�lculos, usar estes programas para fazer os c�lculos por n�s � altamente vantajoso, porque temos os resultados quase imediatamente s� com os dados do problema. 

Qualquer quest�o ou sujest�o que tenham � sempre bem-vinda:)

-------------------------------
PROGRAMAS
-------------------------------

===ENERGLIG===
Calcula a energia de liga��o de um is�topo ou dada a energia de liga��o, calcula a massa at�mica.


INPUTS:
- Caso no menu se escolha a primeira op��o "E.LIG->MASSA", � pedida a energia de liga��o, que deve ser dada em MeV. � guardado na vari�vel E.
- Caso no menu se escolha a primeira op��o "MASSA->E.LIG", � pedida a massa do is�topo, que deve ser dada em u, unidades de massa at�mica. � guardado na vari�vel M.
Em ambas as op��es � tamb�m pedido o valor de A (n� de massa) e Z (n� de prot�es) do is�topo.

OUTPUTS:
- Caso no menu se escolha a primeira op��o "E.LIG->MASSA", � dada a massa do is�topo, em u, unidades de massa at�mica. � guardado na vari�vel E.
- Caso no menu se escolha a primeira op��o "MASSA->E.LIG", � dada a energia de liga��o, em MeV. � guardado na vari�vel E.

Exerc�cios da ficha que podem ser resolvidos com este programa:
- Ex. 93 - directamente, escolhendo a 2� op��o.
- Ex. 94 b) - quase directamente, escolhendo a 1� op��o. Com o  programa consegue-se calcular a energia do is�topo. Para calcular a energia do nucle�o, deve-se dividir essa energia por 238. NOTA: Este � um caso em que usar as variveis do programa d� jeito. Correndo o programa e dando os valores ele devolve a massa e guarda na vari�vel M. Fora do programa podem simplesmente escrever a express�o M/298 e t�m a solu��o do exerc�cio.
- Ex. 95 - quase directamente, com a 2� op��o. O programa permite calcular a energia que � necess�rio fornecer para decompor 1 nucle�tido. Depois � s� multiplicar este valor pelo n� de n�cleos (aqui tamb�m podem tirar partido da vari�vel E).


===ENERGDES===
Programa que calcula a energia libertada numa desintegra��o radioactiva alfa (beta- e beta+ ainda a ser feito).

INPUTS: 
Massa dos is�topos envolvidos na desintegra��o. Fornecer o valor da massa em u, unidades de massa at�mica. Os valores s�o guardados nas vari�veis X e Y.

OUTPUT: 
- Energia libertada na desintegra��o, em MeV, guardada na vari�vel E.
- O programa devolve ainda o valor de E em uc^2 e J. Estes dois valores contudo, n�o s�o guardados em nenhuma vari�vel.

Exerc�cios da ficha que podem ser resolvidos com este programa:
- Ex. 94 a) - directamente

Exerc�cios do teste de 2012 que podem ser resolvidos com este programa:
- Ex c-2) - directamente


===IDADE===
***
AVISO: O programa DECAIMENT � uma vers�o mais evolu�da deste. Faz o mesmo que este programa e muito mais. Considerem sacar o programa DECAIMENT em vez deste.
***

Calcula a idade de um is�topo radioactivo.

INPUTS:
- Caso no menu se escolha a 1� op��o "K" � perguntado o k, que � dado em T^(-1), em que T representa uma unidade de tempo, geralmente a que mais for conviniente para o exerc�cio. Guarda na viar�vel k.
- Caso no menu se escolha a 2� op��o "T 1/2VIDA" � perguntado o tempo de meia vida, que deve ser dada numa unidade de tempo, geralmente a que mais for conviniente para o exerc�cio. Guarda na vari�vel T.
Em ambas as op��es � tamb�m perguntado o A/Ao ou N/No, guardados nas vari�veis P e O. De notar que a f�rmula para a actividade � igual � f�rmula para o n� de is�topos, por isso pode-se usar um ou outro. Claro que se subentende que se no valor perguntado em "A/N?", derem um valor corresponde a uma actividade (A), na pergunta seguinte "A0/N0?" o valor dado deve corresponder a A0. Aten��o para n�o se dar um valor que corresponde a A na primeira pergunta e depois na segunda se dar um valor correspondente a N0, ou vice-versa. Nesse caso o valor que o programa der n�o vai ter sentido.

OUTPUTS:
- Em ambas as op��es o programa devolve o valor corresponde ao tempo/idade de um is�topo, nas mesmas unidades de tempo que as dadas nos inputs.
Adicionalmente, caso se escolha a 2� op��o, � ainda devolvido o valor de k.

Exerc�cios da ficha que podem ser resolvidos com este programa:
- Ex. 96 a) - directamente, com a 2� op��o.
- Ex. 97 - directamente, com a 2� op��o.
- Ex. 98 - quase directamente, com a 2� op��o. O programa d� logo o valor pedido, desde que antes se tenha o cuidado de passar ao programa os valores j� todos em dias.
- Ex. 111 a) - quase directamente, com a 2� op��o. Antes de usar o programa, � preciso calcular o n� de n�cleos inicial e final (N e N0). Quando se tiver esses valores, pode-se usar o programa que d� logo o valor pedido.


===SIEVERT===
Calcula a dose equivalente de uma exposi��o a radia��o, em Sievert's.

INPUTS:
- Energia de uma part�cula radioactiva (em MeV), guardada na vari�vel E.
- N� de part�culas, guardada em X.
- N� de exposi��es, gaurdada em Y. ("Quantos exames foram feitos?"\"Quantas vezes a pessoa foi exposta?")
- Factor de Qualidade, guardada em Q.
- Peso, da mat�ria irradiada, geralmente uma pessoa, deve ser dada em Kg. Guardada na vari�vel P.

OUTPUTS:
- Dose absorvida, em Gray (J/Kg), guardada na vari�vel D.
- Dose equivalente, em Sievert's (J/kg), guardada na vari�vel S.

Exerc�cios da ficha que podem ser resolvidos com este programa:
- Ex. 101 - directamente.
- Ex. 102 - directamente.

Exerc�cios do teste de 2012 que podem ser resolvidos com este programa:
- Ex Q4 b) - directamente

===DECAIMENT===
Este programa � uma evolu��o do programa IDADE.

Este programa tem muitas op��es, explic�-las todas seria demasiado extensivo e redundante.
Algumas linhas gerais para trabalhar com este programa:

- Nos menus, sempre que aparecer um teta, significa "tempo de meia vida" e T significa tempo (� o t das f�rmulas).

- Os inputs e outputs de cada uma das op��es est�o indicados na pr�pria op��o. Por exemplo, a op��o "K,A,A0->T" vai pedir o valor de K, A e A0 e vai devolver o tempo.

- Em alguns pedidos de input vai aparecer algo como "A (ou N)?". Significa que o valor que v�o dar pode ser do A ou do N. No entanto tenham cuidado em ser coerentes! Se na execu��o de uma das op��es vos pede "A (ou N)?", voc�s d�o um valor que corresponde a A, e logo a seguir o programa pedir "A0 (ou N0)?", o valor que d�o neste segundo pedido tem que corresponder ao valor e A0 e nunca de N0. O valor a dar no segundo pedido s� seria de N0, se no primeiro pedido de input tivessem dado um valor de N. Esta l�gica aplica-se tamb�m aos outputs. Se um programa vos pede "A (ou N)?", voc�s d�o um valor correspondente ao N e um dos outputs for "A (ou N0)", devem ler este valor como um valor para N0, porque deram um valor de N no pedido de output.

- Sejam coerentes tamb�m nas unidades que passam ao programa. Por exemplo, na op��o "K,A,A0->T" se passarem um valor para k em segundos^(-1), os valores para A e A0 devem estar em desintegra�oes/segundo e neste caso em particular o output para o tempo dever� tamb�m ser lido em segundos. De notar que podem tamb�m usar express�es nos pedidos de input. Ou seja, se o enunciado vos der por exemplo k = 300 segs^(-1) e A e A0 em desintegra�oes/minuto, para passar o k para minutos^(-1) s� precisam de multiplicar 60*300. Quando vos for pedido o valor de K, podem escrever mesmo a expressao 60*300 em vez de um valor directo, o programa aceita.

PROTIP: Em muitas op��es, o programa assume que se sabe o tempo 1/2vida e n�o se sabe o k. Se n�o for este o caso, e souberem o valor de k e n�o o tempo de 1/2vida, podem usar na mesma a op��o que vos pede o tempo 1/2vida e quando vos for pedido o valor de teta (1/2vida) coloquem a express�o ln(2)/k, substituindo o k pelo valor do enunciado.  


Exerc�cios da ficha que podem ser resolvidos com este programa:
- Os mesmos do programa IDADE.
- Todos os outros em que as f�rmulas A=kN, N=N0*e^(-kt) e A=A0*e^(-kt) sejam importantes para a resolu��o do exerc�cio.

Exerc�cios do teste de 2012 que podem ser resolvidos com este programa:
- Q3 a), Q3 b), Q3 c)