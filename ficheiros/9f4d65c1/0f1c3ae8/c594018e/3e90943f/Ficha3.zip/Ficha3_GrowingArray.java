
/**
 * Classe que implementa um array que cresce à medida das necessidades.
 * Deverá ser utilizada sempre que for necessário ter uma estrutura ordenada
 * para guardar objectos.
 * 
 * Na versão inicial, vamos utilizar objectos da classe Viatura
 * 
 * @author (anr) 
 * @version (2014.03.21)
 */
import java.util.Arrays;

public class GrowingArray {
    
  private Viatura[] elementos;
  private int size;
  
  /**
   * variável que determina o tamanho inicial do array, 
   * se for utilizado o construtor vazio.
   */
  private static final int capacidade_inicial = 20;
    
  public GrowingArray(int capacidade) {
    this.elementos = new Viatura[capacidade];
    this.size = 0;
  }  
  
  public GrowingArray() {
    this(capacidade_inicial);
  }  
  
  public GrowingArray(GrowingArray ga) {
  }
  /**
   * Devolve o elemento que está na posição indicada.
   *
   * @param  indice posição do elemento a devolver
   * @return o objecto que está na posição indicada no parâmetro
   * (deveremos ter atenção às situações em que a posição não existe)
   */
  
  public Viatura get(int indice) {
  }
  
  /**
   * Método que actualiza o valor de uma determinada posição do array.
   * Não deve permitir espaços vazios!
   * 
   * @param indice a posição que se pretende actualizar
   * @param c o Viatura que se pretende colocar na estrutura de dados
   * 
   */
  
  public void set(int indice, Viatura c) {
  }    
  
  
  /**
   * Adiciona o elemento passado como parâmetro ao fim do array
   *
   * @param c Viatura que é adicionado ao array
   * 
   */
    
  public void add(Viatura c) {
  }

  
  /**
   * Método auxiliar que verifica se o array alocado tem capacidade
   * para guardar mais elementos.
   * Por cada nova inserção, verifica se estamos a mais de metade 
   * do espaço 
   * alocado e,caso se verifique, aloca mais 1.5 de capacidade.
   * 
   */ 
  
  private void aumentaCapacidade(int capacidade) {
  }     
  
    
  /**
   * Método que adiciona um elemento numa determinada posição, 
   * forçando a
   * que os elementos à direita no array façam shift.
   * Tal como no método de set não são permitidos espaços. 
   * 
   * @param indice indice onde se insere o elemento
   * @param c Viatura que será inserido no array
   * 
   */
  
  public void add(int indice, Viatura c) {
  }
  
  
  /**
   * Remove do array o elemento que está na posição indicada no parâmetro.
   * Todos os elementos à direita do índice sofrem um deslocamento 
   * para a esquerda.
   * @param indice índice do elemento a ser removido
   * @return o elemento que é removido do array. No caso do índice não
   * existir devolver-se-á null.
   */    
  public Viatura remove(int indice) {
  }

  
   /**
    * Remove a primeira ocorrência do elemento que é passado como parâmetro.
    * Devolve true caso o array contenha o elemento, falso caso contrário.
    * 
    * @param c círculo a ser removido do array (caso exista)
    * @return true, caso o círculo exista no array 
   */
   public boolean remove(Viatura c) {
   }
   
   /**
    * Método que determina o tamanho do array de elementos.
    * 
    * @return o número de elementos contantes no array.
    * 
    */
   public int size() {
   }
   
   
   /** 
    * Método que determina o índice do array onde está localizada a 
    * primeira ocorrência de um objecto.
    * 
    * @param c círculo de que se pretende determinar a posição
    * @return a posição onde o círculo se encontra. -1 caso não esteja no
    * array ou o círculo passado como parâmetro seja null.
    */
   
   public int indexOf(Viatura c) {
   }
  
   
   /**
    * Método que determina se um elemento está no array.
    * 
    * @param c círculo a determinar se está no array
    * @return true se o objecto estiver inserido na estrutura de dados,
    * false caso contrário.
    */

   public boolean contains(Viatura c) {
   }
   
   
   /**
    * Método que determina se o array contém elementos, ou se está vazio.
    * 
    * @return true se o array estiver vazio, false caso contrário.
    */
   
   public boolean isEmpty() {

   }
}



    
    

    
    