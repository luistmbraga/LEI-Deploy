-- Universidade do Minho
-- Mestrado Integrado em Engenharia Informática
-- Lincenciatura em Ciências da Computação
-- Unidade Curricular de Bases de Dados
-- 2015/2016
--
-- Caso de Edstudo: "AtetasEAtletas"
-- Povoamento inicial da base de dados
--

-- Indicação do esquema físico da base de dados
USE `AtletasEAtletas` ;

-- Permissão para fazer operações de remoção de dados.
SET SQL_SAFE_UPDATES = 0;

-- Povoamento da tabela `AtletasEAtletas`.`Categorias`
--
-- DELETE FROM Categorias;
INSERT INTO Categorias
	(id, Designacao)
	VALUES
	(1,'Iniciado'),
	(2,'Junior'),
	(3,'Senior'),
	(4,'Veterano');
--
-- SELECT * FROM Categorias;


-- Povoamento da tabela `AtletasEAtletas`.`Especialidades`
--
-- DELETE FROM Especialidades;
INSERT INTO Especialidades 
	(id, Designacao, Descricao)
	VALUES
	(1,'Sono Prolongado','Dormir, dormir, dormir.... zzzzzzz'),
	(2,'Sonequinha', 'Um pequeno período de sono para recuperar o que quer que seja.'),
	(3,'Siesta', 'Uma pequena soneca a seguir ao almoço'),
	(4,'Sono esporádico', 'Adormecer sem qualeur razão aparente'),
	(5,'Sono da Manhã', 'Período de sonho a seguir ao despertador tocar.');
--
-- SELECT * FROM Especialidades;


-- Povoamento da tabela `AtletasEAtletas`.`Campeonatos`
--
-- DELETE FROM Campeonatos;
INSERT INTO Campeonatos 
	(id, Designacao, Descricao)
	VALUES
	(1,'Liga Nacional do Sono da Manhã','Competição anual entre os atletas dos clubes do sono da 1ª liga.'),
	(2,'Campeonato do Sono', 'Campeonato nacional de todas as competições relacionadas com o sono.'),
	(3,'Taça da Siesta', 'Competição entre todos os clubes do sono de todos os escalões competitivos');
--
-- SELECT * FROM Campeonatos;


-- Povoamento da tabela `AtletasEAtletas`.`Provas` 
--
-- DELETE FROM Provas;
INSERT INTO Provas 
	(Nr, DataRealizacao, Organizacao, Especialidade, Campeonato, Categoria, PriceMoney, Observacoes)
	VALUES
	(1,'2014-12-01','Arsenal das Sonecas',1,1,2, 1000, NULL),
	(2,'2014-12-01','Arsenal das Sonecas',1,1,3, 500, NULL),
	(3,'2014-12-31','Companhia do Sono',2,2,1, 500, NULL),
	(4,'2014-12-31','Companhia do Sono',2,2,2, 750, NULL),
	(5,'2015-10-31','Insónias Clube do Vale',5,1,3, 1000, NULL),
	(6,'2015-10-31','Insónias Clube do Vale',5,2,3, 2000, NULL),
	(7,'2015-10-31','Insónias Clube do Vale',5,3,3, 3000, NULL);
--
-- SELECT * FROM Provas;


-- Povoamento da tabela `AtletasEAtletas`.`Treinadores`
--
-- DELETE FROM Treinadores;
INSERT INTO Treinadores
	(id, Designacao, Observacoes, Especialidade)
	VALUES
	(1,'Jonas Cromo do Bairro','Treinador muito exigente.',1),
	(2,'Prieto Lima de Bandaló',NULL,2),
	(3,'Josefa Bocejo Cunha',NULL,3),
	(4,'Jesualdo Lagarto', 'Só treina em dias de sol.',4),
	(5,'Madruga do Canto da Aurora','Tem um CV extraordinário em questões matinais.',5);
--
-- SELECT * FROM Treinadores;


-- Povoamento da tabela `AtletasEAtletas`.`Atletas`
--
-- DELETE FROM Atletas;
	(1,'Felisberto José Pinto Real','20INSERT INTO Atletas 
	(id,  Nome, DataNascimento, Rua, Localidade, CodPostal, DataInicioAtleta,
	Telefone, Facebook, eMail, Categoria, Treinador, Especialidade, Observacoes)
	VALUES
00-01-01','Rua do Caires da Póvoa, 22','Aguada de Cima','999-888 Aires',
     '2014-01-01',456789123,'https://pt-pt.facebook.com/felis','felis@felis.com',2,1,1,'Passa os tempos livres acordado.'),
	(2,'Castro Costa Caixinhas','2002-02-01','Av Sonorífera Intensa, 231, R/C','Lençóis Alvos','2349-111 Panos do Céu',
     '2014-02-01',123456789,'https://pt-pt.facebook.com/castro','castro@castro.com',1,1,1,'Possui uma espregiçadela muito longa.'),
	(3,'Onória da Conceição da Felicidade','1996-02-04','Rua de Quartos, 1/4','Águas Leves de Cima','1111-000 Águas Leves',
     '2014-02-04',789123456,'https://pt-pt.facebook.com/onoria','onoria@onoria.com',3,2,5,NULL),
	(4,'Estamínio Sousa Prior do Campo','2014-09-09','Bairro da Paz, 43, 1º Dto','Olhares','5432-541 Altares Redios',
     '2014-09-09',123454321,'https://pt-pt.facebook.com/prior','prior@prior.com',3,3,3,'Desempenho notório a fazer muito pouco.'),
	(5,'Preguiça Maria Pinto Sonecas','1979-05-11','Beco da Travessa','Fajões do Aido','4654-764 Quintais',
     '2015-05-11',123451234,'https://pt-pt.facebook.com/anasousa','anasousa@anasousa.com',4,4,4,NULL),
	(6,'Solomilho Anho da Paz','1982-01-12','Rua do Pastor, 1234','Andaimes do Antro','869-231 Antro',
     '2015-01-12',678967565,'https://pt-pt.facebook.com/solomilho','solomilho@solomilho.com',4,5,1,'Não se consegue espreguiçar.');
--
-- SELECT * FROM Atletas;

-- Povoamento da tabela `AtletasEAtletas`.`AtletasRanking` 
--
-- DELETE FROM AtletasRanking;
INSERT INTO AtletasRanking 
	(Atleta, Ano, Pontos)
	VALUES
	(1,2014,0),
	(2,2014,10),
	(3,2014,5),
	(4,2014,0),
	(1,2015,10),
	(2,2015,0),
	(3,2015,5),
	(4,2015,0),
	(5,2015,0),
	(6,2015,0);
--
-- SELECT * FROM AtletasRanking;


-- Povoamento da tabela  `AtletasEAtletas`.`ProvasAtletas`
--
-- DELETE FROM ProvasAtletas;
INSERT INTO ProvasAtletas 
	(Prova, Atleta, Classificacao, Pontos, Observacoes)
	VALUES
	(1,2,1,10,NULL),
	(1,1,12,0,NULL),
	(1,3,2,5,NULL),
	(1,4,45,0,NULL),
	(5,1,1,10,NULL),
	(5,3,2,5,NULL),
	(5,2,24,0,NULL),
	(5,5,78,0,NULL),
	(6,6,123,0,NULL),
	(7,5,222,0,NULL);
--
-- SELECT * FROM ProvasAtletas;

-- Inibição das operações de remoção de dados.
SET SQL_SAFE_UPDATES = 1;

-- <fim>
-- Belo, O., Unidade Curricular de Bases de Dados, 2015

