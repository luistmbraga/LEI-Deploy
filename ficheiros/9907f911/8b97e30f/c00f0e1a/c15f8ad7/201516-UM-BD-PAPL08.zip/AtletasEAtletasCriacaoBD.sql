-- Universidade do Minho
-- Mestrado Integrado em Engenharia Informática
-- Lincenciatura em Ciências da Computação
-- Unidade Curricular de Bases de Dados
-- 2015/2016
--
-- Caso de Estudo: "AtetasEAtletas"
-- Criação da base de dados utilizando a script gerada pelo MySQL Workbench.
--

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `AtletasEAtletas` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `AtletasEAtletas` ;

-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`Categorias`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Categorias` (
  `id` INT NOT NULL,
  `Designacao` VARCHAR(75) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`Especialidades`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Especialidades` (
  `id` INT NOT NULL COMMENT '\n',
  `Designacao` VARCHAR(75) NOT NULL,
  `Descricao` TEXT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`Campeonatos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Campeonatos` (
  `Id` INT NOT NULL,
  `Designacao` VARCHAR(75) NOT NULL,
  `Descricao` TEXT NULL,
  PRIMARY KEY (`Id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`Provas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Provas` (
  `Nr` INT NOT NULL,
  `DataRealizacao` DATE NOT NULL,
  `Organizacao` VARCHAR(150) NOT NULL,
  `Especialidade` INT NOT NULL,
  `Campeonato` INT NOT NULL,
  `Categoria` INT NOT NULL,
  `PriceMoney` DECIMAL(12,2) NULL DEFAULT 0,
  `Observacoes` TEXT NULL,
  PRIMARY KEY (`Nr`),
  INDEX `fk_Provas_Especialidades1_idx` (`Especialidade` ASC),
  INDEX `fk_Provas_Campeonato1_idx` (`Campeonato` ASC),
  CONSTRAINT `fk_Provas_Categorias1`
    FOREIGN KEY (`Categoria`)
    REFERENCES `AtletasEAtletas`.`Categorias` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Provas_Especialidades1`
    FOREIGN KEY (`Especialidade`)
    REFERENCES `AtletasEAtletas`.`Especialidades` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Provas_Campeonato1`
    FOREIGN KEY (`Campeonato`)
    REFERENCES `AtletasEAtletas`.`Campeonatos` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`Treinadores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Treinadores` (
  `id` INT NOT NULL,
  `Designacao` VARCHAR(75) NOT NULL,
  `Observacoes` TEXT NULL,
  `Especialidade` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Treinadores_Especialidades1_idx` (`Especialidade` ASC),
  CONSTRAINT `fk_Treinadores_Especialidades1`
    FOREIGN KEY (`Especialidade`)
    REFERENCES `AtletasEAtletas`.`Especialidades` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`Atletas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Atletas` (
  `id` INT NOT NULL,
  `Nome` VARCHAR(75) NOT NULL,
  `DataNascimento` DATE NOT NULL,
  `Rua` VARCHAR(75) NULL,
  `Localidade` VARCHAR(50) NULL,
  `CodPostal` VARCHAR(60) NULL,
  `DataInicioAtleta` DATE NULL,
  `Telefone` VARCHAR(25) NULL,
  `Facebook` VARCHAR(150) NULL,
  `eMail` VARCHAR(100) NULL,
  `Categoria` INT NOT NULL,
  `Treinador` INT NOT NULL,
  `Especialidade` INT NOT NULL,
  `Observacoes` TEXT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Funcionários_Funcoes1_idx` (`Categoria` ASC),
  INDEX `fk_Atletas_Treinadores1_idx` (`Treinador` ASC),
  INDEX `fk_Atletas_Especialidades1_idx` (`Especialidade` ASC),
  CONSTRAINT `fk_Funcionários_Funcoes1`
    FOREIGN KEY (`Categoria`)
    REFERENCES `AtletasEAtletas`.`Categorias` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Atletas_Treinadores1`
    FOREIGN KEY (`Treinador`)
    REFERENCES `AtletasEAtletas`.`Treinadores` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Atletas_Especialidades1`
    FOREIGN KEY (`Especialidade`)
    REFERENCES `AtletasEAtletas`.`Especialidades` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`AtletasRanking`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`AtletasRanking` (
  `Atleta` INT NOT NULL,
  `Ano` INT NOT NULL,
  `Pontos` INT NOT NULL,
  PRIMARY KEY (`Atleta`, `Ano`),
  CONSTRAINT `fk_AtletasRanking_Atletas1`
    FOREIGN KEY (`Atleta`)
    REFERENCES `AtletasEAtletas`.`Atletas` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `AtletasEAtletas`.`ProvasAtletas`
-- -----------------------------------------------------
DROP TABLE `AtletasEAtletas`.`ProvasAtletas`;
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`ProvasAtletas` (
  `Prova` INT NOT NULL,
  `Atleta` INT NOT NULL,
  `Classificacao` INT NOT NULL,
  `Pontos` INT NOT NULL,
  `Observacoes` TEXT NULL,
  PRIMARY KEY (`Prova`, `Atleta`),
  INDEX `fk_ProvasAtletas_Atletas1_idx` (`Atleta` ASC),
  CONSTRAINT `fk_ProvasAtletas_Prova1`
    FOREIGN KEY (`Prova`)
    REFERENCES `AtletasEAtletas`.`Provas` (`Nr`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ProvasAtletas_Atletas1`
    FOREIGN KEY (`Atleta`)
    REFERENCES `AtletasEAtletas`.`Atletas` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- <fim>
-- Unidade Curricular de Bases de Dados, 2015