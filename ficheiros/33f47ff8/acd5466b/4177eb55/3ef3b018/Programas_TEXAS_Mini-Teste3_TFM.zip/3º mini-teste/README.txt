PROGRAMAS TEXAS
3� MINI-TESTE T�PICOS F�SICA MODERNA

-------------------------------
INSTALAR:
-------------------------------

Para poderem p�r estes programas precisam de uma m�quina TEXAS, cabo de conex�o ao pc, e o TI Connect. Podem fazer download do TI CONNECT aqui: http://education.ti.com/pt/portugal/software/details/en/14D11109C9F44D55B9BBF65E5A62E7F1/swticonnectsoftwareforwindows
Se me conseguirem apanhar durante as aulas, tamb�m vos posso meter os programas directamente na vossa m�quina a partir da minha (tenho cabo).
Fiz os programas numa TI 84-PLUS, mas em princ�pio devem funcionar todos nas mais antigas. Nas TI-NSPIRE tanto quanto sei, n�o funcionam, sorry.

Aos amigos que t�m m�quinas CASIO, apenas posso recomendar que comprem uma m�quina como deve ser xD

-------------------------------
IMPORTANTE - ANTES DE USAR:
-------------------------------

- Estes programas usam, e mudam os valores de algumas vari�veis da m�quina. Se tiverem colocado um valor numa vari�vel qualquer e est�o habituados a usar essa vari�vel a fazer contas, tenham cuidado redrobrado e verifiquem se depois de usar o programa o valor da vari�vel se mantem o mesmo, i.e, se o programa a usou ou n�o. Para facilitar, neste mesmo documento indico as vari�veis que cada programa usa e o que faz com elas, para que tenham essa informa��o antes de instalar/usar os programas.
- Os programas n�o est�o protegidos, ou seja, s�o livres de os alterar de modo a ir mais de encontro ao que pessoalmente preferem. No menu dos programas, no separador EDIT podem escolher o programa a editar. Isto permite ver o c�digo de cada programa e o que ele faz.
- Usem o programas antes de os usarem num teste ou em algo importante. Tentem resolver exerc�cios j� resolvidos com eles. Isto ajuda a familizariar com o uso do programa e a saber as potencialidades e limita��es de cada um.

DICA: Os programas al�m de mostrarem resultados no ecr�, tamb�m guardam o(s) resultado(s) nas vari�veis A,B,C,D...Z da m�quina. Se souberem a vari�vel que est� associada a um determinado resultado (indico neste documento as vari�veis), podem depois usar a vari�vel fora do programa nas expess�es. 
EXEMPLO: O programa CNEGRO recebe uma temperatura de um corpo negro e um dos resultados que devolve � a frequ�ncia da radia��o emitida por esse corpo. O programa mostra a frequ�ncia no ecr� mas ao mesmo tempo guarda esse resultado na vari�vel F. Depois de sairem do programa, essa vari�vel pode ser usada em qualquer express�o. Supondo que fora do programa, querem o dobro da frequ�ncia que o programa vos deu. Basta escrever 2F -> ENTER e a m�quina devolve o dobro da frequ�ncia.

Os programas foram feitos por mim, n�o s� como forma de estudo, mas tamb�m como forma de ajudar a resolver os exerc�cios mais rapidamente. Como os testes s�o de escolha m�ltipla e n�o obrigam a apresenta��o de todos os c�lculos, usar estes programas para fazer os c�lculos por n�s � altamente vantajoso, porque temos os resultados quase imediatamente s� com os dados do problema. 

Qualquer quest�o ou sujest�o que tenham � sempre bem-vinda:)

-------------------------------
PROGRAMAS
-------------------------------


===CNEGRO===
Programa sobre a radia��o de corpo negro.

Input: Temperatura de um corpo negro, em Kelvins (Guarda na vari�vel T)

Outputs:
-Comprimento de onda m�ximo da radia��o emitida pelo corpo, em metros. (Guarda na vari�vel L)
-Irradi�ncia, ou seja, a energia por segundo e por unidade de �rea da radia��o emitida por esse corpo, em Watts/m^2 (Guarda na vari�vel I)
-Frequ�ncia da radia��o emitida pelo corpo, em Hz (Guarda na vari�vel F)

Considera��es: Este programa faz uso das f�mulas F=C/c.d.o; I=omega*T^4; T*(c.d.o max.)=0,2898*10^(-2)

===COMPTON===
Programa sobre o efeito de Compton.
Tem um menu com duas op��es. 
Escolher a op��o "DESVIO" se se pretende saber o desvio de compton (aka "delta lambda").
Escolher a segunda ("teta") op��o se se pretender saber o �ngulo associado ao desvio de compton.

Inputs:
Caso tenha sido escolhida a op��o "DESVIO", pergunta o �ngulo (que deve ser dado em graus) associado ao desvio de compton que se pretende saber (Guarda o �ngulo na vari�vel "teta")
Caso tenha sido escolhida a segunda op��o ("teta"), pergunta o desvio de compton (que deve ser dado em metros) associado ao �ngulo teta que se pretende saber (Guarda o desvio na vari�vel L)

Outputs:
Caso tenha sido escolhida a op��o "DESVIO", devolve o desvio de compton, em metros (Guarda na vari�vel L)
Caso tenha sido escolhida a segunda op��o ("teta"), devolve o �ngulo associado ao desvio de compton dado, com o �ngulo em graus (Guarda na vari�vel teta)

Considera��es: Este programa faz uso da f�rmula do desvio de compton. A m�quina � colocada no modo graus. Todos os �ngulos devem ser dados em graus e devem ser lidos em graus (nos resultados). Aplica-se o mesmo aos comprimento de onda, que deve ser dado em metros e lido em metros. 
NOTA IMPORTANTE: Este programa usa a massa do electr�o em kilos a constante de Planck em J*s e a velocidade da luz em metros. Nos exerc�cios que fizemos na aula e os que est�o nas fichas n�o � preciso usar unidades diferentes destas, mas � conviniente ter no��o que o programa parte deste pressuposto. Usar o programa apenas quando se pretende usar as contantes nas unidades referidas atr�s.

===CPLANCK===
Programa que apenas muda a vari�vel H.

A constante de Plack tem o problema de...n�o ser exactamente constante. Em exerc�cios tanto podemos usar o valor dela em ev*s como em J*s. Como era chato ter que estar sempre a alterar manualmente o valor da vari�vel H sempre que a queria numa unidade diferente, criei este programa simples, que me permite escolher se quero a constante em ev*s ou J*s e atribui o valor num�rico respectivo consoante a unidade que eu escolhi. Se est�o tamb�m habituados a usar vari�veis nas express�es da m�quina e em particular usam a vari�vel H para a constante de Planck, talvez possam estar interessados neste programa. Caso contr�rio, ignorem e n�o instalem.

===CDOTRANS==
Calcula o comprimento de onda de uma transi��o

Inputs:
- N� dos n�veis da transi��o (guardados nas vari�veis A e B)
- N� de prot�es (Guardado em Z)
- Massas das cargas positiva e negativa, em kg (Guardadas nas veri�veis J e O)

Output:
- Comprimento de onda correspondente � transi��o, em metros.

Considera��es:
As massas das cargas positivas e negativas apenas s�o necess�rias quando a particula positiva ou negativa n�o � o prot�o e o eletr�o como acontece no �tomo de hidrog�nio. Nesse caso o programa precisa das massas para calcular a massa reduzida do sistema e s� depois fazer a conta final.
Como facilidade, caso se coloque o valor 0 (zero) numa das massas, ou nas duas, o programa assume que a massa reduzida a considerar � a massa do electr�o (caso do �tomo de hidrog�nio).

===Debrogli===
Calcula o comprimento de onda de De Broglie.

Inputs:
- O programa vai perguntar se as unidades s�o em electrao-volt ou Joule e vai guardar a resposta na vari�vel T. Indicar 1, caso as unidades pretendidas sejam Joule, 0 caso seja electrao-volt.
- Energia cin�tica da part�cula, em electrao-volt ou Joule, dependendo da escolha inicial (Guarda na variavel W)
- Massa da part�cula, em kg (Guarda na variavel M).

Outputs:
- Comprimento de onda de De Broglie, em metros (Guarda na vari�vel L)
- Velocidade da particula em m/s. (Guarda na variavel V)
- Rela��o velocidade/velocidade_da_luz. (Este resultado n�o � guardado em nenhuma vari�vel) NOTA: Se este valor for <0,1, significa que n�o � necess�rio usar a aproxima��o relativ�stica.

Considera��es:
Independentemente dos valores dados, o programa usa SEMPRE a aproxima��o relativ�stica e a constante de Planck em J*s para os c�lculos.

===ENERGORB===
Indica a energia de um n�vel OU dada uma energia indica qual o n�vel correspondente.

Inputs:
 - O programa vai perguntar se as unidades s�o em electrao-volt ou Joule e vai guardar a resposta na vari�vel T. Indicar 1, caso as unidades pretendidas sejam Joule, 0 caso seja electrao-volt.
 - Massas das cargas positiva e negativa, em kg (Guardadas nas veri�veis J e O)
 - Caso se escolha o primeiro modo, pergunta a energia que deve ser dada nas unidades que se escolheu no 1� ponto. (Guarda na veri�vel E)
 - Caso se escolha o segundo modo, pergunta o n� do n�vel (Guarda na vari�vel N)
 
 Outputs:
 - Caso se tenha escolhido o 1� modo, d� o n�vel, correspondente � energia dada. (Guarda em Z)
 - Caso se tenha escolhido o 2� modo, d� a energia, correspondente ao n�vel dado, nas unidades indicadas no 1� input. (Guarda em Z)

Considera��es:
As massas das cargas positivas e negativas apenas s�o necess�rias quando a particula positiva ou negativa n�o � o prot�o e o eletr�o como acontece no �tomo de hidrog�nio. Nesse caso o programa precisa das massas para calcular a massa reduzida do sistema e s� depois fazer a conta final.
Como facilidade, caso se coloque o valor 0 (zero) numa das massas, ou nas duas, o programa assume que a massa reduzida a considerar � a massa do electr�o (caso do �tomo de hidrog�nio).
 
===GAMA===
Calcula o Gama.

Input:
- Velocidade em m/s (Guarda em V)

Output:
- Gama, adimensional (Guarda em G)

===RAIOORB===
Calcula o raio de uma �rbita.

Inputs:
 - N� do n�vel para o qual se pretende saber o raio (Guarda em N)
 - N� de prot�es (Guarda em Z)
 - Massas das cargas positiva e negativa, em kg (Guardadas nas veri�veis J e O)
 
 Output:
 - Raio da �rbita, em metros.

Considera��es:
As massas das cargas positivas e negativas apenas s�o necess�rias quando a particula positiva ou negativa n�o � o prot�o e o eletr�o como acontece no �tomo de hidrog�nio. Nesse caso o programa precisa das massas para calcular a massa reduzida do sistema e s� depois fazer a conta final.
Como facilidade, caso se coloque o valor 0 (zero) numa das massas, ou nas duas, o programa assume que a massa reduzida a considerar � a massa do electr�o (caso do �tomo de hidrog�nio).

===RYDBERG===
Coloca na vari�vel R o valor da constante de Rydberg.

Se est�o tamb�m habituados a usar vari�veis nas express�es da m�quina e em particular usam a vari�vel R para a constante de Rydberg, talvez possam estar interessados neste programa. Caso contr�rio, ignorem e n�o instalem.

===VELELECT===
Calcula a velocidade de um electr�o numa �rbita.

Inputs:
- N� do n�vel da �rbita em que est� o electrao (Guardado em N)
- N� de prot�es (Guardado em Z)

Outputs:
- Velecidade do electr�o, em m/s (Guarda em V)
- Rela��o velocidade/velocidade_da_luz. (Este resultado n�o � guardado em nenhuma vari�vel)

