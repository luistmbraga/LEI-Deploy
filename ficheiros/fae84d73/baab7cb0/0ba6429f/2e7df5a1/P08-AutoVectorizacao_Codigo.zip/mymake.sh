
make -f MakefileO2 clean
make -f MakefileO2
make -f MakefileO3 clean
make -f MakefileO3

