#include <stdio.h>

#include "papi_inst.h"

#define REPEATS 10

#define SIZE 1000000

float a[SIZE] __attribute__ ((aligned(16)));
float b[SIZE] __attribute__ ((aligned(16)));
float c[SIZE] __attribute__ ((aligned(16)));

void loop () {
  int i;
 
 for (i=0 ; i<SIZE; i++) {
    c[i] = a[i]*a[i]*a[i] + 10.0f/a[i] + 100.f/(a[i]*a[i]);
  }
}

//extern void loop (float * , float * , float * , const int );

main () {
  long long start_usec, end_usec;
  long long inst, cyc;

  // Initialize Papi and its events

  for (int n=0 , f=1.0; n<SIZE ;  n++ , f=f+1.0F) a[n] = f;

  // use PAPI  (usecs + cyc)
  startPAPI();
  start_usec = PAPI_get_real_usec();

  for (int n=0 ; n<REPEATS ; n++) {
    loop ();
    //loop (a, b, c, SIZE);
  }

  end_usec = PAPI_get_real_usec();
  stopPAPI(&inst, &cyc);

  printf ("CPI= %.2f\t (#cc= %lld /#I= %lld)\tTexec: %lld usecs\t\n", ((float)cyc)/((float)inst), cyc/REPEATS, inst/REPEATS, (end_usec - start_usec)/REPEATS);

}


