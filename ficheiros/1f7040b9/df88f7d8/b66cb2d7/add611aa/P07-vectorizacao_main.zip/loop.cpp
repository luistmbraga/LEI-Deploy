//void loop (int * __restrict__ x, int * __restrict__ y, int * __restrict__ z, const int S) {
void loop (int * x, int *  y, int * z, const int S) {
  int i;
 
 for (i=0 ; i<S; i++) {
    z[i] = x[i] + y[i];
  }
}
