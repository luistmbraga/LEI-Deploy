#include <stdio.h>

#include "papi_inst.h"

#define REPEATS 10

#define SIZE 1000000

int a[SIZE] __attribute__ ((aligned(16)));
int b[SIZE] __attribute__ ((aligned(16)));
int c[SIZE] __attribute__ ((aligned(16)));

void loop () {
  int i;
 
 for (i=0 ; i<SIZE; i++) {
    c[i] = a[i] + b[i];
  }
}

//extern void loop (float * , float * , float * , const int );

main () {
  long long start_usec, end_usec;
  long long inst, cyc;

  // Initialize Papi and its events

  // use PAPI  (usecs + cyc)
  start_usec = PAPI_get_real_usec();
  startPAPI();

  for (int n=0 ; n<REPEATS ; n++) {
    loop ();
    //loop (a, b, c, SIZE);
  }

  stopPAPI(&inst, &cyc);
  end_usec = PAPI_get_real_usec();

  printf ("CPI= %.2f\t (#cc= %lld /#I= %lld)\tTexec: %lld usecs\t\n", ((float)cyc)/((float)inst), cyc/REPEATS, inst/REPEATS, (end_usec - start_usec)/REPEATS);

}


