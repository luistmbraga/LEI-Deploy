#ifndef __CONFIG_H__
#define __CONFIG_H__

//#define IL_NO_JPG
//#define IL_NO_MNG
//#define IL_NO_PNG
//#define IL_NO_TIF
//#define IL_NO_GIF
//#define IL_NO_LCMS

#define ILUT_USE_OPENGL
#define ILUT_USE_DIRECTX8
#define ILUT_USE_WIN32

#endif /* __CONFIG_H__ */
