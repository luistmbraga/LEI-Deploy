
/**
 * Motorista.
 * 
 * @author Jos� Creissac campos
 * @version 05/2008
 */
public class Motorista extends Empregado {
    // class variables
    private static double ValorPorKm = 10; // assumimos que � igual para todos...

    // instance variables
    private double km;

    /**
     * Constructor for objects of class Motorista
     */
    public Motorista(String cod, String nom, int dias, double km) {
        super(cod, nom, dias); 
        this.km = km;
    }
    
    public Motorista(Motorista m) {
        super(m);
        this.km = m.getKms();
    }

    // M�todos de inst�ncia
    /**
     * Saber Km percorridos
     * 
     * @return     Km percorridos pelo motorista 
     */
    public double getKms() {
        return this.km;
    }

    /**
     * Calcular sal�rio
     * 
     * @return     sal�rio do motorista tendo em conta os Km percorridos
     */
    public double salario() { 
       return super.salario()+this.km*Motorista.ValorPorKm; 
    } 
    
    
    /**
     * Motorista como String
     * 
     * @return  Uma string vom o nome e c�digo do motorista
     */
    public String toString() { 
        return "Motorista" + ";" + super.toString() + ";" + this.km;
    }  
        
    /**
     * Criar uma c�pia do motorista
     */
    public Motorista clone() { 
        return new Motorista(this); 
    } 

    /** 
     * Comparar Motoristas 
     */   
    public boolean equals (Object o) {
        if (o==this)
            return true;
        if (o==null || o.getClass()!=this.getClass())
            return false;
        Motorista g = (Motorista) o;
        return super.equals(o) && this.km==g.getKms();
   }


}
