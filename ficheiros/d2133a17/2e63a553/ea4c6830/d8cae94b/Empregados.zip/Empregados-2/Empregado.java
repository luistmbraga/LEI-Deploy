/** 
 * Abstract class Empregado  
 *  
 * @author F. M�rio Martins 
 * @version 1/2007 (alterado!)
 */ 
import java.io.*; 
public abstract class Empregado implements Serializable { 
   // de classe 
   private static double salDia = 50.00; 
   public static double getSalDia() { return salDia; } 

   // de inst�ncia 
   private String codigo; 
   private String nome; 
   private int dias; 

   // Construtores 
   public Empregado(String cod, String nom, int dias) { 
       codigo = cod; nome = nom; this.dias = dias; 
   }    
   public Empregado(Empregado emp) { 
       codigo = emp.getCodigo(); nome = emp.getNome();  
       dias = emp.getDias(); 
   } 
    
   public String getNome() { return nome; } 
   public String getCodigo() { return codigo; } 
   public int getDias() { return dias; } 
    
   public boolean equals(Object o) {
        if (o==this)
            return true;
        if (o==null || o.getClass()!=this.getClass())
            return false;
        Empregado e = (Empregado) o;
        return this.codigo.equals(e.getCodigo())
            && this.nome.equals(e.getNome())
            && this.dias == e.getDias();
        }
        
   public int hashCode() {
       return this.codigo.hashCode();
    }
            
   public  double salario() { 
       return this.getDias()*Empregado.getSalDia(); 
    }  
    
   public String toString() {
       return this.codigo + ";" + this.nome + ";" + this.dias;
    }
   
   // abstractos 
   public abstract Empregado clone(); 
} 
 
