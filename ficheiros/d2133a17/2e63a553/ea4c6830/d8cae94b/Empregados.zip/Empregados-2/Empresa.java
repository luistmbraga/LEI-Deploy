/** 
 * TabelaEmpregados. 
 *  
 * @author Jos� Creissac Campos 
 * @version 05/2008 
 */ 
import java.util.*; 
import java.io.*; 
public class Empresa implements Serializable { 
 
    private Map<String,Empregado> emps; 
   
    // Construtores 
    public Empresa() { 
        this.emps = new TreeMap<String,Empregado>(); 
    } 
      
    public Empresa(Empresa tab) {    
        Map<String,Empregado> aux = tab.daTabela(); 
        for(Map.Entry<String,Empregado> e : aux.entrySet()) 
            emps.put(e.getKey(),e.getValue()); 
    }
   
    // Inst�ncia 
    public Map<String,Empregado> daTabela() { 
        Map<String,Empregado> aux = new TreeMap<String,Empregado>(); 
        for(Map.Entry<String,Empregado> e : emps.entrySet()) 
            aux.put(e.getKey(),e.getValue().clone()); 
        return aux; 
    } 
 
    public boolean existeEmp(String cod) { 
        return emps.containsKey(cod); 
    } 
   
    public void insereEmp(Empregado emp) { 
        emps.put(emp.getCodigo(),emp.clone()); 
    } 
 
    public Empregado daFichaEmp(String cod) { 
        Empregado emp = emps.get(cod); 
        return emp!=null ? emp.clone() : null; 
    } 
   
    public void juntaEmpregados(Set<? extends Empregado> lstEmp) { 
        for(Empregado emp : lstEmp) 
            emps.put(emp.getCodigo(),emp.clone()); 
    } 
   
    public double totalSalarios() { 
        double total = 0.0; 
        for(Empregado emp : emps.values()) 
            total += emp.salario(); 
        return total; 
    } 
   
    public int totalGestores() { 
        int total = 0; 
        for(Empregado emp : emps.values()) 
            if(emp instanceof Gestor) 
                total++; 
        return total; 
    } 
   
    public int totalDe(String Tipo) { 
        int total = 0; 
        for(Empregado emp : emps.values()) 
            if(emp.getClass().getName().equals(Tipo)) 
                total++; 
        return total; 
    }       
   
    public double totalKms() { 
        double totalKm = 0.0; 
        for(Empregado emp : emps.values())  
            if(emp instanceof Motorista) 
                totalKm += ((Motorista) emp).getKms(); 
        return totalKm; 
    }   
  
    public String toString() { 
      StringBuilder sb = new StringBuilder(); 
      for(Empregado emp : emps.values()) 
            sb.append(emp.toString() + "\n"); 
      return sb.toString(); 
  } 
} 
 
 
