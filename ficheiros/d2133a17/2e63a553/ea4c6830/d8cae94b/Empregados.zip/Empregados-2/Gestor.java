/** 
 * Gestor 
*/ 
public class Gestor extends Empregado { 
   // Vars de inst�ncia 
   private double premio;  
   // Construtores 
   public Gestor(String cod, String nom, int dias, double prem) { 
       super(cod, nom, dias); 
       premio = prem; 
   }    
   public Gestor(Gestor gest) { 
       super(gest); 
       premio = gest.getPremio(); 
   } 
   // M�todos de inst�ncia 
   public double getPremio() { return premio; }   
   
   public boolean equals (Object o) {
       if (o==this)
            return true;
        if (o==null || o.getClass()!=this.getClass())
            return false;
        Gestor g = (Gestor) o;
        return super.equals(o) && this.premio==g.getPremio();
   }
    
   public double salario() { 
       return super.salario()*this.premio; 
    } 
    
    public String toString() {
        return "Gestor" + ";" +super.toString() + ";" + this.premio; 
    }  

                                     // Implementa��o dos abstractos 
   public Gestor clone() { return new Gestor(this); } 
} 
