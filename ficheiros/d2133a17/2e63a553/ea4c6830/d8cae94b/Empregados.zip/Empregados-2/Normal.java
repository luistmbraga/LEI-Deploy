
/**
 * Empregado "normal".
 * 
 * @author Jos� Creissac campos
 * @version 05/2008
 */
public class Normal extends Empregado {

    /**
     * Constructor for objects of class Normal
     */
    public Normal(String cod, String nom, int dias) {
        super(cod, nom, dias); 
    }
    
    public Normal(Normal m) {
        super(m);
    }

    // M�todos de inst�ncia
    
    public String toString() {
        return "Normal" + ";" + super.toString();
    }
        
    /**
     * Criar uma c�pia do empregado
     */
    public Normal clone() { 
        return new Normal(this); 
    } 

}

