//PAPI related stuff
#include "papi_inst.h"

#define NUMEVENTS 2

#include<stdio.h>
using namespace std;
#include <iostream>



string nEvents[NUMEVENTS] = { "PAPI_TOT_INS", "PAPI_TOT_CYC" };
int events[NUMEVENTS] = {PAPI_TOT_INS, PAPI_TOT_CYC};
int errorcode;
long long values[NUMEVENTS];
char errorstring[PAPI_MAX_STR_LEN+1];

void startPAPI() {
	errorcode = PAPI_start_counters(events, NUMEVENTS);
}
void stopPAPI() {
	errorcode = PAPI_stop_counters(values, NUMEVENTS);
	
	if (errorcode != PAPI_OK) {
	    PAPI_perror(errorcode, errorstring, PAPI_MAX_STR_LEN);
	    fprintf(stderr, "PAPI error (%d): %s\n", errorcode, errorstring);
	}
	for (int w=0; w<NUMEVENTS; w++)
		cout << nEvents[w] << ":" << values[w] << endl;
}
