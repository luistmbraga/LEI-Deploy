#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "papi_inst.h"

#include "convolve.h"
#include "ppm.h"

static int verify_command_line (int argc, char *argv[], char *infile, char *outfile);
static int read_inp_image (char *infile, image *img);
static int write_out_image (char *outfile, image res_img);
static void print_usage (char *msg);




int main (int argc, char *argv[]) {
  image img, res_img, buf;
  char infile[256], outfile[256];
  long long start_usec, end_usec;
  int total_elements;

  if (!verify_command_line (argc, argv, infile, outfile)) {
	return 0;
  }

  // Read input file
  if (!read_inp_image (infile, &img)) return 0;
  total_elements = img->width * img->height;
  printf ("Image resolution %d x %d = %d pixels\n\n", img->width, img->height, total_elements);

  // create output image
  res_img = new_img (img->width, img->height, BW);
  if (!res_img) {
	fprintf (stderr, "Error creating result image\n");
	return 0;
  } 

  // create intermediate image
  buf = new_img (img->width, img->height, BW);
  if (!buf) {
	fprintf (stderr, "Error creating intermediate buffer image\n");
	return 0;
  } 

  // Initialize Papi and its events
  //startPAPI();

  // use PAPI timer (usecs)
  start_usec = PAPI_get_real_usec();

  convolve (res_img->buf, img->buf, img->width, img->height, buf->buf);

  end_usec = PAPI_get_real_usec();
  printf ("Wall clock time: %lld usecs\n", end_usec - start_usec);
  //stopPAPI();


  if (!write_out_image (outfile, res_img)) return 0;

  free_img (img);
  free_img (res_img); 
  free_img (buf); 

  printf ("\nThat's all, folks\n");
}

static int verify_command_line (int argc, char *argv[], char *infile, char *outfile) {
	if (argc!=3) {
		print_usage ((char *)"Exactly 2 arguments are required!");
		return 0;
	}
	strcpy (infile, argv[1]);
	strcpy (outfile, argv[2]);
	return 1;
}

static void print_usage (char *msg) {
	fprintf (stderr, "Command Line Error! %s\n", msg);
	fprintf (stderr, "Usage:\tconvolve <input filename> <output filename>\n\n");
}

static int read_inp_image (char *infile, image *img) {
	FILE *f;
	
	// open input file
	// NOTE: it must be open as binary, otherwise reading might stop at \0 chars
	f = fopen (infile, "rb");
	if (!f) {
		fprintf (stderr, "Error opening input file: %s\n", infile);
		return 0;
	}

	// read file
	*img = read_ppm(f);
	if (!(*img)) {
		fclose (f);
		fprintf (stderr, "Error reading image file:%s\n", infile);
		return 0;
	}
	fclose (f);
	return 1;
}

static int write_out_image (char *outfile, image res_img) {
	FILE *f;
	
	// open output file
	// NOTE: it must be open as binary, otherwise errors arise with the CR+LF and the LF convention of Win/Unix
	f = fopen (outfile, "wb");
	if (!f) {
		fprintf (stderr, "Error opening output file: %s\n", outfile);
		return 0;
	}
	output_ppm(f, res_img);
	fclose (f);
}
