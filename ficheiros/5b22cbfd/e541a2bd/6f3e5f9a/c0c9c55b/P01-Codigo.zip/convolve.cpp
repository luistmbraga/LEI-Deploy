#include <stdio.h>

void convolve (int *h, int *I, int W, int H, int *buf) {
  int x, y;

  // horizontal filter
  for (x=1 ; x<(W-1) ; x++) { // for each column of I
    for (y=0 ; y<H ; y++) { // for each row of I
      buf[x+y*W] = (I[x-1+y*W] + I[x+y*W] + I[x+1+y*W]) / 3;
    } // y loop
  } // x loop

  // vertical filter
  for (x=1 ; x<(W-1) ; x++) { // for each column of I
    for (y=1 ; y<(H-1) ; y++) { // for each row of I
      h[x+y*W] = (buf[x+(y-1)*W] + buf[x+y*W] + buf[x+(y+1)*W]) / 3;
    } // y loop
  } // x loop
}
