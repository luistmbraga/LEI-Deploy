#ifndef __CONVOLVE
#define __CONVOLVE

void convolve (int *h, int *I, int W, int H, int *buf);

#endif
