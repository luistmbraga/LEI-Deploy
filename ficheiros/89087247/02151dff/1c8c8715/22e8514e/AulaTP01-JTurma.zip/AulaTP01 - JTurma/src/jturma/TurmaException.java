package jturma;


/**
 * Excep��es da classe Turma.
 * 
 * @author Jos� Creissac Campos
 * @version 05/2002
 */
public class TurmaException extends Exception{
    
    public TurmaException() {
        super();
    }
    
    public TurmaException(String s) {
        super(s);
    }
}
