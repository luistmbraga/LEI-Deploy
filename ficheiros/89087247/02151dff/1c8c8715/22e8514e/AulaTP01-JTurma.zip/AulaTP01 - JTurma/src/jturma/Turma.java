package jturma;

/**
 * Classe turma.
 * 
 * @author Jos� Creissac Campos
 * @version 080501
 */

import java.util.*;
public class Turma extends Observable {
    // vari�veis de inst�ncia


    /**
     * @associates <{Aluno}>
     * @link aggregation*/
    private Map<String,Aluno> turma;

    // Construtor

    public Turma() {
        this.turma = new Hashtable<String,Aluno>();
    }

    // M�todos de inst�ncia

    /**
     * Adicionar um aluno.
     * Se o Aluno j� existe, � substituido.
     */
    public void addAluno(Aluno a) {
        Aluno copia = (Aluno)a.clone();
        String num= a.getNumero();
        boolean update = this.turma.containsKey(num);
        this.turma.put(num,copia);
        if (!update) {
            this.setChanged();
            this.notifyObservers();
        }
    }

    /**
     * Consultar um aluno
     */
    public Aluno getAluno(String num) throws TurmaException {
        
        try {
            Aluno a = this.turma.get(num);
            return (Aluno)a.clone();
        } 
        catch (NullPointerException e) {
            StringBuffer sb = new StringBuffer("Aluno ");
            sb.append(num);
            sb.append(" inexistente!");
            throw new TurmaException(sb.toString());
        }
    }

    /**
     * Remover um aluno
     */
    public void delAluno(String num) throws TurmaException {
        if (!this.turma.containsKey(num)) {
            StringBuffer sb = new StringBuffer("Aluno ");
            sb.append(num);
            sb.append(" inexistente!");
            throw new TurmaException(sb.toString());
        }        
        this.turma.remove(num);
        this.setChanged();
        this.notifyObservers();
    }

    /**
     * Quantos alunos passaram
     */
    public int quantosPassam() {
        Iterator e = this.turma.values().iterator();
        int tot = 0;

        while (e.hasNext()) {
            Aluno a = (Aluno)e.next();
            if (a.getMedia()>=10)
                tot++;
        }
        return tot;
    }
         
}
