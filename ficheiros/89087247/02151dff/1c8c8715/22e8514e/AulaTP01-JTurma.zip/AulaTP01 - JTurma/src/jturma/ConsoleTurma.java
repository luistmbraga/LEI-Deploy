
/**
 * Classe de teste interactiva em modo Texto.
 * 
 * @author Jos� Creissac Campos 
 * @version 05/2002
 */

package jturma;

public class ConsoleTurma {

    // Vari�veis de classe
    private static Turma t;

    // M�todo principal
    public static void main(String[] args)  {
        int op;
        String[] op��es = {"Inserir Aluno","Remover Aluno","Consultar Aluno"};
    
        t = new Turma();        // inicializar a turma a vazio...
        
        do {
            op = ConsoleTurma.menu(op��es);
            switch (op) {
                case 1: inserir(); 
                        break;
                case 2: remover();
                        break;
                case 3: consultar();
            }
        } while (op!=0);
        System.out.println("Volte sempre!");
    }
    
    // M�todos auxiliares
    
    /** Inserir um aluno */
    private static void inserir() {
        Aluno a;
        String nome, num;
        int nt,np;
        
        nome = Console.readString("Nome: ");
        num = Console.readString("Numero: ");
        nt = Console.readInt("Nota Te�rica");
        np = Console.readInt("Nota Pr�tica");
        
        a = new Aluno(num, nome, nt, np);
        
        t.addAluno(a);
    }
    
    /** Consultar um aluno */
    private static void consultar() {
        Aluno a;
        String num;
        
        num = Console.readString("Numero: ");
        
        try {
            a = t.getAluno(num);
            System.out.println(a.toString());
            System.out.println("M�dia: "+a.getMedia());
        }
        catch (TurmaException e) {
            System.out.println("Aluno inexistente!");
        }
    }
    
    /** Remover um aluno */
    private static void remover() {
        Aluno a;
        String num;
        
        num = Console.readString("N�mero: ");
        
        try {
            t.delAluno(num);
            System.out.println("Aluno removido.");
        }
        catch (TurmaException e) {
            System.out.println("Aluno inexistente!");
        }
    }
    
    /** Apresentar Menu e ler opc��o */
    private static int menu(String[] ops) {
        int op;
        
        do {
            // Apresentar o menu
            System.out.println(" *** Menu *** ");
            for (int i=0; i<ops.length; i++) {
                System.out.print(i+1);
                System.out.print(" - ");
                System.out.println(ops[i]);
            }
            System.out.println("0 - Sair");
        
            // ler op��o
            op = Console.readInt("Op��o: ");
            if (op<0 || op>ops.length)
                System.out.println("Op��o Inv�lida!!!");
        } while (op<0 || op>ops.length);
        
        return op;
    }
}
