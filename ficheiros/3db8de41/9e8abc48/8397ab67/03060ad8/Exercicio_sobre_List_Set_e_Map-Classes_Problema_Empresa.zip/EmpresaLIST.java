
/**
 * Implementação de uma empresa numa lista
 * 
 * 
 */
public class EmpresaLIST {
  private ArrayList<Empregado> empregados;
  
  
    
    
}
