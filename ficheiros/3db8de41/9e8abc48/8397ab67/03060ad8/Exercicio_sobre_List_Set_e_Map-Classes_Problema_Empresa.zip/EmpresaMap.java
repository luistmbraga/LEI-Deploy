
/**
 * Implementação de uma empresa utilizando um Map.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EmpresaMap {
   
  private HashMap<String,Empregado> empregados;
  
  
}
