
/**
 * Implementação da empresa utilizando um HashSet
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EmpresaHash {
  private HashSet<Empregado> empregados;
  
  
}
