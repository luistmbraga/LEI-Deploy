
/**
 * Abstract class Empregado 
 * 
 * @author F. M�rio Martins
 * @version 1/2007
 * 
 * @author anr
 * @version 5/2012
 */
import java.io.*;

public class Empregado implements Serializable {
   // de classe
   private static double salDia = 50.00;
   public static double getSalDia() { return salDia; }
   public static void setSalDia(double nvSalDia) { 
     salDia = nvSalDia; 
   }
   
   // de inst�ncia
   private String codigo;
   private String nome;
   private int dias;
   private double factor; //factor de desempenho
   
   // Construtores
   
   public Empregado() {
     this.codigo = "";
     this.nome = "";
     this.dias = 0;
     this.factor = 0.0;
   }
   
   public Empregado(String cod, String nom, int dias, double factor) {
       this.codigo = cod; this.nome = nom; this.dias = dias;
       this.factor = factor;
   }   
   
   public Empregado(Empregado emp) {
       this.codigo = emp.getCodigo(); this.nome = emp.getNome(); 
       this.dias = emp.getDias();
       this.factor = emp.getFactor();
   }
   
   public String getNome() { return this.nome; }
   public String getCodigo() { return this.codigo; }
   public int getDias() { return this.dias; }
   public double getFactor() {return this.factor;}
   
   public boolean equals(Object obj) {
      if(this == obj) return true; 
      if((obj == null) || (this.getClass() != obj.getClass())) return false;
      Empregado e = (Empregado) obj;
      return this.nome.equals(e.getNome()) && this.codigo.equals(e.getCodigo()) && this.dias == e.getDias();
   } 
  
  
   public double salario() {
     return getSalDia()*this.factor;
    }
    
   public String toString() {return "COMPLETAR";}
   public Empregado clone() {
     return new Empregado(this);
   }
}
  
