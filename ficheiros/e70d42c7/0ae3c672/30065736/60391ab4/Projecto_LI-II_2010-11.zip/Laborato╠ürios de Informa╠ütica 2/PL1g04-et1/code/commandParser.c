#include "erro.h"
#include "stackAreas.h"
#include "stackRectangulos.h"
#include "restricoes.h"
#include <stdio.h>
#include <string.h>

void correrComando (char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas)
{
	char escolha[10];

	sscanf(linha, "%10s", escolha);

	if (!strcmp(escolha,"DIM"))
	{
		if (adicionaArea(linha, pAreas)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"AREA"))
	{
		if (adicionaArea(linha, pAreas)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"RECT"))
	{
		if (adicionaRectangulo(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"COL"))
	{
		if (colocaRectangulo(linha, pRects, pAreas, 'n')) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"COLR"))
	{
		if (colocaRectangulo(linha, pRects, pAreas, 's')) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"DIR"))
	{
		if (estaDireita(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"ESQ"))
	{
		if (estaEsquerda(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"CIM"))
	{
		if (estaCima(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"BX"))
	{
		if (estaBaixo(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"CLD"))
	{
		if (estaColado(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"SEP"))
	{
		if (!estaColado(linha, pRects)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"DENTRO"))
	{
		if (estaDentro(linha, pRects, pAreas)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"FORA"))
	{
		if (estaFora(linha, pRects, pAreas)) printf("SIM\n");
		else printf("NAO\n");
	}
	else if (!strcmp(escolha,"ESTADO"))
	{
		listaRectangulos(pRects);
	}
	else mensagem_de_erro(E_COMANDO);
/** \code
 char escolha[10];
 
 sscanf(linha, "%10s", escolha);	// Recolhe o nome do comando.
 
 if (!strcmp(escolha,"DIM"))	// Caso seja DIM...
 {
	if (adicionaArea(linha, pAreas)) printf("SIM\n");	// Executa a função \a adicionaArea e, caso adicione correctamente, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"AREA"))	// Caso seja AREA...
 {
	if (adicionaArea(linha, pAreas)) printf("SIM\n");	// Executa a função \a adicionaArea e, caso adicione correctamente, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"RECT"))	// Caso seja RECT...
 {
	if (adicionaRectangulo(linha, pRects)) printf("SIM\n");	// Executa a função \a adicionaRectangulo e, caso adicione correctamente, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"COL"))	// Caso seja COL...
 {
	if (colocaRectangulo(linha, pRects, pAreas, 'n')) printf("SIM\n");	// Executa a função \a colocaRectangulo e, caso coloque correctamente, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"COLR"))	// Caso seja COLR...
 {
	if (colocaRectangulo(linha, pRects, pAreas, 's')) printf("SIM\n");	// Executa a função \a colocaRectangulo e, caso coloque correctamente, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"DIR"))	// Caso seja DIR...
 {
	if (estaDireita(linha, pRects)) printf("SIM\n");	// Executa a função \a estaDireita e, caso esteja à direita, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"ESQ"))	// Caso seja ESQ...
 {
	if (estaEsquerda(linha, pRects)) printf("SIM\n");	// Executa a função \a estaEsquerda e, caso esteja à esquerda, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário.	
 }
 else if (!strcmp(escolha,"CIM"))	// Caso seja CIM...
 {
	if (estaCima(linha, pRects)) printf("SIM\n");	// Executa a função \a estaCima e, caso esteja em cima, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"BX"))	// Caso seja BX...
 {
	if (estaBaixo(linha, pRects)) printf("SIM\n");	// Executa a função \a estaBaixo e, caso esteja em baixo, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"CLD"))	// Caso seja CLD...
 {
	if (estaColado(linha, pRects)) printf("SIM\n");	// Executa a função \a estaColado e, caso esteja colado, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"SEP"))	// Caso seja SEP...
 {
	if (estaSeparado(linha, pRects)) printf("SIM\n");	// Executa a função \a estaSeparado e, caso esteja separado, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"DENTRO"))	// Caso seja DENTRO...
 {
	if (estaDentro(linha, pRects, pAreas)) printf("SIM\n");	// Executa a função \a estaDentro e, caso esteja dentro, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"FORA"))	// Caso seja FORA...
 {
	if (estaFora(linha, pRects, pAreas)) printf("SIM\n");	// Executa a função \a estaFora e, caso esteja fora, retorna 'SIM'.
	else printf("NAO\n");	// Retorna 'NAO', caso contrário. 
 }
 else if (!strcmp(escolha,"ESTADO"))	// Caso seja ESTADO...
 {
	listaRectangulos(pRects); // Faz uma listagem de rectângulos...
 }
 else mensagem_de_erro(E_COMANDO); // Caso seja inserido um comando não reconhecido, erro, pois o comando não existe.
 
* \endcode
*/	

/** \param linha que vai ser lida e corresponde à inserção de um dos comandos existentes. */
/** \param pRects que será a pilha de rectângulos usada em todo o processo. */		
/** \param pAreas que será a pilha de àreas usada em todo o processo. */	
}