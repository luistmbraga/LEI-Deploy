#include <stdio.h>
#include "stackAreas.h"
#include "stackRectangulos.h"
#include "commandParser.h"

/** 
* \file commandParser.h
* \brief Leitor de comandos 
* 
* Assinatura da função \a correrComando.
*/

/** 
 * \file commandParser.c
 * \brief Leitor de comandos
 * 
 * Implementação da função \a correrComando. \n Esta função recebe o comando e executa a função correspondente.
 * \n Retorna 'SIM' ou 'NAO' conforme o resultado da função.
 */

/** 
 * \file erro.h
 * \brief Mensagens de erro
 * 
 * Assinatura da função \a mensagem_de_erro e definição dos erros possíveis.
 */

/** 
 * \file erro.c
 * \brief Estrutura de erro
 * 
 * Definição da estrutura de erro e implementação da função \a mensagem_de_erro 
 */

/** 
 * \file restricoes.h
 * \brief Restricoes
 * 
 * 
 * Assinatura das funções que definem as restrições.
 */

/** 
 * \file restricoes.c
 * \brief Restricoes 
 * 
 * Implementação das funções que definem as restrições.
 */

/** 
 * \file stackAreas.h
 * \brief Estrutura de àreas e pilha de àreas
 * 
 * Estrutura de àrea e pilha de àrea. \n
 * Assinatura das funções relativas a àreas.
 */

/** 
 * \file stackAreas.c
 * \brief Estrutura de àreas e pilha de àreas
 * 
 * Implementação das funções relativas a àreas.
 */

/** 
 * \file stackRectangulos.h
 * \brief Estrutura de rectângulos e pilha de rectângulos
 * 
 *  Estrutura de rectângulo e pilha de rectângulos. \n
 *  Assinatura das funções relativas a rectângulos.
 */

/** 
 * \file stackRectangulos.c
 * \brief Estrutura de rectângulos e pilha de rectângulos
 * 
 * Implementação das funções relativas a rectângulos.
 */

/** 
 * \file main.c
 * \brief Programa principal
 * 
 * É o que está visível ao utilizador. Aqui, ele insere os comandos que pretende.
 */

/*! \mainpage Etapa 1 
 *
 * \section Autores
 * Carlos Gregório, Hugo Mendes e Tiago Conceição
 * 
 *
 * \section Introdução
 *
 * Nesta etapa é criada a ferramenta que permitirá ao utilizador colocar os rectângulos na àrea de trabalho 
 * e verificar quais as restrições que são cumpridas. \n
 * Assim, apenas vai ser feita a leitura do dispositivo de entrada dos comandos e a escrita 
 * no dispositivo de saída da linguagem de disposição dos rectângulos. \n
 *
 * Foram implementados: \n
 *		- Um leitor de comandos;
 *		- Uma estrutura para àreas e outra para rectângulos;
 *		- Uma estrutura para pilha de àreas e outra para pilha de rectângulos;
 *		- Todas as funções para que o output da aplicação fosse o mais correcto possível;
 *		- E ainda o módulo de erros fornecido pelo docente.
 */

int main()
{	

	pilhaRectangulos pRects;
	pilhaAreas pAreas;

	char linha[2048];

	rectangulosInit(&pRects);
	areasInit(&pAreas);
	
	while (!feof(stdin)) if (scanf("\n%[^\n]s\n", linha) != EOF) correrComando(linha, &pRects, &pAreas);

	return 0;
/** \code
 pilhaRectangulos pRects;	// Declaração da pilha de rectângulos.
 pilhaAreas pAreas;	// Declaração da pilha de àreas.
 
 char linha[2048];	// Corresponde a todo o input.
 
 rectangulosInit(&pRects);	// Inicialização da pilha de rectângulos.
 areasInit(&pAreas);	// Inicialização da pilha de àreas.
 
 while (!feof(stdin))	// Enquanto houver input...
	if (scanf("\n%[^\n]s\n", linha) != EOF) // ...se o comando não fôr a linha vazia...
		correrComando(linha, &pRects, &pAreas);	// ...executa o comando introduzido.
 return 0;
* \endcode 
*/ 
}