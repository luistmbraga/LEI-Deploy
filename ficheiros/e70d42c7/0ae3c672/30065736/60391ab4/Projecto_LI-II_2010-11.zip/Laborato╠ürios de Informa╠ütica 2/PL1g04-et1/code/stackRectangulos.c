#include <stdio.h>
#include <string.h>
#include "stackRectangulos.h"
#include "erro.h"

int rectangulosInit(pilhaRectangulos *pilha)
{
	pilha->stackPtr = 0;
	return 1;
/** \code
 pilha->stackPtr = 0;	// Basta inicializar o stack pointer a 0 
 return 1;
 * \endcode 
 */
 
/** \param pilha que vai ser criada com o nome que lhe for dado aqui.  */	
}

int adicionaRectangulo(char *linha, pilhaRectangulos *pilha)
{
	rectangulo auxR;
	
	if (sscanf(linha, "%*s %s %d %d %c", auxR.nome, &auxR.tamx, &auxR.tamy, &auxR.roda) == 4)	
	{
		if (auxR.tamx <= MAXTAMX && auxR.tamy <= MAXTAMY && auxR.tamx > 0 && auxR.tamy > 0)	
		{
			if (auxR.roda == 's' || auxR.roda == 'n')	
			{
				if (procuraRectangulo(auxR.nome, pilha) == NULL)	
				{
					if (!rectangulosCheia(pilha))	
					{
						auxR.rodado = 'n'; auxR.coordx = -1; auxR.coordy = -1;
						pilha->rectangulos[pilha->stackPtr] = auxR;
						pilha->stackPtr++;
						return 1;
					}
				}  else mensagem_de_erro(E_JA_EXISTE);
			} else mensagem_de_erro(E_INVARGS);
		} else mensagem_de_erro(E_DIM);
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 rectangulo auxR;
 
 if (sscanf(linha, "%*s %s %d %d %c", auxR.nome, &auxR.tamx, &auxR.tamy, &auxR.roda) == 4)	// Recebe os argumentos, ignorando o nome do comando.
 {
	if (auxR.tamx < MAXTAMX && auxR.tamy < MAXTAMY && auxR.tamx > 0 && auxR.tamy > 0)	// O rectângulo só pode ter valores inteiros positivos, menores que a dimensão máxima.
	{
		if (auxR.roda == 's' || auxR.roda == 'n')	// O argumento roda só pode tomar os valores 's' ou 'n'.
		{
			if (procuraRectangulo(auxR.nome, pilha) == NULL)	// O rectângulo não pode ser encontrado na pilha de rectângulos.
			{
				if (!rectangulosCheia(pilha))	// A pilha de rectângulos não pode estar cheia.
				{
				auxR.rodado = 'n';	// Como ainda não foi colocado, também não foi rodado.
				auxR.coordx = -1; auxR.coordy = -1; // À posição inicial atribuiu-se (-1,-1) para ficar fora da àrea de trabalho, 
									// pois iria entrar em conflito com as colocações de outros rectângulos.
				pilha->rectangulos[pilha->stackPtr] = auxR;	// Coloca na stack.
				pilha->stackPtr++;	// Incrementa o stack pointer.
				return 1;
				}
			}  else mensagem_de_erro(E_JA_EXISTE);	// Caso encontre o rectângulo na pilha, erro, pois o rectângulo já existe.
		} else mensagem_de_erro(E_INVARGS);	// Caso 'roda' tome valores diferentes dos estipulados, erro de argumentos inválidos.
	} else mensagem_de_erro(E_DIM);	// Caso as dimensões não estejam dentro dos parâmetros, erro de dimensões.
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 4, erro de argumentos.
 return 0; 
* \endcode 
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b RECT. */
/** \param pilha em que vai ser inserido o rectângulo. */		
}

int colocaRectangulo(char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas, char rodando)
{
	rectangulo *auxR, auxRR;
	int auxInt;

	if (sscanf(linha, "%*s %s %d %d", auxRR.nome, &auxRR.coordx, &auxRR.coordy) == 3)
	{
		if (auxRR.coordx > 0 && auxRR.coordy > 0)
		{
			if (pAreas->stackPtr != 0)
			{
				auxR = procuraRectangulo(auxRR.nome, pRects);
				if (auxR != NULL)
				{
					auxRR.tamx = auxR->tamx;
					auxRR.tamy = auxR->tamy;
					auxRR.rodado = auxR->rodado;
	
					if (podeColocar(&auxRR, pRects, pAreas))
					{
						if (rodando == 's')
						{
							if (auxR->roda == 's')
							{
								if (auxR->rodado == 'n')
								{
									auxInt = auxR->tamx;
									auxR->tamx = auxR->tamy;
									auxR->tamy = auxInt;
									auxR->rodado = 's';
								}
							auxR->coordx = auxRR.coordx;
							auxR->coordy = auxRR.coordy;
							} else mensagem_de_erro(E_ROD);
						}
						else
						{
							if (auxR->rodado == 's')
							{
								auxInt = auxR->tamx;
								auxR->tamx = auxR->tamy;
								auxR->tamy = auxR->tamx;
							}
							auxR->coordx = auxRR.coordx;
							auxR->coordy = auxRR.coordy;
						}
						return 1;
					} else mensagem_de_erro(E_SOBREP);
				} else mensagem_de_erro(E_NO_DIM);
			} else mensagem_de_erro(E_NAO_EXISTE);
		} else mensagem_de_erro(E_DIM);
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 rectangulo *auxR, auxRR;
 int auxInt;
 
 if (sscanf(linha, "%*s %s %d %d", auxRR.nome, &auxRR.coordx, &auxRR.coordy) == 3)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR = procuraRectangulo(auxRR.nome, pRects);	// Procura na pilha de rectângulos o rectâgulo que se pretende colocar.
	if (auxR != NULL)	// Tem que o enctontrar, senão não existe nenhum rectângulo com esse nome.
	{
		auxRR.tamx = auxR->tamx;
		auxRR.tamy = auxR->tamy;
		auxRR.rodado = auxR->rodado;
 
		if (podeColocar(&auxRR, pRects, pAreas))	// Tem de poder colocar o rectângulo na àrea de trabalho.
		{
			if (rodando == 's')	// Caso o comando seja COLR...
			{
				if (auxR->roda == 's')	// ...se o rectângulo pode ser rodado...
				{
					if (auxR->rodado == 'n')	// ...se ainda não foi rodado...
					{
						auxInt = auxR->tamx;	// ...troca-se a coordenada horizontal pela vertical e vice-versa...
						auxR->tamx = auxR->tamy;
						auxR->tamy = auxInt;
						auxR->rodado = 's'; // ...e passa a estar rodado.
					}
					auxR->coordx = auxRR.coordx;
					auxR->coordy = auxRR.coordy;
				} else mensagem_de_erro(E_ROD);	// Caso o rectângulo não possa ser rodado, erro, pois não pode rodar.
			}
			else	// Caso o comando seja COL...
			{
				if (auxR->rodado == 's')	// ...se já foi rodado...
				{
					auxInt = auxR->tamx;	// ...troca-se a coordenada horizontal pela vertical e vice-versa...
					auxR->tamx = auxR->tamy;
					auxR->tamy = auxInt;	//...e deixa de estar rodado.
				}
				auxR->coordx = auxRR.coordx;
				auxR->coordy = auxRR.coordy;
			}
			return 1;
		} else mensagem_de_erro(E_SOBREP);	// Caso não possa colocar o rectângulo, erro de sobreposição.
	} else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre o rectângulo na pilha, erro, pois não existe rectângulo.
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 3, erro de argumentos.
 return 0; 
 * \endcode 
*/ 	

/** \param linha linha que vai ser lida e corresponde, neste caso, ao comando \b COL ou \b COLR. */	
/** \param pRects que é a pilha onde se encontra o rectângulo. */	
/** \param pAreas que é a pilha onde se encontra a àrea de trabalho. */	
/** \param rodando que toma o valor 's' ou 'n' caso o comando utilizado seja \b COLR ou \b COL, respectivamente. */		
}

int rectangulosVazia(pilhaRectangulos *pilha)
{
	if (pilha->stackPtr == 0) return 1;
	else return 0;
/** \code
 if (pilha->stackPtr == 0) return 1;	// Se o stack pointer está a 0, a pilha não tem elementos.
 else return 0;	
* \endcode 
*/ 

/** \param pilha que vai ser sujeita ao teste. */		
}

int rectangulosCheia(pilhaRectangulos *pilha)
{
	if (pilha->stackPtr >= MAXRECTANGULOS) return 1;
	else return 0;
/** \code
 if (pilha->stackPtr >= MAXRECTANGULOS) return 1;	// Se o stack pointer da pilha for maior ou igual ao número máximo de rectâgulos, a pilha está cheia.
 else return 0;
* \endcode 
*/ 

/** \param pilha que vai ser sujeita ao teste.  */	
}

rectangulo* procuraRectangulo(char *nome, pilhaRectangulos *pilha)
{
	int i;
	
	for (i=0; i<pilha->stackPtr; i++)
	{
		if (!strcmp(pilha->rectangulos[i].nome, nome)) return &pilha->rectangulos[i];
	}
	return NULL;
/** \code
 int i;
 for (i=0; i<pilha->stackPtr; i++)	// Percorre a pilha de rectângulos.
 {
	if (!strcmp(pilha->rectangulos[i].nome, nome)) return &pilha->rectangulos[i];	// Se encontrar o mesmo nome na pilha, devolve o rectângulo correpondente.
 }
 return NULL;	// Caso não encontre, retorna NULL para ser usado noutras funções.
* \endcode 
*/
 
/** \param nome do rectângulo que vai procurar.*/
/** \param pilha em que o vai procurar.*/		
}

int podeColocar(rectangulo *rectangulo, pilhaRectangulos *pRect, pilhaAreas *pAreas)
{
	int i;
	
	if (areasVazia(pAreas)) return 0;

	if ((rectangulo->coordx + rectangulo->tamx) > pAreas->areas[0].tamx) return 0;
	if ((rectangulo->coordy + rectangulo->tamy) > pAreas->areas[0].tamy) return 0;
	
	for (i=0; i<pRect->stackPtr; i++)
	{
		if (strcmp(pRect->rectangulos[i].nome,rectangulo->nome) != 0 && pRect->rectangulos[i].coordx != -1)
		{
			if (rectangulo->coordx >= (pRect->rectangulos[i].coordx + pRect->rectangulos[i].tamx)) continue;
			if (rectangulo->coordy >= (pRect->rectangulos[i].coordy + pRect->rectangulos[i].tamy)) continue;
			if ((rectangulo->coordx + rectangulo->tamx) <= pRect->rectangulos[i].coordx) continue;
			if ((rectangulo->coordy + rectangulo->tamy) <= pRect->rectangulos[i].coordy) continue;
			return 0;
		}
	}
	return 1;
/** \code
 int i;
 
 if (areasVazia(pAreas)) return 0;	// Se a pilha de àreas está vazia, a àrea de trabalho não está definida.
 
 if ((rectangulo->coordx + rectangulo->tamx) > pAreas->areas[0].tamx) return 0;	// O rectângulo tem que caber na àrea de trabalho horizontalmente...
 if ((rectangulo->coordy + rectangulo->tamy) > pAreas->areas[0].tamy) return 0;	// ...e também verticalmente.

 
 for (i=0; i<pRect->stackPtr; i++)	// Percorre a pilha de rectângulos.
 {
	if (strcmp(pRect->rectangulos[i].nome,rectangulo->nome) != 0)	// Caso encontre um rectângulo diferente, vai fazer o teste de sobreposição...
	{
		if (rectangulo->coordx >= (pRect->rectangulos[i].coordx + pRect->rectangulos[i].tamx)) continue;	// ...à direita...
		if (rectangulo->coordy >= (pRect->rectangulos[i].coordy + pRect->rectangulos[i].tamy)) continue;	// ...em baixo...
		if ((rectangulo->coordx + rectangulo->tamx) <= pRect->rectangulos[i].coordx) continue;	// ...à esquerda...
		if ((rectangulo->coordy + rectangulo->tamy) <= pRect->rectangulos[i].coordy) continue;	// ...e em cima.
		return 0;
	}
 }
 return 1;
* \endcode 
*/

/** \param rectangulo que vai ser sujeito ao teste. */
/** \param pRect que é a pilha onde está o rectângulo. */	
/** \param pAreas que é a pilha onde está a àrea de trabalho. */		
}

int listaRectangulos(pilhaRectangulos *pilha)
{
	int i, trocado=1;
	rectangulo auxR;
	
	if (pilha->stackPtr == 0) return 0;

	while (trocado == 1)
	{
		trocado = 0;
		for(i=0; i<pilha->stackPtr-1; i++)
		{
			if (strcmp(pilha->rectangulos[i].nome, pilha->rectangulos[i+1].nome) > 0)
			{
				trocado = 1;
				auxR = pilha->rectangulos[i];
				pilha->rectangulos[i] = pilha->rectangulos[i+1];
				pilha->rectangulos[i+1] = auxR;
			}
		}
	}
	
	for(i=0; i<pilha->stackPtr; i++)
	{
		if (pilha->rectangulos[i].coordx != -1) printf("%s %d %d %d %d\n", pilha->rectangulos[i].nome, pilha->rectangulos[i].coordx, pilha->rectangulos[i].coordy, pilha->rectangulos[i].coordx + pilha->rectangulos[i].tamx, pilha->rectangulos[i].coordy + pilha->rectangulos[i].tamy);
	}

/** \code
int i, trocado=1;
rectangulo auxR;

if (pilha->stackPtr == 0) return 0;	// A pilha tem de conter elementos.

	// Algoritmo de ordenação por "troca directa". Na próxima etapa, um quickSort.
while (trocado == 1)
{
	trocado = 0;
	for(i=0; i<pilha->stackPtr-1; i++)	// Percorre a pilha de rectângulos...
	{
		if (strcmp(pilha->rectangulos[i].nome, pilha->rectangulos[i+1].nome) > 0)
		{
			trocado = 1;
			auxR = pilha->rectangulos[i];
			pilha->rectangulos[i] = pilha->rectangulos[i+1];
			pilha->rectangulos[i+1] = auxR;
		}
	}
}

for(i=0; i<pilha->stackPtr; i++)	// Percorre a pilha de rectângulos.
{
	if (pilha->rectangulos[i].coordx != -1)	// Enquanto não listar o último...
	printf("%s %d %d %d %d\n",	// ...imprime no formato desejado...
	pilha->rectangulos[i].nome, pilha->rectangulos[i].coordx, pilha->rectangulos[i].coordy, pilha->rectangulos[i].coordx + pilha->rectangulos[i].tamx,
	pilha->rectangulos[i].coordy + pilha->rectangulos[i].tamy);	// ...as variáveis que compoêm o rectângulo e a sua colocação.
}
* \endcode 
*/
/** \param pilha de rectângulos que vão ser listados.  */	

	return 1;	
}