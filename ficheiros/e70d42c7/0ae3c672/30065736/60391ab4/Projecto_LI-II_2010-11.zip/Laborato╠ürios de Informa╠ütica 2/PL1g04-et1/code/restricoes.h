#ifndef M_RESTRICOES
#define M_RESTRICOES

int estaDireita(char *linha, pilhaRectangulos *pilha);
/*!< Função que testa se um rectângulo está à direita de outro. \n Esta função é chamada quando é utilizado o comando \b DIR. */
int estaEsquerda(char *linha, pilhaRectangulos *pilha);
/*!< Função que testa se um rectângulo está à esquerda de outro. \n Esta função é chamada quando é utilizado o comando \b ESQ. */
int estaCima(char *linha, pilhaRectangulos *pilha);
/*!< Função que testa se um rectângulo está em cima de outro. \n Esta função é chamada quando é utilizado o comando \b CIM. */
int estaBaixo(char *linha, pilhaRectangulos *pilha);
/*!< Função que testa se um rectângulo está em baixo de outro. \n Esta função é chamada quando é utilizado o comando \b BX. */
int estaColado(char *linha, pilhaRectangulos *pilha);
/*!< Função que testa se um rectângulo está colado a outro.\n  Esta função é chamada quando é utilizado o comando \b CLD. */
int estaSeparado(char *linha, pilhaRectangulos *pilha);
/*!< Função que testa se um rectângulo está separado de outro. \n Esta função é chamada quando é utilizado o comando \b SEP. */
int estaDentro(char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas);
/*!< Função que testa se um rectângulo está completamente dentro de uma dada àrea. \n Esta função é chamada quando é utilizado o comando \b DENTRO. */
int estaFora(char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas);
/*!< Função que testa se um rectângulo está completamente fora de uma dada àrea. \n Esta função é chamada quando é utilizado o comando \b FORA. */
#endif
