#include "erro.h"
#include "stackRectangulos.h"
#include "stackAreas.h"
#include <stdio.h>

int estaDireita(char *linha, pilhaRectangulos *pilha)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1, *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pilha);
		auxR2 = procuraRectangulo(nome2, pilha);

		if (auxR1 != NULL && auxR2 != NULL)
		{
			if (auxR1->coordx >= (auxR2->coordx + auxR2->tamx)) return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1, *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pilha);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraRectangulo(nome2, pilha);	// Recolhe o rectângulo com nome2.
 
	if (auxR1 != NULL && auxR2 != NULL)	// Ambos os rectângulos têm de ser encontrados na pilha.
	{
		if (auxR1->coordx >= (auxR2->coordx + auxR2->tamx))	return 1;	// Se estiver à direita, retorna 1 (True).
	} else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre ambos os rectângulos, erro, pois o(s) rectângulo(s) não existe(m). 
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b DIR. */
/** \param pilha de rectângulos onde estão os rectângulos pretendidos para o teste. */

}

int estaEsquerda(char *linha, pilhaRectangulos *pilha)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1, *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pilha);	
		auxR2 = procuraRectangulo(nome2, pilha);

		if (auxR1 != NULL && auxR2 != NULL)
		{
			if ((auxR1->coordx + auxR1->tamx) <= auxR2->coordx) return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1, *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pilha);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraRectangulo(nome2, pilha);	// Recolhe o rectângulo com nome2.
 
	if (auxR1 != NULL && auxR2 != NULL)	// Ambos os rectângulos têm de ser encontrados na pilha.
	{
		if ((auxR1->coordx + auxR1->tamx) <= auxR2->coordx) return 1;	// Se estiver à esquerda, retorna 1 (True).
	} else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre ambos os rectângulos, erro, pois o(s) rectângulo(s) não existe(m).
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b ESQ. */
/** \param pilha de rectângulos onde estão os rectângulos pretendidos para o teste. */
}

int estaCima(char *linha, pilhaRectangulos *pilha)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1, *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pilha);
		auxR2 = procuraRectangulo(nome2, pilha);

		if (auxR1 != NULL && auxR2 != NULL)
		{
			if ((auxR1->coordy + auxR1->tamy) <= auxR2->coordy) return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1, *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pilha);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraRectangulo(nome2, pilha);	// Recolhe o rectângulo com nome2.
 
	if (auxR1 != NULL && auxR2 != NULL)	// Ambos os rectângulos têm de ser encontrados na pilha.
	{
		if ((auxR1->coordy + auxR1->tamy) <= auxR2->coordy) return 1;	// Se estiver em cima, retorna 1 (True).
	} else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre ambos os rectângulos, erro, pois o(s) rectângulo(s) não existe(m).
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b CIM. */
/** \param pilha de rectângulos onde estão os rectângulos pretendidos para o teste. */
}

int estaBaixo(char *linha, pilhaRectangulos *pilha)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1, *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pilha);
		auxR2 = procuraRectangulo(nome2, pilha);

		if (auxR1 != NULL && auxR2 != NULL)
		{
			if (auxR1->coordy >= (auxR2->coordy + auxR2->tamy)) return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1, *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pilha);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraRectangulo(nome2, pilha);	// Recolhe o rectângulo com nome2.
 
	if (auxR1 != NULL && auxR2 != NULL)	// Ambos os rectângulos têm de ser encontrados na pilha.
	{
		if (auxR1->coordy >= (auxR2->coordy + auxR2->tamy)) return 1;	// Se estiver em baixo, retorna 1 (True).
	} else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre ambos os rectângulos, erro, pois o(s) rectângulo(s) não existe(m).
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b BX. */
/** \param pilha de rectângulos onde estão os rectângulos pretendidos para o teste. */
}

int estaColado(char *linha, pilhaRectangulos *pilha)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1, *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pilha);
		auxR2 = procuraRectangulo(nome2, pilha);

		if (auxR1 != NULL && auxR2 != NULL)
		{
			if (((auxR1->coordx + auxR1->tamx) == auxR2->coordx) && ((auxR1->coordy <= auxR2->coordy+auxR2->tamy && auxR1->coordy >= auxR2->coordy) || (auxR1->coordy+auxR1->tamy <= auxR2->coordy+auxR2->tamy && auxR1->coordy+auxR1->tamy >= auxR2->coordy))) return 1;
			if (((auxR1->coordy + auxR1->tamy) == auxR2->coordy) && ((auxR1->coordx <= auxR2->coordx+auxR2->tamx && auxR1->coordx >= auxR2->coordx) || (auxR1->coordx+auxR1->tamx <= auxR2->coordx+auxR2->tamx && auxR1->coordx+auxR1->tamx >= auxR2->coordx))) return 1;
			if ((auxR1->coordx == (auxR2->coordx + auxR2->tamx)) && ((auxR1->coordy <= auxR2->coordy+auxR2->tamy && auxR1->coordy >= auxR2->coordy) || (auxR1->coordy+auxR1->tamy <= auxR2->coordy+auxR2->tamy && auxR1->coordy+auxR1->tamy >= auxR2->coordy))) return 1;
			if ((auxR1->coordy == (auxR2->coordy + auxR2->tamy)) && ((auxR1->coordx <= auxR2->coordx+auxR2->tamx && auxR1->coordx >= auxR2->coordx) || (auxR1->coordx+auxR1->tamx <= auxR2->coordx+auxR2->tamx && auxR1->coordx+auxR1->tamx >= auxR2->coordx))) return 1;
			
			if (((auxR2->coordx + auxR2->tamx) == auxR1->coordx) && ((auxR2->coordy <= auxR1->coordy+auxR1->tamy && auxR2->coordy >= auxR1->coordy) || (auxR2->coordy+auxR2->tamy <= auxR1->coordy+auxR1->tamy && auxR2->coordy+auxR2->tamy >= auxR1->coordy))) return 1;
			if (((auxR2->coordy + auxR2->tamy) == auxR1->coordy) && ((auxR2->coordx <= auxR1->coordx+auxR1->tamx && auxR2->coordx >= auxR1->coordx) || (auxR2->coordx+auxR2->tamx <= auxR1->coordx+auxR1->tamx && auxR2->coordx+auxR2->tamx >= auxR1->coordx))) return 1;
			if ((auxR2->coordx == (auxR1->coordx + auxR1->tamx)) && ((auxR2->coordy <= auxR1->coordy+auxR1->tamy && auxR2->coordy >= auxR1->coordy) || (auxR2->coordy+auxR2->tamy <= auxR1->coordy+auxR1->tamy && auxR2->coordy+auxR2->tamy >= auxR1->coordy))) return 1;
			if ((auxR2->coordy == (auxR1->coordy + auxR1->tamy)) && ((auxR2->coordx <= auxR1->coordx+auxR1->tamx && auxR2->coordx >= auxR1->coordx) || (auxR2->coordx+auxR2->tamx <= auxR1->coordx+auxR1->tamx && auxR2->coordx+auxR2->tamx >= auxR1->coordx))) return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1, *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pilha);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraRectangulo(nome2, pilha);	// Recolhe o rectângulo com nome2.
 
	 if (auxR1 != NULL && auxR2 != NULL)	// Ambos os rectângulos têm de ser encontrados na pilha.
	 {
		// Aqui utilizou-se a "força bruta" para verficar a restrição. A mudar na próxima etapa!
		if (((auxR1->coordx + auxR1->tamx) == auxR2->coordx) && ((auxR1->coordy <= auxR2->coordy+auxR2->tamy && auxR1->coordy >= auxR2->coordy) || (auxR1->coordy+auxR1->tamy <= auxR2->coordy+auxR2->tamy && auxR1->coordy+auxR1->tamy >= auxR2->coordy))) return 1;
		if (((auxR1->coordy + auxR1->tamy) == auxR2->coordy) && ((auxR1->coordx <= auxR2->coordx+auxR2->tamx && auxR1->coordx >= auxR2->coordx) || (auxR1->coordx+auxR1->tamx <= auxR2->coordx+auxR2->tamx && auxR1->coordx+auxR1->tamx >= auxR2->coordx))) return 1;
		if ((auxR1->coordx == (auxR2->coordx + auxR2->tamx)) && ((auxR1->coordy <= auxR2->coordy+auxR2->tamy && auxR1->coordy >= auxR2->coordy) || (auxR1->coordy+auxR1->tamy <= auxR2->coordy+auxR2->tamy && auxR1->coordy+auxR1->tamy >= auxR2->coordy))) return 1;
		if ((auxR1->coordy == (auxR2->coordy + auxR2->tamy)) && ((auxR1->coordx <= auxR2->coordx+auxR2->tamx && auxR1->coordx >= auxR2->coordx) || (auxR1->coordx+auxR1->tamx <= auxR2->coordx+auxR2->tamx && auxR1->coordx+auxR1->tamx >= auxR2->coordx))) return 1;
		
		if (((auxR2->coordx + auxR2->tamx) == auxR1->coordx) && ((auxR2->coordy <= auxR1->coordy+auxR1->tamy && auxR2->coordy >= auxR1->coordy) || (auxR2->coordy+auxR2->tamy <= auxR1->coordy+auxR1->tamy && auxR2->coordy+auxR2->tamy >= auxR1->coordy))) return 1;
		if (((auxR2->coordy + auxR2->tamy) == auxR1->coordy) && ((auxR2->coordx <= auxR1->coordx+auxR1->tamx && auxR2->coordx >= auxR1->coordx) || (auxR2->coordx+auxR2->tamx <= auxR1->coordx+auxR1->tamx && auxR2->coordx+auxR2->tamx >= auxR1->coordx))) return 1;
		if ((auxR2->coordx == (auxR1->coordx + auxR1->tamx)) && ((auxR2->coordy <= auxR1->coordy+auxR1->tamy && auxR2->coordy >= auxR1->coordy) || (auxR2->coordy+auxR2->tamy <= auxR1->coordy+auxR1->tamy && auxR2->coordy+auxR2->tamy >= auxR1->coordy))) return 1;
		if ((auxR2->coordy == (auxR1->coordy + auxR1->tamy)) && ((auxR2->coordx <= auxR1->coordx+auxR1->tamx && auxR2->coordx >= auxR1->coordx) || (auxR2->coordx+auxR2->tamx <= auxR1->coordx+auxR1->tamx && auxR2->coordx+auxR2->tamx >= auxR1->coordx))) return 1;
	 } else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre ambos os rectângulos, erro, pois o(s) rectângulo(s) não existe(m).
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b CLD. */
/** \param pilha de rectângulos onde estão os rectângulos pretendidos para o teste. */
}

int estaSeparado(char *linha, pilhaRectangulos *pilha)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1, *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pilha);
		auxR2 = procuraRectangulo(nome2, pilha);

		if (auxR1 != NULL && auxR2 != NULL)
		{
			if ((auxR1->coordx + auxR1->tamx) == auxR2->coordx) return 0;
			if ((auxR1->coordy + auxR1->tamy) == auxR2->coordy) return 0;
			if (auxR1->coordx == (auxR2->coordx + auxR2->tamx)) return 0;
			if (auxR1->coordy == (auxR2->coordy + auxR2->tamy)) return 0;
			return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 1;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1, *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pilha);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraRectangulo(nome2, pilha);	// Recolhe o rectângulo com nome2.
 
	if (auxR1 != NULL && auxR2 != NULL)	// Ambos os rectângulos têm de ser encontrados na pilha.
	{
		if ((auxR1->coordx + auxR1->tamx) == auxR2->coordx) return 0;	// Se tiverem algum dos lados em comum, então estão colados, logo não estão separados.
		if ((auxR1->coordy + auxR1->tamy) == auxR2->coordy) return 0;
		if (auxR1->coordx == (auxR2->coordx + auxR2->tamx)) return 0;
		if (auxR1->coordy == (auxR2->coordy + auxR2->tamy)) return 0;
		return 1;	// Caso contrário, estão separados.
	} else mensagem_de_erro(E_NAO_EXISTE);	// Caso não encontre ambos os rectângulos, erro, pois o(s) rectângulo(s) não existe(m).
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b SEP. */
/** \param pilha de rectângulos onde estão os rectângulos pretendidos para o teste. */
}

int estaDentro(char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1;
	area *auxR2;

	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pRects);
		auxR2 = procuraArea(nome2, pAreas);

		if (auxR1 != NULL)
		{
			if (auxR2 != NULL)
			{
				if (auxR1->coordx >= auxR2->coordx && auxR1->coordy >= auxR2->coordy && (auxR1->coordx + auxR1->tamx) <= (auxR2->coordx + auxR2->tamx) && (auxR1->coordy + auxR1->tamy) <= (auxR2->coordy + auxR2->tamy)) return 1;
			} else mensagem_de_erro(E_NO_DIM);
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;
/** \code
 char nome1[50], nome2[50];
 rectangulo *auxR1;
 area *auxR2;
 
 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
 {
	auxR1 = procuraRectangulo(nome1, pRects);	// Recolhe o rectângulo com nome1.
	auxR2 = procuraArea(nome2, pAreas);	// Recolhe a àrea com o nome2.
 
	if (auxR1 != NULL)	// O rectângulo tem de ser encontrado na pilha.
	{
		if (auxR2 != NULL)	// A àrea tem de ser encontrada na pilha.
		{
			if (auxR1->coordx >= auxR2->coordx && auxR1->coordy >= auxR2->coordy && (auxR1->coordx + auxR1->tamx) <= 
				(auxR2->coordx + auxR2->tamx) && (auxR1->coordy + auxR1->tamy) <= (auxR2->coordy + auxR2->tamy))
			return 1;	// Se estiver completamente dentro, retorna 1 (True).
		} else mensagem_de_erro(E_NO_DIM);	// Caso não encontre a àrea na pilha, erro, pois a àrea ainda não foi inicializada.
	} else mensagem_de_erro(E_NAO_EXISTE);		// Caso não encontre o rectângulo na pilha, erro, pois o rectângulo não existe.
 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b DENTRO. */
/** \param pRects que é a pilha de rectângulos onde está o rectângulo pretendido para o teste. */
/** \param pAreas que é a pilha de àreas onde está a àrea pretendida para o teste. */
}

int estaFora(char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas)
{
	char nome1[50], nome2[50];
	rectangulo *auxR1;
	area *auxR2;
	
	if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)
	{
		auxR1 = procuraRectangulo(nome1, pRects);
		auxR2 = procuraArea(nome2, pAreas);
		
		if (auxR1 != NULL)
		{
			if (auxR2 != NULL)
			{
				if (auxR1->coordx >= (auxR2->coordx + auxR2->tamx)) return 1;
				if (auxR1->coordy >= (auxR2->coordy + auxR2->tamy)) return 1;
				if ((auxR1->coordx+auxR1->tamx) <= auxR2->coordx) return 1;
				if ((auxR1->coordy+auxR1->tamy) <= auxR2->coordy) return 1;
			} else mensagem_de_erro(E_NO_DIM);
		} else mensagem_de_erro(E_NAO_EXISTE);	
	} else mensagem_de_erro(E_ARGS);
	return 0;

	/** \code
	 char nome1[50], nome2[50];
	 rectangulo *auxR1;
	 area *auxR2;
	 
	 if (sscanf(linha, "%*s %s %s", nome1, nome2) == 2)	// Recebe os argumentos, ignorando o nome do comando.
	 {
		auxR1 = procuraRectangulo(nome1, pRects);	// Recolhe o rectângulo com nome1.
		auxR2 = procuraArea(nome2, pAreas);	// Recolhe a àrea com o nome2.
	 
		if (auxR1 != NULL)	// O rectângulo tem de ser encontrado na pilha.
		{
			if (auxR2 != NULL)	// A àrea tem de ser encontrada na pilha.
			{
				if (auxR1->coordx >= (auxR2->coordx + auxR2->tamx)) return 1;
				if (auxR1->coordy >= (auxR2->coordy + auxR2->tamy)) return 1;
				if ((auxR1->coordx+auxR1->tamx) <= auxR2->coordx) return 1;
				if ((auxR1->coordy+auxR1->tamy) <= auxR2->coordy) return 1;
				// Se estiver completamente fora, retorna 1 (True).
			} else mensagem_de_erro(E_NO_DIM);	// Caso não encontre a àrea na pilha, erro, pois a àrea ainda não foi inicializada.
		} else mensagem_de_erro(E_NAO_EXISTE);		// Caso não encontre o rectângulo na pilha, erro, pois o rectângulo não existe.
	 } else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
	 return 0;	// Retorna 0 (False), caso algumas destas condições falhe.
	 * \endcode
	 */
	
	/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b FORA. */
	/** \param pRects que é a pilha de rectângulos onde está o rectângulo pretendido para o teste. */
	/** \param pAreas que é a pilha de àreas onde está a àrea pretendida para o teste. */
}