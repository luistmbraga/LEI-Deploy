/** Tudo normal. */
#define E_NOERR		 0
/** Comando não existe. */
#define E_COMANDO	 1
/** Erro de argumentos a mais ou a menos. */
#define E_ARGS		 2
/** A àrea ainda não foi inicializada. */
#define E_NO_DIM	 3
/** Erro de dimensões. */
#define E_DIM		 4
/** Não existe. */
#define E_NAO_EXISTE 5	
/** Já existe. */
#define E_JA_EXISTE	 6	
/** Rectangulo não colocado. */
#define E_COL		 7	
/** Rectangulo não pode rodar. */
#define E_ROD		 8	
/** Colocado fora. */
#define E_FORA		 9
/** Rectangulo sobreposto a outro. */
#define E_SOBREP	10	
/** Argumentos inválidos. */
#define E_INVARGS	11	
/** Violacao de restricões. */
#define E_RESTR		12	
/** Não há solucão. */
#define E_NOSOL		13	

/**
* Reporta o erro escrevendo uma mensagem no standard error
* \param erro_num O número do erro que vem da tabela de erros. Usar SEMPRE o define e não o valor numérico para maior legibilidade.
*/
int mensagem_de_erro(int erro_num);
