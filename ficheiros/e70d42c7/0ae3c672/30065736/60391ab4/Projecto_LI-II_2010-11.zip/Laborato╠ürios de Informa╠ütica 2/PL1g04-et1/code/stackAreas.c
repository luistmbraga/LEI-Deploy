#include <stdio.h>
#include <string.h>
#include "stackAreas.h"
#include "erro.h"

int areasInit(pilhaAreas *pilha)
{
	pilha->stackPtr = 0;
	return 1;

/** \code
 pilha->stackPtr = 0; // Basta inicializar o stack pointer a 0. 
 return 1;
* \endcode
*/

/** \param pilha que vai ser criada com o nome que lhe for dado aqui. */
 
}

int areasVazia(pilhaAreas *pilha)
{
	if (pilha->stackPtr == 0) return 1;
	else return 0;
/** \code
 if (pilha->stackPtr == 0) return 1;	// Se o stack pointer está a 0, a pilha não tem elementos.
 else return 0;
* \endcode
*/

/** \param pilha que vai ser sujeita ao teste. */	
}

int areasCheia(pilhaAreas *pilha)
{
	if (pilha->stackPtr >= MAXAREAS) return 1;
	else return 0;
/** \code
 if (pilha->stackPtr >= MAXAREAS) return 1;	// Se o stack pointer da pilha for maior ou igual ao número máximo de àreas, a pilha está cheia.
 else return 0; 
* \endcode
*/

/** \param pilha que vai ser sujeita ao teste. */	
}

int adicionaArea(char *linha, pilhaAreas *pilha)
{
	area auxA;
	char escolha[5];
	sscanf(linha, "%s", escolha);
	if (strcmp(escolha,"DIM") == 0)
	{
		if (sscanf(linha, "%*s %d %d", &auxA.tamx, &auxA.tamy) == 2)
		{
			if (areasVazia(pilha))
			{
				if (auxA.tamx > 0 && auxA.tamy > 0 && auxA.tamx <= MAXTAMX && auxA.tamy <= MAXTAMY)
				{
					auxA.tamx++; auxA.tamy++;
					strcpy(auxA.nome, "DIM"); auxA.coordx = 1; auxA.coordy = 1;
					pilha->areas[pilha->stackPtr] = auxA;
					pilha->stackPtr++;
					return 1;
				} else mensagem_de_erro(E_DIM);
			}
		} else mensagem_de_erro(E_ARGS);
	}
	else
	{
		if (sscanf(linha, "%*s %s %d %d %d %d", auxA.nome, &auxA.coordx, &auxA.coordy, &auxA.tamx, &auxA.tamy) == 5)
		{
			if (!areasVazia(pilha))
			{
				if (auxA.tamx > 0 && auxA.tamy > 0 && auxA.tamx <= MAXTAMX && auxA.tamy <= MAXTAMY)
				{
					pilha->areas[pilha->stackPtr] = auxA;
					pilha->stackPtr++;
					return 1;
				} else mensagem_de_erro(E_DIM);
			}  else mensagem_de_erro(E_NO_DIM);
		} else mensagem_de_erro(E_ARGS);
	}
	return 0;
/** \code
 area auxA;
 char escolha[5];
 sscanf(linha, "%s", escolha);	// Recolhe a primeira palavra do comando, ou seja, o nome do comando.
 if (strcmp(escolha,"DIM") == 0)	// Se for DIM...
 {
	if (sscanf(linha, "%*s %d %d", &auxA.tamx, &auxA.tamy) == 2)	// Recebe os argumentos, ignorando o nome do comando.
	{
		if (areasVazia(pilha))	// A pilha de àreas tem de estar vazia pois a àrea de trabalho principal é o seu primeiro elemento.
		{
			if (auxA.tamx > 0 && auxA.tamy > 0 && auxA.tamx <= MAXTAMX && auxA.tamy <= MAXTAMY)	// A àrea só pode ter valores inteiros positivos, menores que a dimensão máxima.
			{			
				strcpy(auxA.nome, "DIM");	// Atribui o nome DIM.
				auxA.coordx = 1; auxA.coordy = 1;	// Posição inicial (1,1).
				pilha->areas[pilha->stackPtr] = auxA;	// Coloca na stack.
				pilha->stackPtr++;	// Incrementa o stack pointer.
				return 1;
			} else mensagem_de_erro(E_DIM);	// Caso as dimensões não estejam dentro dos parâmetros, erro de dimensões.
		}
	} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
 }
 else	// Se for AREA...
 {
	if (sscanf(linha, "%*s %s %d %d %d %d", auxA.nome, &auxA.coordx, &auxA.coordy, &auxA.tamx, &auxA.tamy) == 5)	// Recebe os argumentos, ignorando o nome do comando.
	{
		if (!areasVazia(pilha))	// Aqui, a pilha de àreas já não pode estar vazia pois a àrea de trabalho principal já foi definida.
		{
			if (auxA.tamx > 0 && auxA.tamy > 0 && auxA.tamx <= MAXTAMX && auxA.tamy <= MAXTAMY)	// A àrea só pode ter valores inteiros positivos, menores que a dimensão máxima.
			{
				pilha->areas[pilha->stackPtr] = auxA;	// Coloca na stack.
				pilha->stackPtr++;	// Incrementa o stack pointer.
				return 1;
			} else mensagem_de_erro(E_DIM); // Caso as dimensões não estejam dentro dos parâmetros, erro de dimensões.
		}  else mensagem_de_erro(E_NO_DIM);	// Caso ainda não haja àrea de trabalho principal, erro de falta de àrea de trabalho.
	} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 5, erro de argumentos.
 }
 return 0;
 
* \endcode
*/

/** \param linha que vai ser lida e corresponde, neste caso, ao comando \b DIM ou \b AREA.*/
/** \param pilha em que vai ser inserida a àrea. */
	
}

area* procuraArea(char *nome, pilhaAreas *pilha)
{
	int i;
	
	for (i=0; i<pilha->stackPtr; i++)
	{
		if (!strcmp(pilha->areas[i].nome, nome)) return &pilha->areas[i];
	}
	return NULL;
/** \code
 int i;
 
 for (i=0; i<pilha->stackPtr; i++)	// Percorre a pilha de àreas.
 {
	if (!strcmp(pilha->areas[i].nome, nome)) return &pilha->areas[i];	// Se encontrar o mesmo nome na pilha, devolve a àrea correpondente.
 }
 return NULL;	// Caso não encontre, retorna NULL para ser usado noutras funções.
* \endcode
*/

/** \param nome da àrea que vai procurar. */
/** \param plha em que a vai procurar. */	
}