#ifndef M_STACKAREAS
#define M_STACKAREAS

/*! Número máximo de àreas que se podem definir. 
 Nesta etapa optou-se por 100, àrea principal de trabalho incluìda. */
#define MAXAREAS 100
/*! O tamanho horizontal máximo de uma àrea é 100. */
#define MAXTAMX 100
/*! O tamanho vertical máximo de uma àrea é 100. */
#define MAXTAMY 100


typedef struct s_area
/** Uma àrea é composta por um nome, 
 * as coordenadas do seu canto inferior esquerdo,
 * o seu tamanho horizontal e o seu tamanho vertical.
 */
{
	int coordx, /*!< Abcissa do canto inferior esquerdo. */
	coordy, /*!< Ordenada do canto inferior esquerdo. */
	tamx, /*!< Tamanho horizontal. */
	tamy; /*!< Tamanho vertical. */
	char nome[50]; /*!< Nome da àrea. */
} area;

typedef struct s_pilhaAreas
/** A pilha de àreas é uma \a stack em que 
 * serão armazenadas as àreas. A àrea de trabalho principal é o primeiro elemento desta pilha. \n
 * Contém um array do tipo \a area com comprimento máximo \a MAXAREAS
 * e um \a stack \a pointer para indicar o número de elementos na pilha de àreas.
 */
{
	area areas[MAXAREAS]; /*!< Array que armazena àreas. */
	int stackPtr; /*!< Indica o número de elementos no array. */
} pilhaAreas;

int areasInit(pilhaAreas *pilha);
/*!< Função de criação da pilha que armazena àreas. */
int areasVazia(pilhaAreas *pilha);
/*!< Função que testa se a pilha de àreas está vazia. Retorna 1 (True), ou 0 (False). */
int areasCheia(pilhaAreas *pilha);
/*!< Função que testa se a pilha de àreas está cheia. Retorna 1 (True), ou 0 (False). */
int adicionaArea(char *linha, pilhaAreas *pilha);
/*!< Função que adiciona uma àrea à pilha de àreas. Esta função é chamada caso o comando
 utilizado seja \b DIM ou \b AREA.
 */
area* procuraArea(char *nome, pilhaAreas *pilha);
/*!< Função que procura na pilha de àreas por uma dada àrea. Caso encontre, retorna-a.*/

#endif