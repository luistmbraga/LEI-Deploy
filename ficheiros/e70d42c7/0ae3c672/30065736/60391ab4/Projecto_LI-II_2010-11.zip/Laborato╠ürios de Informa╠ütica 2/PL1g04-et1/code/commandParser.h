#ifndef M_COMMANDPARSER
#define COMMANDPARSER

void correrComando (char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas);
/*!< Função que lê um comando introduzido e executa a função correspondente. 
 \n Retorna 'SIM' ou 'NAO' conforme o resultado do comando. */

#endif