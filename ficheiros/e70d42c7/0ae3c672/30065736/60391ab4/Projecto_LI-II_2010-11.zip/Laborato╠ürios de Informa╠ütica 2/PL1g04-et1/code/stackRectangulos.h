#ifndef M_STACKRECTANGULOS
#define M_STACKRECTANGULOS

#include "stackAreas.h"

/*! Número máximo de àreas que se podem definir. */
#define MAXRECTANGULOS 100

typedef struct s_rectangulo
/** Um rectângulo é composto por um nome, 
 * as coordenadas do seu canto superior esquerdo,
 * o seu tamanho horizontal e o seu tamanho vertical.
 */
{
	int coordx, /*!< Abcissa do canto superior esquerdo. */
		coordy, /*!< Ordenada do canto superior esquerdo. */
		tamx, /*!< Tamanho horizontal. */
		tamy; /*!< Tamanho vertical. */
	char nome[50], /*!< Nome do rectângulo. */
		 roda, /*!< Toma o valor \a s ou \a n caso o retcângulo possa ou não ser rodado. */
		 rodado; /*!< Toma o valor \a s ou \a n caso o retcângulo tenha ou não sido rodado. */
} rectangulo;

typedef struct s_pilhaRectangulos
/** A pilha de rectângulos é uma \a stack em que 
 * serão armazenados os rectângulos. \n
 * Contém um array do tipo \a rectangulo com comprimento máximo \a MAXRECTANGULOS
 * e um \a stack \a pointer para indicar o número de elementos na pilha de rectângulos.
 */
{
	rectangulo rectangulos[MAXRECTANGULOS]; /*!< Array que armazena rectângulos. */
	int stackPtr; /*!< Indica o número de elementos no array. */
} pilhaRectangulos;

int rectangulosInit(pilhaRectangulos *pilha);
/*!< Função de criação da pilha que armazena rectângulos. */
int rectangulosVazia(pilhaRectangulos *pilha);
/*!< Função que testa se a pilha de rectângulos está vazia. Retorna 1 (True), ou 0 (False). */
int rectangulosCheia(pilhaRectangulos *pilha);
/*!< Função que testa se a pilha de rectângulos está cheia. Retorna 1 (True), ou 0 (False). */
int adicionaRectangulo(char *linha, pilhaRectangulos *pilha);
/*!< Função que adiciona um rectângulo à pilha de rectângulos. Esta função é chamada caso o comando utilizado seja \b RECT.*/
rectangulo* procuraRectangulo(char *nome, pilhaRectangulos *pilha);
/*!< Função que procura na pilha de rectângulos por um dado rectângulo. Caso encontre, retorna-o.*/
int podeColocar(rectangulo *rectangulo, pilhaRectangulos *pRect, pilhaAreas *pAreas);
/*!< Função que testa se se pode ou não colocar um rectângulo na àrea de trabalho. \n
 Retorna 1 (True), se todas as condições forem favoràveis, ou sai da função mal encontre 
 uma regra que não é cumprida retornando 0 (False). */
int colocaRectangulo(char *linha, pilhaRectangulos *pRects, pilhaAreas *pAreas, char rodando);
/*!< Função de colocação de rectângulos na àrea de trabalho. Esta função é chamada caso o comando utilizado seja \b COL ou \b COLR.*/
int listaRectangulos(pilhaRectangulos *pilha);
/*!< Função de listagem de rectângulos que estâo na pilha de rectângulos. Esta função é chamada caso o comando utilizado seja \b ESTADO. */

#endif