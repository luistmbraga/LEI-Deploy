#ifndef MOD_RECTANGULOS
#define MOD_RECTANGULOS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "erro.h"
#include "mod_areas.h"

typedef struct s_Rectangulo
/** Um rectângulo é composto por um nome, 
 * as coordenadas do seu canto superior esquerdo,
 * o seu tamanho horizontal e o seu tamanho vertical. \n
 * E ainda dois indicadores que dizem se um rectângulo pode ou não ser rodado e se está ou não rodado.
 */
{
	char *nome, /*!< Nome do rectângulo. */
	roda, /*!< Toma o valor \a s ou \a n caso o retcângulo possa ou não ser rodado. */
	rodado;	/*!< Toma o valor \a s ou \a n caso o rectângulo esteja ou não rodado. */
	int coordx, /*!< Abcissa do canto superior esquerdo. */
	coordy,  /*!< Ordenada do canto superior esquerdo. */
	tamx, /*!< Tamanho horizontal. */
	tamy; /*!< Tamanho vertical. */
} Rectangulo;

typedef struct s_pilhaRectangulos
/** A pilha de rectângulos é uma \a stack em que 
 * serão armazenados os rectângulos. \n
 * Contém um rectângulo e um apontador para o rectângulo seguinte.
*/
{
	Rectangulo rectangulo; /* Um rectângulo. */
	struct s_pilhaRectangulos *seg; /* Apontador para o rectângulo seguinte. */
} *pilhaRectangulos, n_pilhaRectangulos; /*!< \b pilhaRectangulos - nome do tipo \n \b n_pilhaRectangulos - nodo_pilhaRectangulos */

typedef struct s_Restricao
/** Uma restrição é composta pelo seu nome, o do comando, 
 * e dois argumentos.
 */
{
	char *cmd, /*!< Nome da restrição. */
	*arg1, /*!< Argumento 1. */
	*arg2; /*!< Argumento 2. */
} Restricao;

typedef struct s_pilhaRestricoes
/** A pilha de restrições é uma \a stack em que 
 * serão armazenadas as restrições. \n
 * Contém uma restrição e o apontador para a restrição seguinte.
 */
{
	Restricao restricao; /*!< Uma restrição. */
	struct s_pilhaRestricoes *seg; /*!< Apontador para a restrição seguinte. */
} *pilhaRestricoes, n_pilhaRestricoes; /*!< \b pilhaRestricoes - nome do tipo \n \b n_pilhaRestricoes - nodo_pilhaRestricoes */

typedef struct s_Undo
/** Um undo é um dos comandos que podem ser anulados. É composto pelo nome de comando, \n
 *  o nome da área ou rectângulo e as coordenadas de colocação.
 */
{
	char *cmd,  /*!< Nome do comando */
	*arg;  /*!< Nome da àrea ou rectângulo */
	int coordx, /*!< Abcissa do canto superior esquerdo se for rectângulo, inferior esquerdo, se for àrea. */
	coordy;	/*!< Ordenada do canto superior esquerdo se for rectângulo, inferior esquerdo, se for àrea. */
} Undo;

typedef struct s_pilhaUndo
/** A pilha de comandos que podem ser anulados é uma \a stack em que 
 * serão armazenadas os comandos. \n
 * Contém um comando e o apontador para a comando seguinte.
 */
{	
	Undo undo;	/*!< Um comando que pode ser anulado. */
	struct s_pilhaUndo *seg;	/*!< Apontador para a comando seguinte. */
} *pilhaUndo, n_pilhaUndo;	/*!< \b pilhaUndo - nome do tipo \n \b n_pilhaUndo - nodo_pilhaUndo */


pilhaRectangulos adicionaRectangulo(pilhaRectangulos _pilha, Rectangulo _rectangulo);
/*!< Função que adiciona um rectângulo à pilha de rectângulos. Esta função é chamada caso o comando utilizado seja \b RECT. Retorna a pilha. */
Rectangulo* procuraRectangulo(pilhaRectangulos _pilha, char *_nomeRectangulo);
/*!< Função que procura na pilha de rectângulos por um dado rectângulo. Caso encontre, retorna-o. */
int colocaRectangulo(pilhaRectangulos _pilha, char *_nomeRectangulo, int _coordx, int _coordy, char _rodando);
/*!< Função de colocação de rectângulos na àrea de trabalho. Esta função é chamada caso o comando utilizado seja \b COL ou \b COLR. \n 
 * Retorna 1 (True), caso tenha colocado e 0 (False), caso contrário.
 */
void listaRectangulos (pilhaRectangulos _pilha);
/*!< Função de listagem de rectângulos que estâo na pilha de rectângulos. Esta função é chamada caso o comando utilizado seja \b ESTADO. */
pilhaRestricoes adicionaRestricao(pilhaRestricoes _pilha, char *_cmd, char *_arg1, char *_arg2);
/*!< Função que adiciona uma restrição à pilha de restrições. Retorna a pilha. */
int verificaRestricao (pilhaRectangulos _pilhaRectangulos, pilhaAreas _pilhaAreas, Restricao _restricao);
/*!< Função que testa uma restrição quando se pretende adicionar uma restrição. Retorna 1 (True), ou 0 (False). */
int verificaRestricoes (pilhaRectangulos _pilhaRectangulos, pilhaAreas _pilhaAreas, pilhaRestricoes _pilhaRestricoes, char *_nomeRectangulo);
/*!< Função que testa uma restrição quando se pretende colocar um rectângulo. Retorna 1 (True), ou 0 (False). */
pilhaUndo adicionarUndo(pilhaUndo _pilha, char *_cmd, char *_arg, int _coordx, int _coordy);
/*!< Função que adiciona um comando à pilha de comandos que podem ser anulados. Retorna a pilha. */
int fazerUndo(pilhaRectangulos _pilhaRectangulos, pilhaAreas _pilhaAreas, pilhaUndo _pilhaUndo);
/*!< Função que anula o úlyimo comando AREA, COL ou COLR. Retorna 1 (True), ou 0 (False). */
Undo* procuraUndo(pilhaUndo _pilhaUndo, Undo _undo);
/*!< Função que procura um comando na pilha de comandos que podem ser anulados. Retorna a comando. */
void listaUndo(pilhaUndo _pilha);
/*!< Função que lista os comandos que podem ser anulados. */

#endif
