#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "erro.h"

#include "mod_areas.h"
#include "mod_rectangulos.h"

/** 
 * \file erro.h
 * \brief Mensagens de erro
 * 
 * Assinatura da função \a mensagem_de_erro e definição dos erros possíveis.
 */

/** 
 * \file erro.c
 * \brief Estrutura de erro
 * 
 * Definição da estrutura de erro e implementação da função \a mensagem_de_erro 
 */

/** 
 * \file mod_areas.h
 * \brief Estrutura de àreas e pilha de àreas
 * 
 * Estrutura de àrea e pilha de àrea. \n
 * Assinatura das funções relativas a àreas.
 */

/** 
 * \file mod_areas.c
 * \brief Implementação das funções relativas a áreas
 * 
 * Implementação das funções relativas a àreas.
 */

/** 
 * \file mod_rectangulos.h
 * \brief Estrutura de rectângulos, restrições, undo's e respectivas pilhas
 * 
 *  Estrutura de rectângulo e pilha de rectângulos. \n
 *  Assinatura das funções relativas a rectângulos.
 */

/** 
 * \file mod_rectangulos.c
 * \brief Implementação das funções relativas a rectângulos, restrições e undo's
 * 
 * Implementação das funções relativas a rectângulos , restrições e undo's.
 */

/** 
 * \file main.c
 * \brief Programa principal
 * 
 * É o que está visível ao utilizador. Aqui, ele insere os comandos que pretende.
 */

/*! \mainpage Etapa 3 
 *
 * \section Autores
 * Carlos Gregório, Hugo Mendes e Tiago Conceição
 * 
 *
 * \section Etapa1
 *
 * Nesta etapa foi criada a ferramenta que permite ao utilizador colocar os rectângulos na àrea de trabalho 
 * e verificar quais as restrições que são cumpridas. \n
 * Assim, apenas foi feita a leitura do dispositivo de entrada dos comandos e a escrita 
 * no dispositivo de saída da linguagem de disposição dos rectângulos. \n
 *
 * Foram implementados: \n
 *		- Um leitor de comandos;
 *		- Uma estrutura para àreas e outra para rectângulos;
 *		- Uma estrutura para pilha de àreas e outra para pilha de rectângulos;
 *		- Todas as funções para que o output da aplicação fosse o mais correcto possível;
 *		- E ainda o módulo de erros fornecido pelo docente.
 *
 * \section Etapa2 
 * Aqui foi criado, o comando DESF que permite ao utilizador anular o último comando AREA, COL ou COLR. \n
 * Contudo, o principal objectivo foi mudar a função que as restrições têm na aplicação. \n
 * Enquanto que na 1ª etapa eram apenas uma verificação acerca da colocação dos rectângulos, \n nesta etapa passaram
 * a ser definidas antes da colocação dos rectângulos, ou seja, passaram a ser restrições.
 * 
 * Foram implementados: \n
 *		- Uma modificação à estrutura de dados, em que as pilhas passam a ser listas ligadas;
 *		- Com esta modificação, as funções tiveram que ser ajustadas por forma a funcionarem com listas ligadas;
 *		- Uma pilha de restrições;
 *		- Uma pilha de comandos que podem ser anulados;
 *		- O comando DESF.
 *
 * \section Introdução
 * Esta etapa tem como principal objectivo a criaçõa do comando RSV que coloca, se for possível, \n
 * os rectângulos na área de trabalho. Ainda se pretende "ajustar" o código, com o intuito de melhorar a eficiência \n
 * da aplicação.
 *
 */


int main()
{
	char linha[2000], comando[10], _auxString1[50], _auxString2[50], _auxString3[50];
	Area _auxArea;
	Rectangulo _auxRectangulo, *_auxRectanguloPtr=NULL, *_auxRectanguloPtr2=NULL;
	pilhaRectangulos _pilhaRectangulos = NULL, _auxPilhaRectangulos;
	pilhaAreas _pilhaAreas = NULL, _auxPilhaAreas;
	pilhaRestricoes _pilhaRestricoes = NULL;
	pilhaUndo _pilhaUndo = NULL;
		
	while (!feof(stdin))
	{
		if (scanf("\n%[^\n]s", linha) != EOF)
		{
			if (sscanf(linha, "%10s", comando))
			{
				
	/*---------------------DIM--------------------*/		
				if (!strcmp(comando, "DIM"))
				{
					if (sscanf(linha, "%*s %d %d", &_auxArea.tamx, &_auxArea.tamy) == 2)
					{
						_auxArea.nome = strdup(comando);
						_auxArea.coordx = 1;
						_auxArea.coordy = 1;
						
						_auxPilhaAreas = adicionaArea(_pilhaAreas, _auxArea);
						
						if (_auxPilhaAreas && !_pilhaAreas) { printf("SIM\n"); _pilhaAreas = _auxPilhaAreas; }
						else printf("NAO\n");
					} else mensagem_de_erro(E_ARGS);
				}
				
	/*---------------------RECT--------------------*/						
				else if (!strcmp(comando, "RECT"))
				{
					if (sscanf(linha, "%*s %50s %d %d %c", _auxString1, &_auxRectangulo.tamx, &_auxRectangulo.tamy, &_auxRectangulo.roda) == 4)
					{
						_auxRectangulo.nome = strdup(_auxString1);

						_auxPilhaRectangulos = adicionaRectangulo(_pilhaRectangulos, _auxRectangulo);
						
						if (_auxPilhaRectangulos) 
						{ 
							printf("SIM\n"); _pilhaRectangulos = _auxPilhaRectangulos; 
							_pilhaRestricoes = adicionaRestricao(_pilhaRestricoes, "DENTRO", _auxString1, "DIM"); 
						}
						else printf("NAO\n");
					} else mensagem_de_erro(E_ARGS);
				}
				
	/*---------------------AREA--------------------*/						
				else if (!strcmp(comando, "AREA"))
				{
					if (_pilhaAreas)
					{
						if (sscanf(linha, "%*s %50s %d %d %d %d", _auxString1, &_auxArea.coordx, &_auxArea.coordy, &_auxArea.tamx, &_auxArea.tamy) == 5)
						{
							_auxArea.nome = strdup(_auxString1);
							
							_auxPilhaAreas = adicionaArea(_pilhaAreas, _auxArea);
							
							if (_auxPilhaAreas) 
							{ 
								printf("SIM\n"); 
								_pilhaAreas = _auxPilhaAreas; 
								_pilhaUndo = adicionarUndo(_pilhaUndo, comando, _auxString1, _auxArea.coordx, _auxArea.coordy); 
							}
							else printf("NAO\n");
						} else mensagem_de_erro(E_ARGS);
					} else mensagem_de_erro(E_NO_DIM);
				}
				
	/*---------------------COL--------------------*/						
				else if (!strcmp(comando, "COL"))
				{
					int x=0, y=0;
					if (sscanf(linha, "%*s %50s %d %d", _auxString1, &_auxRectangulo.coordx, &_auxRectangulo.coordy) == 3)
					{
						if (_pilhaAreas)
						{
							_auxRectanguloPtr = procuraRectangulo(_pilhaRectangulos, _auxString1);
							x = _auxRectanguloPtr->coordx;
							y = _auxRectanguloPtr->coordy;
							_auxRectanguloPtr->coordx = _auxRectangulo.coordx;
							_auxRectanguloPtr->coordy = _auxRectangulo.coordy;
							
							if (verificaRestricoes(_pilhaRectangulos, _pilhaAreas, _pilhaRestricoes, _auxString1))
							{	
								if (colocaRectangulo(_pilhaRectangulos, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy, 'n')) 
								{ 
									printf("SIM\n"); 
									_pilhaUndo = adicionarUndo(_pilhaUndo, comando, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy); 
									continue;  
								}	  
								else printf("NAO\n");
							} else mensagem_de_erro(E_RESTR);
						} else mensagem_de_erro(E_NO_DIM);
					} else mensagem_de_erro(E_ARGS);
					_auxRectanguloPtr->coordx = x;
					_auxRectanguloPtr->coordy = y;
				}
				
	/*---------------------COLR--------------------*/			
				else if (!strcmp(comando, "COLR"))
				{
					if (sscanf(linha, "%*s %50s %d %d", _auxString1, &_auxRectangulo.coordx, &_auxRectangulo.coordy) == 3)
					{
						if (_pilhaAreas)
						{
							if (colocaRectangulo(_pilhaRectangulos, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy, 's')) 
							{ 
								printf("SIM\n"); 
								_pilhaUndo = adicionarUndo(_pilhaUndo, comando, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy); 
							}
							else printf("NAO\n");
						} else mensagem_de_erro(E_NO_DIM);
					} else mensagem_de_erro(E_ARGS);
				}
				
	/*---------------------RESTRICÕES--------------------*/			
				else if (!strcmp(comando, "CIM") || !strcmp(comando, "BX") || !strcmp(comando, "ESQ") || !strcmp(comando, "DIR") || !strcmp(comando, "CLD") || !strcmp(comando, "SEP") || !strcmp(comando, "DENTRO") || !strcmp(comando, "FORA"))
				{
					if (sscanf(linha, "%50s %50s %50s", _auxString1, _auxString2, _auxString3) == 3)
					{
						int flag = 0;
						_auxRectanguloPtr = procuraRectangulo(_pilhaRectangulos, _auxString2);
						if (_auxRectanguloPtr->coordx == -1) flag = 1;
						if (strcmp(_auxString1, "DENTRO") && strcmp(_auxString1, "FORA"))
						{
							_auxRectanguloPtr2 = procuraRectangulo(_pilhaRectangulos, _auxString3);
							if (_auxRectanguloPtr2->coordx == -1) flag = 1;
						}
						if (flag) 
						{
							_pilhaRestricoes = adicionaRestricao(_pilhaRestricoes, _auxString1, _auxString2, _auxString3);
							printf("SIM\n");
						}
						else
						{
							Restricao _restricao;
							_restricao.cmd = strdup(_auxString1);
							_restricao.arg1 = strdup(_auxString2);
							_restricao.arg2 = strdup(_auxString3);
							
							if (verificaRestricao(_pilhaRectangulos, _pilhaAreas, _restricao)) printf("SIM\n");
							else printf("NAO");
						}
					} else mensagem_de_erro(E_ARGS);
				}
				
	/*---------------------ESTADO--------------------*/			
				else if (!strcmp(comando, "ESTADO"))
				{
					listaRectangulos(_pilhaRectangulos);
				}
				
	/*---------------------DEDF--------------------*/			
				else if (!strcmp(comando, "DESF"))
				{
					if (fazerUndo(_pilhaRectangulos, _pilhaAreas, _pilhaUndo)) { printf("SIM\n"); _pilhaUndo = _pilhaUndo->seg; }
					else printf("NAO\n");
				}
				else mensagem_de_erro(E_COMANDO);
			}
		}
	}
	return 1;
	
	/**
	 * \code 
	 
	  // Declaração de variáveis auxiliares.
	 char linha[2000], comando[10], _auxString1[50], _auxString2[50], _auxString3[50];
	 Area _auxArea;
	 Rectangulo _auxRectangulo, *_auxRectanguloPtr=NULL, *_auxRectanguloPtr2=NULL;
	 
	  // Declaração das pilhas.
	 pilhaRectangulos _pilhaRectangulos = NULL, _auxPilhaRectangulos;
	 pilhaAreas _pilhaAreas = NULL, _auxPilhaAreas;
	 pilhaRestricoes _pilhaRestricoes = NULL;
	 pilhaUndo _pilhaUndo = NULL;
	 
	 while (!feof(stdin))	// Enquanto houver input...
	 {
	 if (scanf("\n%[^\n]s", linha) != EOF)	// ...se o comando não fôr a linha vazia...
	 {
	 if (sscanf(linha, "%10s", comando))	// ...então recolhe o nome do comando.
	 {
	 
//---------------------DIM--------------------	
	 
	 if (!strcmp(comando, "DIM"))	// Caso seja DIM...
	 {
		if (sscanf(linha, "%*s %d %d", &_auxArea.tamx, &_auxArea.tamy) == 2)	// Recebe os argumentos, ignorando o nome do comando.
		{
			_auxArea.nome = strdup("DIM");	// Atribui o nome DIM.
			_auxArea.coordx = 1;	// Coordenadas do canto superior esquerdo.
			_auxArea.coordy = 1;
	 
			_auxPilhaAreas = adicionaArea(_pilhaAreas, _auxArea);	// Adiciona a área de trabalho à pilha de áreas.
	 
			if (_auxPilhaAreas && !_pilhaAreas) // Caso o resultado da adiçao seja favorável e a pilha de àreas já não esteja vazia. 
			{ 
				printf("SIM\n"); _pilhaAreas = _auxPilhaAreas; // Executou correctamente o comando com o resultado pretendido.
			}
			else printf("NAO\n");	// Não executou correctamente o comando com o resultado pretendido.
		} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 2, erro de argumentos.
	 }
	 
//---------------------RECT--------------------	 
	
	 else if (!strcmp(comando, "RECT"))	// Caso seja RECT...
	 {
		if (sscanf(linha, "%*s %50s %d %d %c", _auxString1, &_auxRectangulo.tamx, &_auxRectangulo.tamy, &_auxRectangulo.roda) == 4) // Recebe os argumentos, ignorando o nome do comando.
		{
			_auxRectangulo.nome = strdup(_auxString1);	// Recolhe o nome.
			_auxPilhaRectangulos = adicionaRectangulo(_pilhaRectangulos, _auxRectangulo);	// Adiciona o rectângulo à pilha de rectângulos.
	 
			if (_auxPilhaRectangulos)	// Caso o resultado da adiçao seja favorável.
			{ 
				printf("SIM\n"); // Executou correctamente o comando com o resultado pretendido.
				_pilhaRectangulos = _auxPilhaRectangulos;	// Actualiza a pilha.
		
					// Para testar se o rectângulo fica dentro da área de trabalho, adicionamos a restrição "DENTRO <nome_rect> DIM" á pilha de restrições.
				_pilhaRestricoes = adicionaRestricao(_pilhaRestricoes, "DENTRO", _auxString1, "DIM");	
			}
			else printf("NAO\n");	// Não executou correctamente o comando com o resultado pretendido.
		} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 4, erro de argumentos.
	 }
	 
//---------------------AREA--------------------	 
	 
	 else if (!strcmp(comando, "AREA"))	// Caso seja AREA...
	 {
		if (_pilhaAreas)	// Aqui, a pilha de àreas já não pode estar vazia pois a àrea de trabalho principal já foi definida.
		{
			if (sscanf(linha, "%*s %50s %d %d %d %d", _auxString1, &_auxArea.coordx, &_auxArea.coordy, &_auxArea.tamx, &_auxArea.tamy) == 5) // Recebe os argumentos, ignorando o nome do comando.
			{
				_auxArea.nome = strdup(_auxString1);	// Recolhe o nome.
				_auxPilhaAreas = adicionaArea(_pilhaAreas, _auxArea);	// Adiciona a àrea à pilha de àreas.
	 
				if (_auxPilhaAreas)	// Caso o resultado da adiçao seja favorável.
				{ 
					printf("SIM\n"); // Executou correctamente o comando com o resultado pretendido.
					_pilhaAreas = _auxPilhaAreas;	// Actualiza a pilha.
	 ´				_pilhaUndo = adicionarUndo(_pilhaUndo, comando, _auxString1, _auxArea.coordx, _auxArea.coordy);	// Adiciona à pilha dos comandos que podem ser anulados.
				}
				else printf("NAO\n");	// Não executou correctamente o comando com o resultado pretendido.
			} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 5, erro de argumentos.
		} else mensagem_de_erro(E_NO_DIM);	// Caso a pilha de áreas esteja vazia, erro pois não existe àrea de trabalho.
	 }
	 
//---------------------COL--------------------
	 
	 else if (!strcmp(comando, "COL"))	// Caso seja COL...
	 {
		int x=0, y=0;
		if (sscanf(linha, "%*s %50s %d %d", _auxString1, &_auxRectangulo.coordx, &_auxRectangulo.coordy) == 3)	// Recebe os argumentos, ignorando o nome do comando.
		{
			if (_pilhaAreas)	// Aqui, a pilha de àreas já não pode estar vazia pois a àrea de trabalho principal já foi definida.
			{
				_auxRectanguloPtr = procuraRectangulo(_pilhaRectangulos, _auxString1);	// Procura o rectangulo na pilha.
				x = _auxRectanguloPtr->coordx;	// Recolhe as coordenadas do rectângulo.
				y = _auxRectanguloPtr->coordy;
				_auxRectanguloPtr->coordx = _auxRectangulo.coordx;	// Muda para as coordenadas de colocação.
				_auxRectanguloPtr->coordy = _auxRectangulo.coordy;
			
				if (verificaRestricoes(_pilhaRectangulos, _pilhaAreas, _pilhaRestricoes, _auxString1))	// Verifica as restrições.
				{
					if (colocaRectangulo(_pilhaRectangulos, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy, 'n')) // Caso tenha colocado.
					{ 
						printf("SIM\n");	// Executou correctamente o comando com o resultado pretendido.
						_pilhaUndo = adicionarUndo(_pilhaUndo, comando, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy);	// Adiciona à pilha dos comandos que podem ser anulados.
						continue;  
					}
					else printf("NAO\n");	// Não executou correctamente o comando com o resultado pretendido.
				} else mensagem_de_erro(E_RESTR);	// Caso uma das restrições não se verifique, erro de restrição.
			} else mensagem_de_erro(E_NO_DIM);	// Caso a pilha de áreas esteja vazia, erro pois não existe àrea de trabalho.
		} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 3, erro de argumentos.
		
		_auxRectanguloPtr->coordx = x;	// Se algo correu mal, volta a atribuir as coordenadas em que o rectângulo se encontrava.
		_auxRectanguloPtr->coordy = y;
	 }
	 
//---------------------COLR--------------------	
	 
	 else if (!strcmp(comando, "COLR"))	// Caso seja COLR...
	 {
		if (sscanf(linha, "%*s %50s %d %d", _auxString1, &_auxRectangulo.coordx, &_auxRectangulo.coordy) == 3)	// Recebe os argumentos, ignorando o nome do comando.
		{
			if (_pilhaAreas)	// Aqui, a pilha de àreas já não pode estar vazia pois a àrea de trabalho principal já foi definida.
			{
				if (colocaRectangulo(_pilhaRectangulos, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy, 's'))		// Caso tenha colocado.
				{ 
					printf("SIM\n");	// Executou correctamente o comando com o resultado pretendido.
					_pilhaUndo = adicionarUndo(_pilhaUndo, comando, _auxString1, _auxRectangulo.coordx, _auxRectangulo.coordy);	// Adiciona à pilha dos comandos que podem ser anulados.
				}
				else printf("NAO\n");	// Não executou correctamente o comando com o resultado pretendido.
			} else mensagem_de_erro(E_NO_DIM);	// Caso a pilha de áreas esteja vazia, erro pois não existe àrea de trabalho.
		} else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 3, erro de argumentos.
	 }
	 
//---------------------RESTRICOES--------------------	
	 
		// Caso seja uma das restricões...
	 else if (!strcmp(comando, "CIM") || !strcmp(comando, "BX") || !strcmp(comando, "ESQ") || !strcmp(comando, "DIR") || !strcmp(comando, "CLD") || !strcmp(comando, "SEP") || !strcmp(comando, "DENTRO") || !strcmp(comando, "FORA"))
	 {
		if (sscanf(linha, "%50s %50s %50s", _auxString1, _auxString2, _auxString3) == 3)	// Recebe os argumentos, ignorando o nome do comando.
		{
			int flag = 0;	// Uma flag.
			_auxRectanguloPtr = procuraRectangulo(_pilhaRectangulos, _auxString2);	// Procura o primeiro rectângulo na pilha.
			if (_auxRectanguloPtr->coordx == -1) flag = 1;	// Se ele não estiver colocado.
			
			if (strcmp(_auxString1, "DENTRO") && strcmp(_auxString1, "FORA"))	// Se não for uma das restrições relativas a àreas. 
			{
				_auxRectanguloPtr2 = procuraRectangulo(_pilhaRectangulos, _auxString3);	// Procura o segundo rectângulo na pilha.
				if (_auxRectanguloPtr2->coordx == -1) flag = 1;	// Se ele não estiver colocado.
			}
	 
			if (flag) // Se não estiverem ambos colocados.
			{
				_pilhaRestricoes = adicionaRestricao(_pilhaRestricoes, _auxString1, _auxString2, _auxString3);	// Adiciona a restrição à pilha de restrições.
				printf("SIM\n");	// Executou correctamente o comando com o resultado pretendido.
			}
			else	// Caso estejam ambos colocados.
			{
				Restricao _restricao;	// Recolhe a restrição e respectivos argumentos.
				_restricao.cmd = strdup(_auxString1);
				_restricao.arg1 = strdup(_auxString2);
				_restricao.arg2 = strdup(_auxString3);
	
				if (verificaRestricao(_pilhaRectangulos, _pilhaAreas, _restricao)) // Verifica a restrição.
					printf("SIM\n");	// Executou correctamente o comando com o resultado pretendido.
				else printf("NAO");	// Não executou correctamente o comando com o resultado pretendido.
			}
		}	else mensagem_de_erro(E_ARGS);	// Caso o número de argumentos seja diferente de 3, erro de argumentos.
	 }
	 
//---------------------ESTADO--------------------
	 
	 else if (!strcmp(comando, "ESTADO"))	// Caso seja ESTADO...
	 {
		listaRectangulos(_pilhaRectangulos);	// Imprime os rectângulos. Houve falta de tempo e coordenação para fazer um "sorted insert".
	 }
	 
//---------------------DESF--------------------	 
	 
	 else if (!strcmp(comando, "DESF"))	// Caso seja DESF...
	 {
		if (fazerUndo(_pilhaRectangulos, _pilhaAreas, _pilhaUndo))	// Anula o último comando AREA, COL ou COLR.
		{ 
			printf("SIM\n");	// Executou correctamente o comando com o resultado pretendido.
			_pilhaUndo = _pilhaUndo->seg;	// Aponta para o próximo comando a ser anulado.
		}
		else printf("NAO\n");	// Não executou correctamente o comando com o resultado pretendido.
	 }
	 
	 else mensagem_de_erro(E_COMANDO);	// Caso haja alguma inconsistência na inserção do comando, erro de comando.
	 }
	 }
	 }
	 return 1;
	 
	 * \endcode
	 */	
	
}
