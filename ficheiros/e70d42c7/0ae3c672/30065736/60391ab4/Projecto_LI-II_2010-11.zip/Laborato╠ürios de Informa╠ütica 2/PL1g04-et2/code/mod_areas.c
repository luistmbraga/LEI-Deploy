
#include "mod_areas.h"

pilhaAreas adicionaArea(pilhaAreas _pilha, Area _area)
{

	if (_area.tamx > 0 && _area.tamy > 0 && _area.coordx > 0 && _area.coordy > 0)	
	{
		if (!procuraArea(_pilha, _area.nome))	
		{
			pilhaAreas _aux;
			
			_aux = (pilhaAreas) malloc(sizeof(n_pilhaAreas));
			_aux->area = _area;
			_aux->seg = _pilha;
			
			return _aux;
		} else mensagem_de_erro(E_JA_EXISTE);
	} else mensagem_de_erro(E_DIM);
	return NULL;
	
/**
 * \code 
 
 if (_area.tamx > 0 && _area.tamy > 0 && _area.coordx > 0 && _area.coordy > 0)	// A àrea só pode ter valores inteiros positivos.
 {
	if (!procuraArea(_pilha, _area.nome))	// A àrea não pode ser encontrada na pilha de àreas.
	{
		pilhaAreas _aux;	// Variável auxiliar.
	
		_aux = (pilhaAreas) malloc(sizeof(n_pilhaAreas));	// Aloca memória.
		_aux->area = _area;	// Adiciona a área...
		_aux->seg = _pilha;	// ...e aponta para a próxima célula.
 
		return _aux;	// Retorna a pilha.
	} else mensagem_de_erro(E_JA_EXISTE);	// Caso a àrea se encontre na pilha, erro pois já existe.
 } else mensagem_de_erro(E_DIM);	// Caso as dimensões não estejam dentro dos parâmetros, erro de dimensões.
 return NULL;	// Caso não consiga adicionar, retorna NULL.
 
 * \endcode
 */

/** \param _pilha que é a pilha que recebe a àrea. */
/** \param _area que é a àrea a inserir. */		
	
}

Area* procuraArea(pilhaAreas _pilha, char *_nomeArea)
{
	while (_pilha)
	{
		if (!strcmp(_pilha->area.nome, _nomeArea)) return &(_pilha->area);
		_pilha = _pilha->seg;
	}
	return NULL;

/**
 * \code 
 
 while (_pilha)	// Enquanto não tiver percorrido toda a pilha...
 {
	if (!strcmp(_pilha->area.nome, _nomeArea)) return &(_pilha->area);	// ...se encontrar a àrea, retorna o apontador para ela...
	_pilha = _pilha->seg;	// ...continua a procurar, caso contrário.
 }
 return NULL;	// Se não encontrar a àrea, retorna NULL.
 
 * \endcode
 */

/** \param _pilha que é a pilha onde vai procurar a àrea. */
/** \param _nomeArea que é o nome da àrea a procurar. */		
	
}

int removeArea(pilhaAreas _pilha, char *_nomeArea)
{
	pilhaAreas _aux=NULL;
	while (_pilha)
	{
		if (!strcmp(_pilha->area.nome, _nomeArea)) _aux = _pilha;
		_pilha = _pilha->seg;
	}
	
	if (_aux)
	{
		_aux = _aux->seg;
		_aux->seg = _aux->seg->seg;
		free(_aux->seg);
		return 1;
	}
	return 0;
	
/**
 * \code 
 
 pilhaAreas _aux=NULL;	// Variável auxiliar.
 
 while (_pilha)	// Enquanto não tiver percorrido toda a pilha...
 {
	if (!strcmp(_pilha->area.nome, _nomeArea)) _aux = _pilha;		// ...se encontrar a àrea, atribui-a à variável auxiliar...
	_pilha = _pilha->seg; // ...continua a procurar, caso contrário.
 }
 
 if (_aux)	// Se tiver encontrado a àrea...
 {
	_aux = _aux->seg;	// ...remove-a.
	_aux->seg = _aux->seg->seg;
	free(_aux->seg);
	return 1;
 }
 return 0;
 
 * \endcode
 */

/** \param _pilha que é a pilha de onde vai remover a àrea. */
/** \param _nomeArea que é o nome da àrea a remover. */			
	
}

void listaAreas (pilhaAreas _pilha)
{
	while (_pilha)
	{
		printf("%s %d %d %d %d\n", _pilha->area.nome, _pilha->area.coordx, _pilha->area.coordy, _pilha->area.coordx+_pilha->area.tamx, _pilha->area.coordy+_pilha->area.tamy);
		_pilha = _pilha->seg;
	}
	
/**
 * \code 
 
 while (_pilha)	// Enquanto não tiver percorrido toda a pilha...
 {
		// ...imprime os dados da àrea...
	printf("%s %d %d %d %d\n", _pilha->area.nome, _pilha->area.coordx, _pilha->area.coordy, _pilha->area.coordx+_pilha->area.tamx, _pilha->area.coordy+_pilha->area.tamy);
	_pilha = _pilha->seg;	// ...e continua a percorrer a pilha.
 }
 
 * \endcode
 */

/** \param _pilha que é a pilha onde estão as àreas a listar. */
			
	
}
