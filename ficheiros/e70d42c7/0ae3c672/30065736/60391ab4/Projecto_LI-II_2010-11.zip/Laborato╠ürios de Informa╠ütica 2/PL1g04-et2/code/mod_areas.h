#ifndef MOD_AREAS
#define MOD_AREAS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "erro.h"

typedef struct s_Area
/** Uma àrea é composta por um nome, 
* as coordenadas do seu canto inferior esquerdo,
* o seu tamanho horizontal e o seu tamanho vertical.
*/
{
	char *nome; /*!< Nome da àrea. */
	int coordx, /*!< Abcissa do canto inferior esquerdo. */ 
	coordy, /*!< Ordenada do canto inferior esquerdo. */
	tamx, /*!< Tamanho horizontal. */
	tamy; /*!< Tamanho vertical. */
} Area;

typedef struct s_pilhaAreas
/** A pilha de àreas é uma \a stack em que 
* serão armazenadas as àreas. A àrea de trabalho principal é o primeiro elemento desta pilha. \n
* Contém uma área e o apontador para a àrea seguinte.
*/
{
	Area area; /*!< Uma área. */
	struct s_pilhaAreas *seg; /*!< Apontador para a àrea seguinte. */
} *pilhaAreas, n_pilhaAreas; /*!< \b pilhaAreas - nome do tipo \n \b n_pilhaAreas - nodo_pilhaAreas */

pilhaAreas adicionaArea(pilhaAreas _pilha, Area _area);
/*!< Função que adiciona uma àrea à pilha de àreas. Esta função é chamada caso o comando
utilizado seja \b DIM ou \b AREA.
*/
Area* procuraArea(pilhaAreas _pilha, char *_nomeArea);
/*!< Função que procura na pilha de àreas por uma dada àrea. Caso encontre, retorna-a. */
int removeArea(pilhaAreas _pilha, char *_nomeArea);
/*!< Função que remove uma àrea da pilha de àreas. Retorna 1 (True), caso tenha removido, e 0 (False), caso contrário. */
void listaAreas (pilhaAreas _pilha);
/*!< Função de listagem de àreas. */

#endif
