
#include "mod_rectangulos.h"

pilhaRectangulos adicionaRectangulo(pilhaRectangulos _pilha, Rectangulo _rectangulo)
{
	pilhaRectangulos _aux;

	if (_rectangulo.tamx > 0 && _rectangulo.tamy > 0)
	{
		if (_rectangulo.roda == 's' || _rectangulo.roda == 'n')
		{
			if (!procuraRectangulo(_pilha, _rectangulo.nome))
			{
				_rectangulo.coordx = -1;
				_rectangulo.coordy = -1;
			
				_aux = (pilhaRectangulos) malloc(sizeof(n_pilhaRectangulos));
				_aux->rectangulo = _rectangulo;
				_aux->seg = _pilha;
				
				return _aux;
			} else mensagem_de_erro(E_JA_EXISTE);
		} else mensagem_de_erro(E_INVARGS);
	} else mensagem_de_erro(E_DIM);
	
	return NULL;
	
/**
 * \code 
 
 pilhaRectangulos _aux;	// Variável auxiliar.
 
 if (_rectangulo.tamx > 0 && _rectangulo.tamy > 0)	// O rectângulo só pode ter valores inteiros positivos.
 {
	if (_rectangulo.roda == 's' || _rectangulo.roda == 'n')	// O argumento roda só pode tomar os valores 's' ou 'n'.
	{
		if (!procuraRectangulo(_pilha, _rectangulo.nome))	// O rectângulo não pode ser encontrado na pilha de rectângulos.
		{
		_rectangulo.coordx = -1;	// À posição inicial atribuiu-se (-1,-1) para indicar que ainda não foi colocado.
		_rectangulo.coordy = -1;
	
		_aux = (pilhaRectangulos) malloc(sizeof(n_pilhaRectangulos));	// Aloca memória.
		_aux->rectangulo = _rectangulo;	 // Adiciona o rectângulo...
		_aux->seg = _pilha;	// ...e aponta para a próxima célula.

		return _aux;	// Retorna a pilha.
		} else mensagem_de_erro(E_JA_EXISTE);	// Caso o rectângulo se encontre na pilha, erro pois já existe.
	} else mensagem_de_erro(E_ARGS);	// Caso 'roda' tome valores diferentes de 's' ou 'n', erro de argumentos. 
 } else mensagem_de_erro(E_DIM);	// Caso as dimensões não estejam dentro dos parâmetros, erro de dimensões.
 
 return NULL; // Caso não consiga adicionar, retorna NULL.
 
 * \endcode
 */

/** \param _pilha que é a pilha que recebe o rectângulo. */
/** \param _rectangulo que é o rectângulo a inserir. */		
	
}

Rectangulo* procuraRectangulo(pilhaRectangulos _pilha, char *_nomeRectangulo)
{
	while (_pilha)
	{
		if (!strcmp(_pilha->rectangulo.nome, _nomeRectangulo)) return &(_pilha->rectangulo);
		_pilha = _pilha->seg;
	}
	
	return NULL;
	
/**
 * \code 
 
 while (_pilha)	// Enquanto não tiver percorrido toda a pilha...
 {
	if (!strcmp(_pilha->rectangulo.nome, _nomeRectangulo)) return &(_pilha->rectangulo);	// ...se encontrar o rectângulo, retorna o apontador para ele...
	_pilha = _pilha->seg;	// ...continua a procurar, caso contrário.
 }
 
 return NULL;	// Se não encontrar a àrea, retorna NULL.
 
 * \endcode
 */

/** \param _pilha _pilha que é a pilha onde vai procurar */
/** \param _nomeRectangulo que é o nome do rectângulo a procurar. */			
}
	
int colocaRectangulo(pilhaRectangulos _pilha, char *_nomeRectangulo, int _coordx, int _coordy, char _rodando)
{
	Rectangulo *_aux = procuraRectangulo(_pilha, _nomeRectangulo);
	
		if (_aux)
		{	
			while(_pilha)
			{
				if (strcmp(_pilha->rectangulo.nome,_aux->nome) != 0 && _pilha->rectangulo.coordx != -1)
				{
					if (_aux->coordx >= (_pilha->rectangulo.coordx + _pilha->rectangulo.tamx)) continue;
					if (_aux->coordy >= (_pilha->rectangulo.coordy + _pilha->rectangulo.tamy)) continue;
					if ((_aux->coordx + _aux->tamx) <= _pilha->rectangulo.coordx) continue;
					if ((_aux->coordy + _aux->tamy) <= _pilha->rectangulo.coordy) continue;
					return 0 ;
				}
				_pilha = _pilha->seg;
			}
			if (_rodando == 's')
			{
				if (_aux->roda == 's')
				{
					int _auxInt;
					_auxInt = _aux->tamx;
					_aux->tamx = _aux->tamy;
					_aux->tamy = _auxInt;
					_aux->rodado = (_aux->rodado == 's')?'n':'s';
				} else { mensagem_de_erro(E_ROD); return 0; }
			}	
			
			_aux->coordx = _coordx;
			_aux->coordy = _coordy;
			
			return 1;
		} else mensagem_de_erro(E_NAO_EXISTE);
	return 0;
	
/**
 * \code 
 
 Rectangulo *_aux = procuraRectangulo(_pilha, _nomeRectangulo);	// Procura o rectangulo na pilha...
 
 if (_aux)	// ...se ele lá estiver...
 {	
 
	while(_pilha)	// Enquanto não tiver percorrido toda a pilha...
	{
		if (strcmp(_pilha->rectangulo.nome,_aux->nome) != 0 && _pilha->rectangulo.coordx != -1)	// Se encontrar outros rectângulos colocados...
		{
			if (_aux->coordx >= (_pilha->rectangulo.coordx + _pilha->rectangulo.tamx)) continue;	// Verifica se pode colocar.
			if (_aux->coordy >= (_pilha->rectangulo.coordy + _pilha->rectangulo.tamy)) continue;
			if ((_aux->coordx + _aux->tamx) <= _pilha->rectangulo.coordx) continue;
			if ((_aux->coordy + _aux->tamy) <= _pilha->rectangulo.coordy) continue;
			return 0 ;
		}
		_pilha = _pilha->seg;
	}
 
	if (_rodando == 's')	// Caso se pretenda rodar...
	{
		if (_aux->roda == 's')	// ...e isso seja possível...
		{
			int _auxInt;	// Variável auxiliar.
				// ...procede à colocação...
			_auxInt = _aux->tamx;	// ...trocando a largura pelo comprimento. 
			_aux->tamx = _aux->tamy;
			_aux->tamy = _auxInt;
 
				// Passa a estar rodado, caso não estivesse e volta a não estar rodado, caso já estivesse.
			_aux->rodado = (_aux->rodado == 's')?'n':'s';
		} 
		else 
		{ 
			mensagem_de_erro(E_ROD);	// Caso não seja possível roda seja 'n', erro pois não pode rodar.
			return 0;	// Retorna 0 (False), se não foi possível colocar o rectângulo.
		}
	}	
 
	_aux->coordx = _coordx;	//	Caso não se pretenda rodar, actualiza-se as coordenadas de colocação.
	_aux->coordy = _coordy;
 
	return 1;	// Retorna 1 (True), se foi possível colocar o rectângulo.
 } else mensagem_de_erro(E_NAO_EXISTE);	// Se não tiver encontrado o rectângulo na pilha, erro pois o rectângulo não existe. 
return 0;	// Retorna 0 (False), se não foi possível colocar o rectângulo.
 
 * \endcode
 */

/** \param _pilha que é a pilha onde está o rectângulo. */
/** \param _nomeRectangulo que é o nome do rectângulo a colocar. */
/** \param _coordx é a abcissa da colocação. */
/** \param _coordy é a ordenada da colocação. */	
/** \param _rodando para indicar se roda ou não. */
	
}

void listaRectangulos (pilhaRectangulos _pilha)
{
	while (_pilha)
	{
		if (_pilha->rectangulo.coordx != -1) printf("%s %d %d %d %d\n", _pilha->rectangulo.nome, _pilha->rectangulo.coordx, _pilha->rectangulo.coordy, _pilha->rectangulo.coordx+_pilha->rectangulo.tamx, _pilha->rectangulo.coordy+_pilha->rectangulo.tamy);
		_pilha = _pilha->seg;
	}

/**
 * \code 
 
 while (_pilha)	// Enquanto não tiver percorrido toda a pilha...
 {
		// ...imprime os dados do rectângulo...
	if (_pilha->rectangulo.coordx != -1) printf("%s %d %d %d %d\n", _pilha->rectangulo.nome, _pilha->rectangulo.coordx, _pilha->rectangulo.coordy, _pilha->rectangulo.coordx+_pilha->rectangulo.tamx, _pilha->rectangulo.coordy+_pilha->rectangulo.tamy);
	_pilha = _pilha->seg;	// ...e continua a percorrer a pilha.
 }
 
 * \endcode
 */

/** \param _pilha que é a pilha onde estão os rectângulos a listar. */	

}

pilhaRestricoes adicionaRestricao(pilhaRestricoes _pilha, char *_cmd, char *_arg1, char *_arg2)
{
	pilhaRestricoes _aux;
	_aux = (pilhaRestricoes) malloc(sizeof(n_pilhaRestricoes));
	_aux->restricao.cmd = strdup(_cmd);
	_aux->restricao.arg1 = strdup(_arg1);
	_aux->restricao.arg2 = strdup(_arg2);
	_aux->seg = _pilha;
	
	return _aux;
	
/**
 * \code 
 
 pilhaRestricoes _aux;	// Variável auxiliar.
	_aux = (pilhaRestricoes) malloc(sizeof(n_pilhaRestricoes));	// Aloca memória.
	_aux->restricao.cmd = strdup(_cmd);	// Adiciona a restrição...
	_aux->restricao.arg1 = strdup(_arg1);
	_aux->restricao.arg2 = strdup(_arg2);
	_aux->seg = _pilha;	// ...e aponta para a próxima célula.
 
 return _aux;	// Retorna a pilha.
 
 * \endcode
 */

/** \param _pilha que é a pilha que recebe a restrição. */
/** \param *_cmd que é o comando da restrição. */	
/** \param *_arg1 que é o primeiro argumento. */	
/** \param *_arg2 que é o segundo argumento. */
	
}

int verificaRestricao (pilhaRectangulos _pilhaRectangulos, pilhaAreas _pilhaAreas, Restricao _restricao)
{
	Rectangulo *r1 = procuraRectangulo(_pilhaRectangulos, _restricao.arg1);
	
	if (!r1) return 0;
	if (r1->coordx == -1) return 1;
	
	if (!strcmp(_restricao.cmd, "CIM"))
	{
		Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);
		if (!r2) return 0;
		if (r2->coordx == -1) return 1;
		if (r1->coordy+r1->tamy <= r2->coordy) return 1;
		else return 0;
	}
	else if (!strcmp(_restricao.cmd, "BX"))
	{
		Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);
		if (!r2) return 0;
		if (r2->coordx == -1) return 1;
		if (r1->coordy >= r2->coordy+r2->tamy) return 1;
		else return 0;
	}
	else if (!strcmp(_restricao.cmd, "DIR"))
	{
		Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);
		if (!r2) return 0;
		if (r2->coordx == -1) return 1;
		if (r1->coordx >= r2->coordx+r2->tamx) return 1;
		else return 0;
	}
	else if (!strcmp(_restricao.cmd, "ESQ"))
	{
		Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);
		if (!r2) return 0;
		if (r2->coordx == -1) return 1;
		if (r1->coordx+r1->tamx <= r2->coordx) return 1;
		else return 0;
	}
	else if (!strcmp(_restricao.cmd, "CLD"))
	{
		Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);
		if (!r2) return 0;
		if (r2->coordx == -1) return 1;
		if (r1->coordx == r2->coordx+r2->tamx)
		{
			if (r1->coordy >= r2->coordy && r1->coordy <= r2->coordy+r2->tamy) return 1;
			if (r2->coordy >= r1->coordy && r2->coordy <= r1->coordy+r1->tamy) return 1;
		}
		if (r2->coordx == r1->coordx+r1->tamx)
		{
			if (r1->coordy >= r2->coordy && r1->coordy <= r2->coordy+r2->tamy) return 1;
			if (r2->coordy >= r1->coordy && r2->coordy <= r1->coordy+r1->tamy) return 1;
		}
		if (r1->coordy == r2->coordy+r2->tamy)
		{
			if (r1->coordx >= r2->coordx && r1->coordx <= r2->coordx+r2->tamx) return 1;
			if (r2->coordx >= r1->coordx && r2->coordx <= r1->coordx+r1->tamx) return 1;
		}
		if (r2->coordy == r1->coordy+r1->tamy)
		{
			if (r1->coordx >= r2->coordx && r1->coordx <= r2->coordx+r2->tamx) return 1;
			if (r2->coordx >= r1->coordx && r2->coordx <= r1->coordx+r1->tamx) return 1;
		}
		return 0;
	}
	else if (!strcmp(_restricao.cmd, "SEP"))
	{
		Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);
		if (!r2) return 0;
		if (r2->coordx == -1) return 1;
		if ((r1->coordx + r1->tamx) == r2->coordx) return 0;
		if ((r1->coordy + r1->tamy) == r2->coordy) return 0;
		if (r1->coordx == (r2->coordx + r2->tamx)) return 0;
		if (r1->coordy == (r2->coordy + r2->tamy)) return 0;
		return 1;
	}
	else if (!strcmp(_restricao.cmd, "DENTRO"))
	{
		Area *a = procuraArea(_pilhaAreas, _restricao.arg2);
		if (!a) return 0;
		if (r1->coordx >= a->coordx && r1->coordy >= a->coordy && (r1->coordx + r1->tamx) <= (a->coordx + a->tamx) && (r1->coordy + r1->tamy) <= (a->coordy + a->tamy)) return 1;
		return 0;
	}
	else if (!strcmp(_restricao.cmd, "FORA"))
	{
		Area *a = procuraArea(_pilhaAreas, _restricao.arg2);
		if (!a) return 0;
		if (r1->coordx >= (a->coordx + a->tamx)) return 1;
		if (r1->coordy >= (a->coordy + a->tamy)) return 1;
		if ((r1->coordx+r1->tamx) <= a->coordx) return 1;
		if ((r1->coordy+r1->tamy) <= a->coordy) return 1;
		return 0;
	}
	return 0;
	
/**
 * \code 
 
 Rectangulo *r1 = procuraRectangulo(_pilhaRectangulos, _restricao.arg1);	// Procura o rectângulo na pilha...
 
 if (!r1) return 0;	// ...se não o encontrar, a restrição não se verifica.
 if (r1->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
 
 if (!strcmp(_restricao.cmd, "CIM"))	// Caso seja CIMA...
 {
	Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);	// Procura o segundo rectângulo na pilha...
	if (!r2) return 0;	// ...se não o encontrar, a restrição não se verifica.
	if (r2->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
 
	if (r1->coordy+r1->tamy <= r2->coordy) return 1;	// Se estiver em cima, retorna 1 (True).
	else return 0;	// Retorna 0 (False), caso contrário.
 }

 else if (!strcmp(_restricao.cmd, "BX"))	// Caso seja BAIXO...
 {
	Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);	// Procura o segundo rectângulo na pilha...
	if (!r2) return 0;	// ...se não o encontrar, a restrição não se verifica.
	if (r2->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
 
	if (r1->coordy >= r2->coordy+r2->tamy) return 1;	// Se estiver em baixo, retorna 1 (True).
	else return 0;	// Retorna 0 (False), caso contrário.
 }
 
 else if (!strcmp(_restricao.cmd, "DIR"))	// Caso seja DIREITA...
 {
	Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);	// Procura o segundo rectângulo na pilha...
	if (!r2) return 0;	// ...se não o encontrar, a restrição não se verifica.
	if (r2->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
 
	if (r1->coordx >= r2->coordx+r2->tamx) return 1;	// Se estiver à direita, retorna 1 (True).
	else return 0;	// Retorna 0 (False), caso contrário.
 }
 
 else if (!strcmp(_restricao.cmd, "ESQ"))	// Caso seja ESQUERDA...
 {
	Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);	// Procura o segundo rectângulo na pilha...
	if (!r2) return 0;	// ...se não o encontrar, a restrição não se verifica.
	if (r2->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
 
	if (r1->coordx+r1->tamx <= r2->coordx) return 1;	// Se estiver à esquerda, retorna 1 (True).
	else return 0;	// Retorna 0 (False), caso contrário.
 }
 
 else if (!strcmp(_restricao.cmd, "CLD"))	// Caso seja COLADO...
 {
	Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);	// Procura o segundo rectângulo na pilha...
	if (!r2) return 0;	// ...se não o encontrar, a restrição não se verifica.
	if (r2->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
	
		// Se estiver colado, retorna 1 (True). Apesar de algum esforço, não conseguimos abandonar a solução de "força bruta".
	if (r1->coordx == r2->coordx+r2->tamx)
	{
	if (r1->coordy >= r2->coordy && r1->coordy <= r2->coordy+r2->tamy) return 1;
	if (r2->coordy >= r1->coordy && r2->coordy <= r1->coordy+r1->tamy) return 1;
	}
	if (r2->coordx == r1->coordx+r1->tamx)
	{
		if (r1->coordy >= r2->coordy && r1->coordy <= r2->coordy+r2->tamy) return 1;
		if (r2->coordy >= r1->coordy && r2->coordy <= r1->coordy+r1->tamy) return 1;
	}
	if (r1->coordy == r2->coordy+r2->tamy)
	{
		if (r1->coordx >= r2->coordx && r1->coordx <= r2->coordx+r2->tamx) return 1;
		if (r2->coordx >= r1->coordx && r2->coordx <= r1->coordx+r1->tamx) return 1;
	}
	if (r2->coordy == r1->coordy+r1->tamy)
	{
		if (r1->coordx >= r2->coordx && r1->coordx <= r2->coordx+r2->tamx) return 1;
		if (r2->coordx >= r1->coordx && r2->coordx <= r1->coordx+r1->tamx) return 1;
	}
	return 0;	// Retorna 0 (False), caso contrário.
 }
 
 else if (!strcmp(_restricao.cmd, "SEP"))	// Caso seja SEPARADO...
 {
	Rectangulo *r2 = procuraRectangulo(_pilhaRectangulos, _restricao.arg2);	// Procura o segundo rectângulo na pilha...
	if (!r2) return 0;	// ...se não o encontrar, a restrição não se verifica.
	if (r2->coordx == -1) return 1;	// Se ainda não estiver colocado, a restrição verifica-se.
 
		// Caso algum dos lados coincida, retorna 0, pois está colado.
	if ((r1->coordx + r1->tamx) == r2->coordx) return 0;
	if ((r1->coordy + r1->tamy) == r2->coordy) return 0;
	if (r1->coordx == (r2->coordx + r2->tamx)) return 0;
	if (r1->coordy == (r2->coordy + r2->tamy)) return 0;
	return 1;	// Retorna 1 (True), caso contrário.
 }
 
 else if (!strcmp(_restricao.cmd, "DENTRO"))	// Caso seja DENTRO...
 {
	Area *a = procuraArea(_pilhaAreas, _restricao.arg2);	// Procura a àrea na pilha...
	if (!a) return 0;	// ...se não a encontrar, a restrição não se verifica.
 
		// Se estiver completamente dentro, retorna 1 (True).
	if (r1->coordx >= a->coordx && r1->coordy >= a->coordy && (r1->coordx + r1->tamx) <= (a->coordx + a->tamx) && (r1->coordy + r1->tamy) <= (a->coordy + a->tamy)) return 1;
	return 0;	// Retorna 0 (False), caso contrário.
 }
 
 else if (!strcmp(_restricao.cmd, "FORA"))	// Caso seja FORA...
 {
	Area *a = procuraArea(_pilhaAreas, _restricao.arg2);	// Procura a àrea na pilha...
	if (!a) return 0;	// ...se não a encontrar, a restrição não se verifica.
 
		// Se estiver completamente fora, retorna 1 (True).		
	if (r1->coordx >= (a->coordx + a->tamx)) return 1;
	if (r1->coordy >= (a->coordy + a->tamy)) return 1;
	if ((r1->coordx+r1->tamx) <= a->coordx) return 1;
	if ((r1->coordy+r1->tamy) <= a->coordy) return 1;
	return 0;	// Retorna 0 (False), caso contrário.
 }
 return 0;
 
 * \endcode
 */
	
/** \param _pilhaRectangulos que é a pilha onde se vão buscar os rectângulos. */
/** \param _pilhaAreas que é a pilha onde se vão buscar as àreas. */			
/** \param _restricao que é a pilha onde se vão buscar as restrições. */
	
}

int verificaRestricoes (pilhaRectangulos _pilhaRectangulos, pilhaAreas _pilhaAreas, pilhaRestricoes _pilhaRestricoes, char *_nomeRectangulo)
{

	Rectangulo *_aux = procuraRectangulo(_pilhaRectangulos, _nomeRectangulo);
	
	if (_aux)
	{
		while (_pilhaRestricoes)
		{
			if (!strcmp(_pilhaRestricoes->restricao.arg1, _nomeRectangulo) || !strcmp(_pilhaRestricoes->restricao.arg2, _nomeRectangulo))
			{
				if (!verificaRestricao(_pilhaRectangulos, _pilhaAreas, _pilhaRestricoes->restricao)) return 0;
			}
			_pilhaRestricoes = _pilhaRestricoes->seg;
		}
	}
	return 1;
	
/**
 * \code 
 
 Rectangulo *_aux = procuraRectangulo(_pilhaRectangulos, _nomeRectangulo);	// Procura o rectângulo na pilha...
 
 if (_aux)	// ...se ele lá estiver...
 {
	while (_pilhaRestricoes)		// Enquanto não tiver percorrido toda a pilha...
	{		
			// Se o rectângulo for argumento de uma restrição.
		if (!strcmp(_pilhaRestricoes->restricao.arg1, _nomeRectangulo) || !strcmp(_pilhaRestricoes->restricao.arg2, _nomeRectangulo))
		{
			if (!verificaRestricao(_pilhaRectangulos, _pilhaAreas, _pilhaRestricoes->restricao)) return 0;	// Caso não se verifique a restrição, retorna 0 (False).
		}
		_pilhaRestricoes = _pilhaRestricoes->seg;	// Continua a percorrer a pilha.
	}
 }
 return 1;	// Caso se verifiquem todas as restrições, retorna 1 (True).
 
 * \endcode
 */

/** \param _pilhaRectangulos que é a pilha onde se vão buscar os rectângulos. */
/** \param _pilhaAreas que é a pilha onde se vão buscar as àreas. */			
/** \param _pilhaRestricoes que é a pilha onde se vão buscar as restrições. */	
/** \param _nomeRectangulo que é o nome do rectângulo que se pretende colocar. */	
	
}

pilhaUndo adicionarUndo(pilhaUndo _pilha, char *_cmd, char *_arg, int _coordx, int _coordy)
{
	pilhaUndo _aux;
	_aux = (pilhaUndo) malloc(sizeof(n_pilhaUndo));
	_aux->undo.cmd = strdup(_cmd);
	_aux->undo.arg = strdup(_arg);
	_aux->undo.coordx = _coordx;
	_aux->undo.coordy = _coordy;
	_aux->seg = _pilha;
	
	return _aux;
	
/**
 * \code 
 
pilhaUndo _aux;	// Variável auxiliar.
	_aux = (pilhaUndo) malloc(sizeof(n_pilhaUndo));	// Aloca memória.
	_aux->undo.cmd = strdup(_cmd);	// Adiciona o rectângulo...
	_aux->undo.arg = strdup(_arg);
	_aux->undo.coordx = _coordx;
	_aux->undo.coordy = _coordy;
	_aux->seg = _pilha;	// ...e aponta para a próxima célula.
 
return _aux;	// Retorna a pilha.
 
 * \endcode
 */

/** \param _pilha que é a pilha que recebe o comando que pode ser anulado. */
/** \param _cmd que é o nome do comando. */			
/** \param _arg que á o nome da àrea ou rectângulo. */
/** \param _coordx que é abcissa de colocação. */
/** \param _coordy que é ordenada de colocação. */
}
	
int fazerUndo(pilhaRectangulos _pilhaRectangulos, pilhaAreas _pilhaAreas, pilhaUndo _pilhaUndo)
{
	if (!_pilhaUndo) return 0;
	if (!strcmp(_pilhaUndo->undo.cmd, "AREA")) return removeArea(_pilhaAreas, _pilhaUndo->undo.arg);
	else if (!strcmp(_pilhaUndo->undo.cmd, "COL")) 
	{
		Undo *aux = procuraUndo(_pilhaUndo->seg, _pilhaUndo->undo); 
		if (aux)
		{
			colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, aux->coordx, aux->coordy, 'n');
		}
		else colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, -1, -1, 'n');
	}
	else if (!strcmp(_pilhaUndo->undo.cmd, "COLR")) 
	{
		Undo *aux = procuraUndo(_pilhaUndo->seg, _pilhaUndo->undo); 
		if (aux)
		{
			colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, aux->coordx, aux->coordy, 's');
		}
		else colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, -1, -1, 'n');
	}
	else return 0;
		
	return 1;
	
/**
 * \code 
 
 if (!_pilhaUndo) return 0;	// A pilha tem de ter comandos a anular.
 
 if (!strcmp(_pilhaUndo->undo.cmd, "AREA")) return removeArea(_pilhaAreas, _pilhaUndo->undo.arg);	// Caso o último comando a ser invocado seja AREA, remove-a.
	
	 else if (!strcmp(_pilhaUndo->undo.cmd, "COL"))	// Caso o último comando a ser invocado seja COL...
	 {
		Undo *aux = procuraUndo(_pilhaUndo->seg, _pilhaUndo->undo); // Vai procurar a última colocação do rectângulo...
		if (aux)	// Caso haja uma colocação anterior...
		{
			colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, aux->coordx, aux->coordy, 'n');	// Coloca na posição anterior.
		}
		else colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, -1, -1, 'n');	// Caso não haja uma colocação anterior, coloca em (-1,-1), que indica que não está colocado.
	 }
 
	 else if (!strcmp(_pilhaUndo->undo.cmd, "COLR")) // Caso o último comando a ser invocado seja COLR...
	 {
		Undo *aux = procuraUndo(_pilhaUndo->seg, _pilhaUndo->undo); // Vai procurar a última colocação do rectângulo...
		if (aux) // Caso haja uma colocação anterior...
	 {
		colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, aux->coordx, aux->coordy, 's');	// Coloca na posição anterior.
	 }
	 else colocaRectangulo(_pilhaRectangulos, _pilhaUndo->undo.arg, -1, -1, 'n');	// Caso não haja uma colocação anterior, coloca em (-1,-1), que indica que não está colocado.
	 }
	
     else return 0;	// Se não encontrar nenhum destes comandos, retorna 0 (False). 

 return 1;	// Retorna 1 (True), se anulou correctamente o último comando AREA, COL ou COLR.
 
 * \endcode
 */
	
/** \param _pilhaRectangulos que é a pilha onde se vão buscar os rectângulos. */
/** \param _pilhaAreas que é a pilha onde se vão buscar as àreas. */			
/** \param _pilhaUndo que é a pilha onde se vão buscar os comandos a anular. */	
	
}

Undo* procuraUndo(pilhaUndo _pilhaUndo, Undo _undo)
{
	while (_pilhaUndo)
	{
		if (!strcmp(_pilhaUndo->undo.cmd, _undo.cmd) && !strcmp(_pilhaUndo->undo.arg, _undo.arg)) return &(_pilhaUndo->undo);
		_pilhaUndo = _pilhaUndo->seg;
	}
	return NULL;
	
/**
 * \code 
 
 while (_pilhaUndo)	// Enquanto não tiver percorrido toda a pilha...
 {
	if (!strcmp(_pilhaUndo->undo.cmd, _undo.cmd) && !strcmp(_pilhaUndo->undo.arg, _undo.arg)) // Procura o comando.
		return &(_pilhaUndo->undo);	// Se o encontrar, retorna-o.
	_pilhaUndo = _pilhaUndo->seg;	// Continua a percorrer a pilha, caso contrário.
 }
 return NULL;	// Retorna NULL, caso não encontre o comando.
 
 * \endcode
 */

/** \param _pilhaUndo que é a pilha onde se vai procurar. */
/** \param _undo que é o comando a procurar. */			
	
}

void listaUndo(pilhaUndo _pilha)
{
		while (_pilha)
		{
			printf("%s %s %d %d\n", _pilha->undo.cmd, _pilha->undo.arg, _pilha->undo.coordx, _pilha->undo.coordy);
			_pilha = _pilha->seg;
		}
	
/**
 * \code 
 
 while (_pilha)	// Enquanto não tiver percorrido toda a pilha...
 {
	printf("%s %s %d %d\n", _pilha->undo.cmd, _pilha->undo.arg, _pilha->undo.coordx, _pilha->undo.coordy);	// ...imprime os dados do comando...
	_pilha = _pilha->seg;	// ...e continua a percorrer a pilha.
 }
 
 * \endcode
 */

/** \param _pilha que é a pilha onde estão os comandos a listar. */	
	
}
