-- Universidade do Minho
-- Mestrado Integrado em Engenharia Informática
-- Lincenciatura em Ciências da Computação
-- Unidade Curricular de Bases de Dados
-- 2015/2016
--
-- Caso de Estudo: "AtetasEAtletas"
-- Criação dos objetos de dados da vista "Testes Clínicos", utilizando parte do script 
-- gerado pelo MySQL Workbench.
--

-- Indicação do esquema físico da base de dados
USE `AtletasEAtletas` ;

--
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Table `mydb`.`Laboratórios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`Laboratórios` (
  `id` INT NOT NULL,
  `Designacao` VARCHAR(75) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`TestesClínicos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`TestesClínicos` (
  `id` CHAR(5) NOT NULL,
  `Designacao` VARCHAR(75) NOT NULL,
  `Periodicidade` CHAR(1) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`AtletasTestesClínicos`
-- -----------------------------------------------------
DROP TABLE `AtletasEAtletas`.`AtletasTestesClínicos`;

CREATE TABLE IF NOT EXISTS `AtletasEAtletas`.`AtletasTestesClínicos` (
  `Atleta` INT NOT NULL,
  `TesteClínico` CHAR(5) NOT NULL,
  `Laboratorio` INT NOT NULL,
  `DataRealizacao` DATE NOT NULL,
  `DataRelatório` DATE NOT NULL,
  `Relatório` TEXT NOT NULL,
  `Avaliação` VARCHAR(75) NOT NULL,
  `Observacoes` TEXT NULL,
  PRIMARY KEY (`Atleta`, `TesteClínico`, `Laboratorio`, `DataRealizacao`),
  INDEX `fk_AtletasTestesClínicos_TestesClínicos1_idx` (`TesteClínico` ASC),
  INDEX `fk_AtletasTestesClínicos_Laboratórios1_idx` (`Laboratorio` ASC),
  CONSTRAINT `fk_AtletasTestesClínicos_TestesClínicos1`
    FOREIGN KEY (`TesteClínico`)
    REFERENCES `AtletasEAtletas`.`TestesClínicos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_AtletasTestesClínicos_Laboratórios1`
    FOREIGN KEY (`Laboratorio`)
    REFERENCES `AtletasEAtletas`.`Laboratórios` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_AtletasTestesClínicos_Atletas1`
    FOREIGN KEY (`Atleta`)
    REFERENCES `AtletasEAtletas`.`Atletas` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- <fim>
-- Unidade Curricular de Bases de Dados, 2015


