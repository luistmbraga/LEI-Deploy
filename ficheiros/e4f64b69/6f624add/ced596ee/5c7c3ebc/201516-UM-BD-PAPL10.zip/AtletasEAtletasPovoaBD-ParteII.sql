-- Universidade do Minho
-- Mestrado Integrado em Engenharia Informática
-- Lincenciatura em Ciências da Computação
-- Unidade Curricular de Bases de Dados
-- 2015/2016
--
-- Caso de Edstudo: "AtetasEAtletas"
-- Povoamento da vista "Testes Clínicos" da base de dados
--

-- Indicação do esquema físico da base de dados
USE `AtletasEAtletas` ;

-- Permissão para fazer operações de remoção de dados.
SET SQL_SAFE_UPDATES = 0;

-- Povoamento da tabela `AtletasEAtletas`.`Laboratórios`
--
-- DELETE FROM Laboratórios;
INSERT INTO Laboratórios
	(id, Designacao)
	VALUES
	(1,'Laboratório da Ajuda'),
	(2,'Sono Ancestral'),
	(3,'Insónia Labs');
--
-- SELECT * FROM Laboratórios;


-- Povoamento da tabela `AtletasEAtletas`.`TestesClínicos`
--
-- DELETE FROM TestesClínicos;
INSERT INTO TestesClínicos 
	(id, Designacao, Periodicidade)
	VALUES
	('A01P1','Estado após siesta.','A'),
	('B99P1','Análise de sono contínuo.','S'),
	('A01P4','Preguiça ao adormecer.','T'),
	('AC5P2','Despertar brusco.','A'),
	('B99P3','Indução de sonho co-de-rosa.','A'),
	('C01P7','Sobressalto em pesadelo induzido.','S');
--
-- SELECT * FROM TestesClínicos;


-- Povoamento da tabela `AtletasEAtletas`.`AtletasTestesClínicos`
--
-- DELETE FROM AtletasTestesClínicos;
INSERT INTO AtletasTestesClínicos
	(Atleta, TesteClínico, Laboratorio, DataRealizacao, DataRelatório, Relatório, Avaliação, Observacoes)
	VALUES
	(1,'A01P1',1,'2013-01-02','2013-01-10','Siesta regular sem qualquer perturbação.','Regular.',NULL),
	(2,'A01P1',1,'2013-02-03','2013-02-10','Siesta regular sem qualquer perturbação.','Regular.',NULL),
	(3,'A01P1',3,'2013-03-04','2013-03-10','Siesta com sucessivas interrupções.','Incómoda.',NULL),
	(4,'A01P1',1,'2013-04-05','2013-04-10','Não foi realizada qualquer siesta.','Não concretizada.',NULL),
	(5,'A01P1',2,'2013-05-06','2013-05-10','Siesta irregular, com pequenos sonhos espontâneos.','Irregular.',NULL),
	(6,'A01P1',1,'2013-06-07','2013-06-10','Siesta regular sem qualquer perturbação.','Regular.',NULL),
	(1,'B99P1',2,'2014-04-02','2014-04-12','Dormiu como um anjo.','Regular.',NULL),
	(2,'B99P1',2,'2014-05-03','2014-05-13','Um anjo com muita atividade.','Regular.','Referiu inúmeras vezes gugugaga, ao longo do sono realizado.'),
	(3,'B99P1',2,'2014-06-11','2014-06-21','Dormiu como um anjo.','Regular.',NULL),
	(4,'B99P1',1,'2014-04-15','2014-04-25','Dormiu como um anjo.','Regular.','Sorrisos e gargalhadas a partir dos 10 minutos, até ao fim.'),
	(5,'B99P1',2,'2014-05-13','2014-05-23','Sono contínuo com fortes pesadelos.','Irregular.',NULL),
	(6,'B99P1',2,'2014-06-12','2014-06-30','Sono interrompido por mais do que uma vez.','Irregular.',NULL),
	(1,'AC5P2',3,'2014-08-02','2013-08-10','Caiu a baixo da cama.','Regular.',NULL),
	(2,'AC5P2',2,'2013-09-02','2013-09-08','Saltou e caiiu sobre a mesinha lateral.','Regular.',NULL),
	(3,'AC5P2',1,'2014-01-20','2013-01-25','Não se mexeu.','Irregular.',NULL),
	(4,'AC5P2',3,'2015-04-02','2015-04-10','Estado de pânico com soluços.','regular.',NULL),
	(5,'AC5P2',3,'2013-03-12','2013-03-20','Bocejou e agradeceu a soneca.','Irregular.',NULL),
	(6,'AC5P2',3,'2013-04-02','2013-04-10','Agrediu o enfermeiro, pedindo desculpa de seguida.','Regular.',NULL);

--
-- SELECT * FROM AtletasTestesClínicos;


-- Inibição das operações de remoção de dados.
SET SQL_SAFE_UPDATES = 1;

-- <fim>
-- Belo, O., Unidade Curricular de Bases de Dados, 2015

