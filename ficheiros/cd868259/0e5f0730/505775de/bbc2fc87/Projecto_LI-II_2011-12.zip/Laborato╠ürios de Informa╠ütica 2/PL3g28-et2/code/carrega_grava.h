#ifndef ___CARREGA_GRAVA_H___
#define ___CARREGA_GRAVA_H___

BOARD *initialize_state();
BOARD *do_load(char *args, BOARD *brd);
BOARD *loadIlum(BOARD *brd);
BOARD *do_save(char *args, BOARD *brd);

#endif