#ifndef ___EST1_C___
#define ___EST1_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est1.h"

BOARD *do_est1(char *args, BOARD *brd)
/** Corre a estratégia 1.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{	
	int col,lin;
	
	args=NULL; 
	if(args==NULL)		
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			for(lin=0; lin<brd->linha; lin++)
				for(col=0; col<brd->coluna; col++)
					if(IS_NUM(col,lin) && getNUM(col,lin,brd) != 0 && getNUM(col,lin,brd) == nFreeOrLamp(col,lin,brd)) 				
						insLamps(col,lin,brd);
		} else {mensagem_de_erro(E_NO_BOARD);}
	}
	if(brd->pilha && top(brd->pilha).ilum != -1) brd->pilha = push(brd->pilha,0,0,-1,0);
	
	return brd;
}

int getNUM(int col, int lin, BOARD *brd)
/** Retorna o número de uma casa.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=-1;
	
	if(IS_NUM(col,lin))
	{
		if(LETTER(col,lin)=='0') n=0;
		if(LETTER(col,lin)=='1') n=1;
		if(LETTER(col,lin)=='2') n=2;
		if(LETTER(col,lin)=='3') n=3;
		if(LETTER(col,lin)=='4') n=4;
	}
	
	return n;
}

int nFreeOrLamp(int col,int lin, BOARD *brd)
/** Retorna o número de casas à volta de uma casa que estão livres ou têm uma lâmpada e que estão dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=0;
	
	if(IS_IN_FREE_OR_LAMP(col-1,lin)) n++;
	if(IS_IN_FREE_OR_LAMP(col+1,lin)) n++;
	if(IS_IN_FREE_OR_LAMP(col,lin-1)) n++;
	if(IS_IN_FREE_OR_LAMP(col,lin+1)) n++;
	
	return n;	
}

BOARD *insLamps(int col, int lin, BOARD *brd)
/** Insere lâmpadas á volta de uma casa, se ela estiver livre e dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	if(IS_IN_FREE(col-1,lin)) COL_LAMP(col-1,lin);
	if(IS_IN_FREE(col+1,lin)) COL_LAMP(col+1,lin); 
	if(IS_IN_FREE(col,lin-1)) COL_LAMP(col,lin-1);	
	if(IS_IN_FREE(col,lin+1)) COL_LAMP(col,lin+1);			
	
	return brd;
}

BOARD *colLamp(int col, int lin, BOARD *brd)
/** Coloca uma lâmpada numa casa, se ela estiver livre e dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	int i;
	
	if(IS_IN_FREE(col,lin))
	{
		brd->pilha = push(brd->pilha,col,lin,0,FREE);
		ILUM(col,lin) = 1;
		LETTER(col,lin) = '@'; 
		STATE(col,lin) = LAMP;
		
		for(i=col-1; (IS_IN_FREE_OR_NO_LAMP(i,lin) || IS_IN_LAMP(i,lin)); i--) 
			if(!ILUM(i,lin))
			{ 
				brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),STATE(i,lin)); 
				ILUM(i,lin) = 1;
			}
		for(i=col+1; (IS_IN_FREE_OR_NO_LAMP(i,lin) || IS_IN_LAMP(i,lin)); i++) 
			if(!ILUM(i,lin))
			{ 
				brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),STATE(i,lin)); 
				ILUM(i,lin) = 1;
			}
		for(i=lin-1; (IS_IN_FREE_OR_NO_LAMP(col,i) || IS_IN_LAMP(col,i)); i--) 
			if(!ILUM(col,i))
			{ 
				brd->pilha = push(brd->pilha,col,i,ILUM(col,i),STATE(col,i)); 
				ILUM(col,i) = 1;
			}
		for(i=lin+1; (IS_IN_FREE_OR_NO_LAMP(col,i) || IS_IN_LAMP(col,i)); i++) 
			if(!ILUM(col,i))
			{ 
				brd->pilha = push(brd->pilha,col,i,ILUM(col,i),STATE(col,i)); 
				ILUM(col,i) = 1;
			}		
	}
	
	return brd;
}

#endif