#ifndef ___ANULA_JOGA_H___
#define ___ANULA_JOGA_H___

BOARD *do_joga(char *args, BOARD *brd);
BOARD *do_an(char *args, BOARD *brd);

#endif
