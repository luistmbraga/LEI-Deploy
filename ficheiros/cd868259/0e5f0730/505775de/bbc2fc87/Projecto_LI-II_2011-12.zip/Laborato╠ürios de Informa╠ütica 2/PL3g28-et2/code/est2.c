#ifndef ___EST2_C___
#define ___EST2_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est2.h"

BOARD *do_est2(char *args, BOARD *brd)
/** Corre a estratégia 2.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	args=NULL;
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{			
			for(lin=0; lin< brd->linha; lin++)
				for(col=0; col< brd->coluna; col++)
					if(IS_LAMP(col,lin))
					{
						ilumina(col,lin,brd); 
						ilumCasas(col,lin,brd);
					}	
		} else {mensagem_de_erro(E_NO_BOARD);} 
	}
	if(brd->pilha && top(brd->pilha).ilum!=-1) brd->pilha = push(brd->pilha,0,0,-1,0);
	
	return brd;	
}

BOARD *ilumCasas(int col, int lin, BOARD* brd)
/** Ilumina as casas na mesma linha e coluna da casa recebida. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int i;
	
	for(i=col-1; IS_IN_FREE_OR_NO_LAMP(i,lin); i--)	ilumina(i,lin,brd); 
	for(i=col+1; IS_IN_FREE_OR_NO_LAMP(i,lin); i++)	ilumina(i,lin,brd);
	for(i=lin-1; IS_IN_FREE_OR_NO_LAMP(col,i); i--)	ilumina(col,i,brd);
	for(i=lin+1; IS_IN_FREE_OR_NO_LAMP(col,i); i++)	ilumina(col,i,brd); 	 
	
	return brd;
}

BOARD *ilumina(int col, int lin, BOARD *brd) 
/** Ilumina uma casa. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(IS_IN_FREE(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),STATE(col,lin));
		ILUM(col,lin) = 1;
		
		LETTER(col,lin) = '.'; 
		STATE(col,lin) = NO_LAMP;
	}
	if(!ILUM(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,0,STATE(col,lin));
		ILUM(col,lin) = 1;
	}	

		
	
	return brd;	
}

#endif