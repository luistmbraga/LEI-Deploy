#ifndef ___EST1_H___
#define ___EST1_H___

int getNUM(int col, int lin, BOARD *brd);
BOARD *do_est1(char *args, BOARD *brd);
int nFreeOrLamp(int col,int lin, BOARD *brd);
BOARD *insLamps(int col, int lin, BOARD *brd);
BOARD *colLamp(int col, int lin, BOARD *brd);

#endif
