#ifndef ___EST5_H___
#define ___EST5_H___

BOARD *do_est5(char *args, BOARD *brd, int length);
int nCasasFreeNotIlum(int col, int lin, BOARD *brd);
BOARD *colLampCasaLivre(int col, int lin, BOARD *brd);

#endif