#ifndef ___TABULEIRO_H___
#define ___TABULEIRO_H___

#include "pilha.h"

#define MAX	40
#define MAX_BUF_SIZE	1024


#define LETTER(X,Y) brd->letter[X][Y]		/*!< Substituição de texto. */
#define STATE(X,Y) brd->state[X][Y]			/*!< Substituição de texto. */
#define ILUM(X,Y) brd->ilum[X][Y]			/*!< Substituição de texto. */

#define IS_IN(X,Y)		((X>=0 && X<brd->coluna && Y>=0 && Y<brd->linha) ? 1 : 0) /*!< Está dentro. */

#define IS_FREE(X,Y)	((STATE(X,Y) == FREE)? 1 : 0)		/*!< Está livre. */
#define IS_BLOQ(X,Y)	((STATE(X,Y) == BLOQ)? 1 : 0)		/*!< Está bloqueado. */
#define IS_NUM(X,Y)		((STATE(X,Y) == NUM)? 1 : 0)		/*!< Tem número. */	
#define IS_LAMP(X,Y)	((STATE(X,Y) == LAMP)? 1 : 0)		/*!< Tem lâmpada. */	
#define IS_NO_LAMP(X,Y) ((STATE(X,Y) == NO_LAMP)? 1 : 0)	/*!< Tem marca. */
#define IS_ILUM(X,Y)	((ILUM(X,Y) == 1)? 1 : 0)			/*!< Está iluminado. */

#define IS_IN_FREE(X,Y)		(( IS_IN (X,Y) && IS_FREE (X,Y))? 1 : 0) 	/*!< Está dentro e livre. */
#define IS_IN_NUM(X,Y)		((IS_IN(X,Y) && IS_NUM(X,Y))? 1 : 0)		/*!< Está dentro e tem número. */
#define IS_IN_LAMP(X,Y)		((IS_IN(X,Y) && IS_LAMP(X,Y))? 1 : 0)		/*!< Está dentro e tem lâmpada. */
#define IS_IN_NO_LAMP(X,Y)	((IS_IN(X,Y) && IS_NO_LAMP(X,Y))? 1 : 0)	/*!< Está dentro e tem marca. */

#define IS_IN_FREE_OR_LAMP(X,Y)	((IS_IN(X,Y) && (IS_FREE(X,Y) || IS_LAMP(X,Y)))? 1 : 0)			/*!< Está dentro e está livre ou tem lâmpada. */
#define IS_IN_FREE_OR_NO_LAMP(X,Y)	((IS_IN(X,Y) && (IS_FREE(X,Y) || IS_NO_LAMP(X,Y)))? 1 : 0)	/*!< Está dentro e está livre ou tem marca. */

#define MARCA(X,Y) marca(X,Y,brd)		/*!< Substituição de texto. */
#define COL_LAMP(X,Y) colLamp(X,Y,brd)	/*!< Substituição de texto. */

typedef struct board
/** Um tabuleiro é composto pelo número de linhas e colunas e a 
 * cada uma casas está associado um caracter, um estado e um iluminado, que indica se a casa está ou não iluminada.
 * Tem ainda uma pilha de Undo's para anulação de comandos.
 */
{
	int coluna, linha, ilum[MAX][MAX];
	char letter[MAX][MAX];
	STATE state[MAX][MAX]; 
	PILHAUNDO pilha;
} BOARD;

#endif
