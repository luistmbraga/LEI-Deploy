#ifndef ___CARREGA_GRAVA_C___
#define ___CARREGA_GRAVA_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "carrega_grava.h"
#include "est2.h"

BOARD *initialize_state()
/** Inicializa um tabuleiro. */
{
	BOARD *brd = NULL;
	int col,lin;
	
	brd = (BOARD *) malloc(sizeof(BOARD));
	if(brd!=NULL) 
	{
		brd->coluna = -1;
		brd->linha = -1;
		for(lin = 0; lin < MAX; lin++)
			for(col = 0; col < MAX; col++) 
			{
				LETTER(col,lin) = '-';
				STATE(col,lin) = FREE;
				ILUM(col,lin) = 0;
				brd->pilha = NULL;
			}
	}
	return brd;	
}

BOARD *do_load(char *args, BOARD *brd) 
/** Carrega o tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	char filename[MAX_BUF_SIZE],c,buf[1];
	int coluna,linha,col,lin,erro=E_NOERR;
	FILE *f;
	BOARD *nbrd = initialize_state();
	
	strcpy(filename, args);	
	strcat(filename,".ill");
	f = fopen(filename, "r");
	
	if(f==NULL) {erro = mensagem_de_erro(E_NO_FILE);}
	
	if(!erro && fscanf(f,"%d %d",&coluna,&linha) != 2) {erro = mensagem_de_erro(E_FILE_FORMAT);}
	
	if(!erro && (coluna>0 && coluna<=MAX) && (linha>0 && linha<=MAX))
	{
		if(nbrd != NULL)
		{
			nbrd->coluna = coluna;
			nbrd->linha = linha;
		}
		else erro = mensagem_de_erro(E_MEM);
	} 
	else {erro = erro || mensagem_de_erro(E_COORDS);}
	
	for(lin=0; !erro && lin<nbrd->linha; lin++)
		for(col=0; !erro && col<nbrd->coluna; col++) 
		{
			if(fscanf(f,"%1s", buf) != 1) {erro = mensagem_de_erro(E_FILE_FORMAT);}
			
			if(sscanf(buf, "%c", &c) && c=='-') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = FREE;
			} 
			else if(sscanf(buf, "%c", &c) && c=='x') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = BLOQ;
			} 
			else if(sscanf(buf, "%c", &c) && (c=='0'||c=='1'||c=='2'||c=='3'||c=='4')) 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = NUM;
			}
			else if(sscanf(buf, "%c", &c) && c=='@') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = LAMP;
			}
			else if(sscanf(buf, "%c", &c) && c=='.') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = NO_LAMP;
			}
			else 
			{
				fprintf(stderr,"Formato do valor na posicao (%d, %d): '%s' invalido\n",col+1,lin+1,buf);
				erro = mensagem_de_erro(E_FILE_FORMAT);
			}
		}
	
	nbrd = loadIlum(nbrd);
	
	if(brd->pilha) brd->pilha = clearPilha(brd->pilha);
	
	if(!erro) 
	{
		free(brd);
		brd = nbrd;
	}
	
	if(f!=NULL) fclose(f);
	
	return brd;
}

BOARD *loadIlum(BOARD *brd)
/** Ilumina o tabuleiro.
 * \param *brd - Tabuleiro */
{
	int col,lin,i;

	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
			if(IS_LAMP(col,lin))
			{
				ILUM(col,lin) = 1;
				for(i=col-1; (IS_IN_FREE_OR_NO_LAMP(i,lin) || IS_IN_LAMP(i,lin)); i--) ILUM(i,lin) = 1;
				for(i=col+1; (IS_IN_FREE_OR_NO_LAMP(i,lin) || IS_IN_LAMP(i,lin)); i++) ILUM(i,lin) = 1;
				for(i=lin-1; (IS_IN_FREE_OR_NO_LAMP(col,i) || IS_IN_LAMP(col,i)); i--) ILUM(col,i) = 1;
				for(i=lin+1; (IS_IN_FREE_OR_NO_LAMP(col,i) || IS_IN_LAMP(col,i)); i++) ILUM(col,i) = 1;		
			}

	return brd;
}

BOARD *do_save(char *args, BOARD *brd)
/** Grava o tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	
	int col,lin;
	char filename[MAX_BUF_SIZE];
	FILE *f;
	
	if(brd->coluna!=-1 && brd->linha!=-1) 
	{
		sscanf(args, "%s", filename);
		strcat(filename, ".ill");
		f = fopen(filename, "w");
		if(f!=NULL)
		{
			fprintf(f,"%d %d\n",brd->coluna,brd->linha);
			for(lin = 0; lin< brd->linha; lin++) 
			{
				for(col=0; col<brd->coluna-1; col++) 
				{	
					fprintf(f, "%c ", LETTER(col,lin));
				}
				fprintf(f, "%c\n", LETTER(col,lin));
			}
			fclose(f);
		} else {mensagem_de_erro(E_SAVE);} 
	} else {mensagem_de_erro(E_NO_BOARD);}	
	
	return brd;
}

#endif