#ifndef ___EST3_C___
#define ___EST3_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est1.h"
#include "est3.h"

BOARD *do_est3(char *args, BOARD *brd, int alts)
/** Corre a estratégia 3.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin,num,lamps;
	
	args=NULL;
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			for(lin=0; lin< brd->linha; lin++)
				for(col=0; col< brd->coluna; col++)
				{
					if(IS_NUM(col,lin) && !todasMarcadas(col,lin,brd))
					{	
						num = getNUM(col,lin,brd);
						lamps = nCasasLamp(col,lin,brd);
						
						lampsMarca(col,lin,brd);
						
						if(num == lamps && !todasMarcadas(col,lin,brd))			  noLampsOrto(col,lin,brd);
						if((num == 4 || num == 3) && !todasMarcadas(col,lin,brd)) noLampsDiag43(col,lin,brd);
						if(num == 2 && !todasMarcadas(col,lin,brd))				  noLampsDiag2(col,lin,num,lamps,brd);
						if(num == 1 && !todasMarcadas(col,lin,brd))				  noLampsDiag1(col,lin,num,lamps,brd);
					}	
				}
		} else {mensagem_de_erro(E_NO_BOARD);}		
	}
	
	if(alts != nAlts(brd->pilha)) return do_est3(args,brd,nAlts(brd->pilha));
	else 
	{
		if(brd->pilha && top(brd->pilha).ilum!=-1) brd->pilha = push(brd->pilha,0,0,-1,0);
		return brd;
	}	
		
}

int nCasasLamp(int col,int lin, BOARD *brd)
/** Retorna o número de casas à volta de uma casa que têm uma lâmpada e que estão dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=0;
	
	if(IS_IN_LAMP(col-1,lin)) n++;
	if(IS_IN_LAMP(col+1,lin)) n++;
	if(IS_IN_LAMP(col,lin-1)) n++;
	if(IS_IN_LAMP(col,lin+1)) n++;
	
	return n;
}

BOARD *noLampsOrto(int col, int lin, BOARD *brd)
/** Marca as casas á volta de uma casa, ortogonalmente. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	if(IS_IN_FREE(col-1,lin)) MARCA(col-1,lin); 	
	if(IS_IN_FREE(col+1,lin)) MARCA(col+1,lin); 
	if(IS_IN_FREE(col,lin-1)) MARCA(col,lin-1); 			
	if(IS_IN_FREE(col,lin+1)) MARCA(col,lin+1); 			
	
	return brd;	
}

BOARD *noLampsDiag43(int col, int lin, BOARD *brd)
/** Marca as casas á volta de uma casa, diagonalmente. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	if(IS_IN_FREE(col-1,lin-1)) MARCA(col-1,lin-1);			
	if(IS_IN_FREE(col+1,lin-1)) MARCA(col+1,lin-1); 	
	if(IS_IN_FREE(col-1,lin+1)) MARCA(col-1,lin+1);			
	if(IS_IN_FREE(col+1,lin+1)) MARCA(col+1,lin+1);		
	
	return brd;	
}

BOARD *noLampsDiag2(int col, int lin, int num, int lamps, BOARD *brd)
/** Marca as casas á volta de uma casa, diagonalmente, caso o número da casa recebida seja 2. 
 * \param col - Coluna
 * \param lin - Linha
 * \param num - Número na coordenada recebida
 * \param lamps - Número de lâmpadas à volta da coordenada recebida, ortogonalmente
 * \param *brd - Tabuleiro */
{	
	/* lt->esquerda, rt->direita, up->cima, dn->baixo, f->livre */
	int lt,rt,up,dn,ltup,rtup,ltdn,rtdn,ltf,rtf,upf,dnf;
	
	lt = IS_IN_FREE_OR_LAMP(col-1,lin);
	rt = IS_IN_FREE_OR_LAMP(col+1,lin);
	up = IS_IN_FREE_OR_LAMP(col,lin-1);
	dn = IS_IN_FREE_OR_LAMP(col,lin+1);
	
	ltup = IS_IN_FREE_OR_LAMP(col-1,lin-1);
	rtup = IS_IN_FREE_OR_LAMP(col+1,lin-1);
	ltdn = IS_IN_FREE_OR_LAMP(col-1,lin+1);
	rtdn = IS_IN_FREE_OR_LAMP(col+1,lin+1);
	
	ltf = IS_IN_FREE(col-1,lin);
	rtf = IS_IN_FREE(col+1,lin);
	upf = IS_IN_FREE(col,lin-1);
	dnf = IS_IN_FREE(col,lin+1);
	
	if(num != lamps)
	{	
		if((!lt && !rt) || (!up && !dn)) noLampsDiag43(col,lin,brd);
		if(!lt && !up) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); MARCA(col-1,lin+1); }
		if(!lt && !dn) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
		if(!rt && !up) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
		if(!rt && !dn) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); MARCA(col-1,lin+1); }
		
		if(!lt && !ltup && !ltdn) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
		if(!rt && !rtup && !rtdn) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); }
		if(!up && !ltup && !rtup) { MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
		if(!dn && !ltdn && !rtdn) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); }
		
		if(!ltf && !upf) MARCA(col+1,lin+1);
		if(!ltf && !dnf) MARCA(col+1,lin-1);
		if(!rtf && !upf) MARCA(col-1,lin+1); 
		if(!rtf && !dnf) MARCA(col+1,lin-1);		
	}
	
	return brd;	
}

BOARD *noLampsDiag1(int col, int lin, int num, int lamps, BOARD *brd)
/** Marca as casas á volta de uma casa, diagonalmente, caso o número da casa recebida seja 1. 
 * \param col - Coluna
 * \param lin - Linha
 * \param num - Número na coordenada recebida
 * \param lamps - Número de lâmpadas à volta da coordenada recebida, ortogonalmente
 * \param *brd - Tabuleiro */
{	
	/* lt->esquerda, rt->direita, up->cima, dn->baixo, f->livre */
	int lt,rt,up,dn,ltf,rtf,upf,dnf;
	
	ltf = IS_IN_FREE(col-1,lin);
	rtf = IS_IN_FREE(col+1,lin);
	upf = IS_IN_FREE(col,lin-1);
	dnf = IS_IN_FREE(col,lin+1);
	
	lt = IS_IN_FREE_OR_LAMP(col-1,lin);
	rt = IS_IN_FREE_OR_LAMP(col+1,lin);
	up = IS_IN_FREE_OR_LAMP(col,lin-1);
	dn = IS_IN_FREE_OR_LAMP(col,lin+1);
	
	if(num != lamps)
	{	
		if(!upf && !rtf && !dnf) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); }	
		if(!ltf && !upf && !rtf) { MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
		if(!upf && !ltf && !dnf) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
		if(!ltf && !dnf && !rtf) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); }
	
		if(!lt && !up) MARCA(col+1,lin+1);
		if(!lt && !dn) MARCA(col+1,lin-1);
		if(!rt && !up) MARCA(col-1,lin+1);			
		if(!rt && !dn) MARCA(col-1,lin-1);	
	}
	
	return brd;	
}	

BOARD *lampsMarca(int col, int lin, BOARD *brd)
/** Marca as casas á volta de uma casa, se houver lâmpadas á volta da casa recebida. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	if(IS_IN_LAMP(col-1,lin)) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); }
	if(IS_IN_LAMP(col+1,lin)) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
	if(IS_IN_LAMP(col,lin-1)) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); }
	if(IS_IN_LAMP(col,lin+1)) { MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
	
	if(IS_IN_LAMP(col-1,lin-1)) 
	{ 
		MARCA(col-1,lin); 
		if(!(IS_NUM(col-1,lin) || IS_BLOQ(col-1,lin)))	MARCA(col-1,lin+1); 
		
		MARCA(col,lin-1); 
		if(!(IS_NUM(col,lin-1) || IS_BLOQ(col,lin-1)))	MARCA(col+1,lin-1); 
	}
	
	if(IS_IN_LAMP(col+1,lin-1)) 
	{ 
		MARCA(col+1,lin); 
		if(!(IS_NUM(col+1,lin) || IS_BLOQ(col+1,lin)))	MARCA(col+1,lin+1); 
		
		MARCA(col,lin-1); 
		if(!(IS_NUM(col,lin-1) || IS_BLOQ(col,lin-1)))	MARCA(col-1,lin-1); 
	}
	
	if(IS_IN_LAMP(col-1,lin+1)) 
	{ 
		MARCA(col-1,lin); 
		if(!(IS_NUM(col-1,lin) || IS_BLOQ(col-1,lin)))	MARCA(col-1,lin-1); 
		
		MARCA(col,lin+1); 
		if(!(IS_NUM(col,lin+1) || IS_BLOQ(col,lin+1)))	MARCA(col+1,lin+1); 
	}
	
	if(IS_IN_LAMP(col+1,lin+1)) 
	{ 
		MARCA(col+1,lin); 
		if(!(IS_NUM(col+1,lin) || IS_BLOQ(col+1,lin)))	MARCA(col+1,lin-1); 
		
		MARCA(col,lin+1); 
		if(!(IS_NUM(col,lin+1) || IS_BLOQ(col,lin+1)))	MARCA(col-1,lin+1); 
	}
	
	return brd;
}

int todasMarcadas(int col, int lin, BOARD *brd)
/** Retorna 1 se as casas à volta de uma casa estiverem todas marcadas, 0 caso contrátio.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(!IS_IN_FREE(col-1,lin-1) && !IS_IN_FREE(col,lin-1) && !IS_IN_FREE(col+11,lin-1) && !IS_IN_FREE(col-1,lin) && 
	   !IS_IN_FREE(col+1,lin) && !IS_IN_FREE(col-1,lin+1) && !IS_IN_FREE(col,lin+1) && !IS_IN_FREE(col+1,lin+1))
		return 1;
	else return 0;
}


BOARD *marca(int col, int lin, BOARD *brd)
/** Marca uma casa, se ela estiver livre e dentro do tabuleiro.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(IS_IN_FREE(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,0,FREE);
		LETTER(col,lin)='.'; 
		STATE(col,lin)=NO_LAMP;		
	}
	
	return brd;	
}

#endif