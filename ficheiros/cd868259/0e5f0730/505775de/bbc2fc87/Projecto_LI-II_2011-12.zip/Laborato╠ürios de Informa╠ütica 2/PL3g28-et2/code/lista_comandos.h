#ifndef ___LISTA_COMANDOS_H___
#define ___LISTA_COMANDOS_H___

#include "tabuleiro.h"
#include "comandos.h"

/**
* Tipo de dados de uma funcão que implementa um comando.
*/
typedef BOARD *(FUNCTION)(char *, BOARD *);

/**
* Estrutura de dados que contém um comando.
*/
typedef struct {
	char *name;			/*!< Nome do comando */
	FUNCTION *func;		/*!< Funcao a chamar */
	int args;			/*!< Numero de argumentos do comando */
	char *doc;			/*!< O texto para o comando \a ? de ajuda */
	char undoable;		/*!< Diz se o comando pode ser anulado */
} COMMAND;

/**
* Esta estrutura de dados contem uma linha por cada comando. \n
* A grande vantagem deste sistema consiste na separacao entre
* o codigo do interpretador de comandos e a sua implementacao
*/
COMMAND command [] = {
	{"cr", cmd_load, 1, "Carrega o estado do puzzle a partir de um ficheiro no formato ILL", 0},
	{"gr", cmd_save, 1, "Grava o estado do puzzle num ficheiro utilizando o formato ILL", 0},
	{"q", cmd_quit, 0, "Sai do programa", 0},
	{"?", cmd_help, 0, "Mostra a ajuda", 0},
	{"jg", cmd_joga, 2, "Coloca uma lâmpada no tabuleiro", 1},
	{"est1", cmd_est1, 0, "Implementa a estratégia 1", 1},
	{"est2", cmd_est2, 0, "Implementa a estratégia 2", 1},
	{"est3", cmd_est3, 0, "Implementa a estratégia 3", 1},
	{"est4", cmd_est4, 0, "Implementa a estratégia 4", 1},
	{"est5", cmd_est5, 0, "Implementa a estratégia 5", 1},
	{"an", cmd_an, 0, "Anula um comando", 0},
	{(char *)NULL, NULL, 0, (char *)NULL, 0} 
};

#endif
