#ifndef ___COMANDOS_H___
#define ___COMANDOS_H___

#include "tabuleiro.h"

/**
* Esta macro pretende facilitar a criação de protótipos de comandos. \n
* Um comando chamado \a cmd tem o protótipo \a BOARD *cmd(char *, BOARD *);
*/
#define PROTOTIPO(_proto)	BOARD *_proto(char *, BOARD *)

void print_state(BOARD *);
BOARD *initialize_state(); 

PROTOTIPO(cmd_quit);
PROTOTIPO(cmd_load);
PROTOTIPO(cmd_save);
PROTOTIPO(cmd_joga);
PROTOTIPO(cmd_est1);
PROTOTIPO(cmd_est2);
PROTOTIPO(cmd_est3);
PROTOTIPO(cmd_est4);
PROTOTIPO(cmd_est5);
PROTOTIPO(cmd_an);
PROTOTIPO(cmd_help);

#endif
