#ifndef ___EST5_C___
#define ___EST5_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"
#include "est1.h"
#include "est5.h"

BOARD *do_est5(char *args, BOARD *brd, int alts)
/** Corre a estratégia 5.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	args=NULL;
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			for(lin=0; lin< brd->linha; lin++)
				for(col=0; col< brd->coluna; col++)
				{
					if(IS_FREE(col,lin) && !ILUM(col,lin) && nCasasFreeNotIlum(col,lin,brd) == 0) COL_LAMP(col,lin);
					else if(IS_NO_LAMP(col,lin) && !ILUM(col,lin) && nCasasFreeNotIlum(col,lin,brd) == 1) colLampCasaLivre(col,lin,brd);
				}
		} else {mensagem_de_erro(E_NO_BOARD);}		
	}
	
	if(alts != nAlts(brd->pilha)) return do_est5(args,brd,nAlts(brd->pilha));
	else 
	{
		if(brd->pilha && top(brd->pilha).ilum!=-1) brd->pilha = push(brd->pilha,0,0,-1,0);
		return brd; 
	}	
}

int nCasasFreeNotIlum(int col, int lin, BOARD *brd)
/** Retorna o número de casas na mesma linha e coluna da casa recebida, que estão livres e dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int i,n=0;
	
	for(i=col-1; (IS_IN_FREE_OR_NO_LAMP(i,lin)) && n<=1; i--) if(IS_FREE(i,lin) && !ILUM(i,lin)) n++;
	for(i=col+1; (IS_IN_FREE_OR_NO_LAMP(i,lin)) && n<=1; i++) if(IS_FREE(i,lin) && !ILUM(i,lin)) n++;
	for(i=lin-1; (IS_IN_FREE_OR_NO_LAMP(col,i)) && n<=1; i--) if(IS_FREE(col,i) && !ILUM(col,i)) n++;
	for(i=lin+1; (IS_IN_FREE_OR_NO_LAMP(col,i)) && n<=1; i++) if(IS_FREE(col,i) && !ILUM(col,i)) n++;
	
	return n;

}

BOARD *colLampCasaLivre(int col, int lin, BOARD *brd)
/** Coloca uma lâmpada na primeira casa livre que encontrar na mesma linha ou coluna da casa recebida. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	int i,lamp=0;
	
	for(i=col-1; IS_IN_FREE_OR_NO_LAMP(i,lin) && !lamp; i--) if(IS_FREE(i,lin) && !ILUM(i,lin)) { COL_LAMP(i,lin); lamp = 1; }
	for(i=col+1; IS_IN_FREE_OR_NO_LAMP(i,lin) && !lamp; i++) if(IS_FREE(i,lin) && !ILUM(i,lin)) { COL_LAMP(i,lin); lamp = 1; }
	for(i=lin-1; IS_IN_FREE_OR_NO_LAMP(col,i) && !lamp; i--) if(IS_FREE(col,i) && !ILUM(col,i)) { COL_LAMP(col,i); lamp = 1; }
	for(i=lin+1; IS_IN_FREE_OR_NO_LAMP(col,i) && !lamp; i++) if(IS_FREE(col,i) && !ILUM(col,i)) { COL_LAMP(col,i); lamp = 1; }
	
	return brd;	
}

#endif