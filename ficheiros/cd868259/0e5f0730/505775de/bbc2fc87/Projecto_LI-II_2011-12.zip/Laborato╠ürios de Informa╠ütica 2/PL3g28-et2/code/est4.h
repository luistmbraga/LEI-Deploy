#ifndef ___EST4_H___
#define ___EST4_H___

BOARD *do_est4(char *args, BOARD *brd);
BOARD *casosEst4(int col, int lin, int num, BOARD *brd);

#endif