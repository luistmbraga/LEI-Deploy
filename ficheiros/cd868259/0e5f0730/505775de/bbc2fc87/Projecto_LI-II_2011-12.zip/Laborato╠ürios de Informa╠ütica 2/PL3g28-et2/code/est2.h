#ifndef ___EST2_H___
#define ___EST2_H___

BOARD *do_est2(char *args, BOARD *brd);
BOARD *ilumCasas(int col, int lin, BOARD* brd);
BOARD *ilumina(int col, int lin, BOARD *brd);

#endif