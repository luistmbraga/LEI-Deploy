#ifndef ___EST4_C___
#define ___EST4_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est1.h"
#include "est4.h"

BOARD *do_est4(char *args, BOARD *brd)
/** Corre a estratégia 4.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	args=NULL;
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			for(lin=0; lin< brd->linha; lin++)
				for(col=0; col< brd->coluna; col++)
					if(IS_NUM(col,lin)) 
						casosEst4(col,lin,getNUM(col,lin,brd),brd);
		} else {mensagem_de_erro(E_NO_BOARD);}		
	}
	if(brd->pilha && top(brd->pilha).ilum!=-1) brd->pilha = push(brd->pilha,0,0,-1,0);
	
	return brd;	
}

BOARD *casosEst4(int col, int lin, int num, BOARD *brd)
/** Trata os casos da estratégia 4, excepto os casos de não-solução.
 * \param col - Coluna
 * \param lin - Linha
 * \param num - Número na coordenada recebida
 * \param *brd - Tabuleiro */
{
	/* DL- inferior esquerdo, DR- inferior direito */
	int numDL=0,numDR=0;
	
	/* Diagonal esquerda */
	if(IS_IN_NUM(col-1,lin+1)) 		
	{
		numDL = getNUM(col-1,lin+1,brd);
		
		if(num==0)
		{
			/* 0 - 1 */
			if(numDL == 1)
			{
				if(nFreeOrLamp(col-1,lin+1,brd) >= 1)
				{
					if(IS_IN_FREE_OR_LAMP(col-2,lin+1) && !IS_IN_FREE_OR_LAMP(col-1,lin+2)) COL_LAMP(col-2,lin+1);
					if(!IS_IN_FREE_OR_LAMP(col-2,lin+1) && IS_IN_FREE_OR_LAMP(col-1,lin+2))	COL_LAMP(col-1,lin+2);
				}
			}
			/* 0 - 2 */
			else if(numDL == 2)
			{
				if(IS_IN_FREE_OR_LAMP(col-2,lin+1) && IS_IN_FREE_OR_LAMP(col-1,lin+2)) { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
			}
		}
		
		else if(num==1)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 1)
			{
				/* 1 - 0 */
				if(numDL == 0)
				{
					if(IS_IN_FREE_OR_LAMP(col+1,lin) && !IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col+1,lin);
					if(!IS_IN_FREE_OR_LAMP(col+1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col,lin-1);
				}
				/* 1 - 1 */
				else if(numDL == 1)
				{	
					if(nFreeOrLamp(col-1,lin+1,brd) >= 1) 
					{
						if((IS_IN_LAMP(col+1,lin) || IS_IN_LAMP(col,lin-1)) && (!IS_IN_FREE_OR_LAMP(col-2,lin+1) || !IS_IN_FREE_OR_LAMP(col-1,lin+2))) 	   
									{ COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						if((IS_IN_LAMP(col-2,lin+1) || IS_IN_LAMP(col-1,lin+2)) && (!IS_IN_FREE_OR_LAMP(col+1,lin) || !IS_IN_FREE_OR_LAMP(col,lin-1))) 
									{ COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }	
						
						if(nFreeOrLamp(col,lin,brd) == 1)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 1) insLamps(col-1,lin+1,brd);
					}
				}
				/* 1 - 2 */
				else if(numDL == 2)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 2)
					{	
						if(nFreeOrLamp(col,lin,brd) == 1) insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 2)
						{
							if(IS_IN_FREE_OR_LAMP(col-2,lin+1) || IS_IN_FREE_OR_LAMP(col-1,lin+2)) insLamps(col-1,lin+1,brd);
						}
					}
				}
				/* 1 - 3 */
				else if(numDL == 3)	
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3)
					{
						if(nFreeOrLamp(col,lin,brd) == 1) brd = insLamps(col,lin,brd);
						if(IS_IN_FREE_OR_LAMP(col-2,lin+1) && IS_IN_FREE_OR_LAMP(col-1,lin+2)) { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
					}				 
				}				
			}
		}
		
		else if(num==2)
		{
			if(nFreeOrLamp(col,lin,brd) >= 2)
			{
				/* 2 - 0 */
				if(numDL == 0)		
				{
					if(IS_IN_FREE_OR_LAMP(col+1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1)) { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }
				}
				/* 2 - 1 */
				else if(numDL == 1)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 1)
					{
						if(nFreeOrLamp(col-1,lin+1,brd) == 1) insLamps(col-1,lin+1,brd);
						if(IS_IN_FREE_OR_LAMP(col+1,lin) && !IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col+1,lin);
						if(!IS_IN_FREE_OR_LAMP(col+1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col,lin-1);
					}
				}
				/* 2 - 2 */
				else if(numDL == 2)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 2) 
					{
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 2) insLamps(col-1,lin+1,brd);
					}
				}
				/* 2 - 3 */
				else if(numDL == 3)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3) 
					{
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 3) insLamps(col-1,lin+1,brd);
					}
				}
				/* 2 - 4 */
				else if(numDL == 4) 
				{
					if(nFreeOrLamp(col-1,lin+1,brd) == 4) insLamps(col-1,lin+1,brd);
				}
			}
		}
		
		else if(num==3)
		{
			if(nFreeOrLamp(col,lin,brd) >= 3)
			{
				/* 3 - 1 */
				if(numDL == 1) 
				{
					if(IS_IN_FREE_OR_LAMP(col+1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1))
					{ 
						COL_LAMP(col+1,lin); COL_LAMP(col,lin-1);
						if(IS_IN_FREE_OR_LAMP(col-1,lin) && !IS_IN_FREE_OR_LAMP(col,lin+1)) COL_LAMP(col-1,lin);
						if(!IS_IN_FREE_OR_LAMP(col-1,lin) && IS_IN_FREE_OR_LAMP(col,lin+1)) COL_LAMP(col,lin+1);
					}	
				}
				/* 3 - 2 */
				else if(numDL == 2)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 2) 
					{
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 2) insLamps(col-1,lin+1,brd);
					}
				}
				/* 3 - 3 */
				else if(numDL == 3)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3) 
					{
						if(IS_IN_LAMP(col+1,lin) && IS_IN_LAMP(col,lin-1))	   { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						if(IS_IN_LAMP(col-2,lin+1) && IS_IN_LAMP(col-1,lin+2)) { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }							
						
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 3) insLamps(col-1,lin+1,brd);
					}
				}
				/* 3 - 4 */
				else if(numDL == 4) 
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 4)
					{
						if(IS_IN_FREE_OR_LAMP(col+1,lin) && !IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col+1,lin);
						if(!IS_IN_FREE_OR_LAMP(col+1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1))	COL_LAMP(col,lin-1);
						insLamps(col-1,lin+1,brd);
					}
				}
			}
		}
		
		else if(num==4)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 4)
			{
				insLamps(col,lin,brd);
				
				/* 4 - 3 */
				if(numDL == 3)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3)
					{
						if(IS_IN_FREE_OR_LAMP(col-2,lin+1) && !IS_IN_FREE_OR_LAMP(col-1,lin+2)) COL_LAMP(col-2,lin+1);
						if(!IS_IN_FREE_OR_LAMP(col-2,lin+1) && IS_IN_FREE_OR_LAMP(col-1,lin+2))	COL_LAMP(col-1,lin+2);
					}
				}
				/* 4 - 4 */
				else if(numDL == 4)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) == 4) insLamps(col-1,lin+1,brd);
				}
			}	
		}
	}	
	
	/* Diagonal direita */
	if(IS_IN_NUM(col+1,lin+1)) 		
	{
		numDR = getNUM(col+1,lin+1,brd);
		
		if(num==0)
		{
			/* 0 - 1 */
			if(numDR == 1)
			{					
				if(nFreeOrLamp(col+1,lin+1,brd) >= 1)
				{
					if(IS_IN_FREE_OR_LAMP(col+2,lin+1) && !IS_IN_FREE_OR_LAMP(col+1,lin+2)) COL_LAMP(col+2,lin+1);
					if(!IS_IN_FREE_OR_LAMP(col+2,lin+1) && IS_IN_FREE_OR_LAMP(col+1,lin+2))	COL_LAMP(col+1,lin+2);
				}
			}
			/* 0 - 2 */
			else if(numDR == 2)
			{
				if(IS_IN_FREE_OR_LAMP(col+2,lin+1) && IS_IN_FREE_OR_LAMP(col+1,lin+2)) { COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
			}
		}
		
		else if(num==1)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 1)
			{
				/* 1 - 0 */
				if(numDR == 0)
				{
					if(IS_IN_FREE_OR_LAMP(col,lin-1) && !IS_IN_FREE_OR_LAMP(col-1,lin)) COL_LAMP(col,lin-1);
					if(!IS_IN_FREE_OR_LAMP(col,lin-1) && IS_IN_FREE_OR_LAMP(col-1,lin)) COL_LAMP(col-1,lin);
				}
				/* 1 - 1 */
				else if(numDR == 1)
				{	
					if(nFreeOrLamp(col+1,lin+1,brd) >= 1) 
					{
						if((IS_IN_LAMP(col-1,lin) || IS_IN_LAMP(col,lin-1)) && (!IS_IN_FREE_OR_LAMP(col+1,lin+2) || !IS_IN_FREE_OR_LAMP(col+2,lin+1))) 	   
								{ COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						if((IS_IN_LAMP(col+1,lin+2) || IS_IN_LAMP(col+2,lin+1)) && (!IS_IN_FREE_OR_LAMP(col-1,lin) || !IS_IN_FREE_OR_LAMP(col,lin-1))) 
								{ COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
						
						if(nFreeOrLamp(col,lin,brd) == 1)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 1) insLamps(col+1,lin+1,brd);
					}
				}
				/* 1 - 2 */
				else if(numDR == 2)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 2)
					{	
						if(nFreeOrLamp(col,lin,brd) == 1) insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 2)
						{
							if(IS_IN_FREE_OR_LAMP(col+2,lin+1) || IS_IN_FREE_OR_LAMP(col+1,lin+2)) insLamps(col+1,lin+1,brd);
						}
					}
				}
				/* 1 - 3 */
				else if(numDR == 3)	
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3)
					{
						if(nFreeOrLamp(col,lin,brd) == 1) brd = insLamps(col,lin,brd);
						if(IS_IN_FREE_OR_LAMP(col+2,lin+1) && IS_IN_FREE_OR_LAMP(col+1,lin+2)) { COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
					}				 
				}
			}	
		}
		
		else if(num==2)
		{
			if(nFreeOrLamp(col,lin,brd) >= 2)
			{	
				/* 2 - 0 */
				if(numDR == 0)		
				{
					if(IS_IN_FREE_OR_LAMP(col-1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1)) { COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
				}
				/* 2 - 1 */
				else if(numDR == 1)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 1)
					{
						if(nFreeOrLamp(col+1,lin+1,brd) == 1) insLamps(col+1,lin+1,brd);					
						
						if(IS_IN_FREE_OR_LAMP(col-1,lin) && !IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col-1,lin);
						if(!IS_IN_FREE_OR_LAMP(col-1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col,lin-1);
					}				
				}
				/* 2 - 2 */
				else if(numDR == 2)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 2) 
					{
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 2) insLamps(col+1,lin+1,brd);
					}
				}
				/* 2 - 3 */
				else if(numDR == 3)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3) 
					{
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 3) insLamps(col+1,lin+1,brd);
					}
				}
				/* 2 - 4 */
				else if(numDR == 4) 
				{
					if(nFreeOrLamp(col+1,lin+1,brd) == 4) insLamps(col+1,lin+1,brd);
				}
			}	
		}
		
		else if(num==3)
		{
			if(nFreeOrLamp(col,lin,brd) >= 3)
			{
				/* 3 - 1 */
				if(numDR == 1) 
				{
					if(IS_IN_FREE_OR_LAMP(col-1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1)) 
					{
						COL_LAMP(col-1,lin); COL_LAMP(col,lin-1);
						if(IS_IN_FREE_OR_LAMP(col+1,lin) && !IS_IN_FREE_OR_LAMP(col,lin+1)) COL_LAMP(col+1,lin);
						if(!IS_IN_FREE_OR_LAMP(col+1,lin) && IS_IN_FREE_OR_LAMP(col,lin+1)) COL_LAMP(col,lin+1);
					}	
				}
				/* 3 - 2 */
				else if(numDR == 2)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 2) 
					{
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 2) insLamps(col+1,lin+1,brd);
					}
				}
				/* 3 - 3 */
				else if(numDR == 3)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3) 
					{
						if(IS_IN_LAMP(col-1,lin) && IS_IN_LAMP(col,lin-1))	   { COL_LAMP(col+1,lin+2); COL_LAMP(col+2,lin+1); }
						if(IS_IN_LAMP(col+1,lin+2) && IS_IN_LAMP(col+2,lin+1)) { COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }	
						
						if(nFreeOrLamp(col,lin,brd) == 3) 	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 3) insLamps(col+1,lin+1,brd);
					}
				}
				/* 3 - 4 */
				else if(numDR == 4) 
				{				
					if(nFreeOrLamp(col+1,lin+1,brd) >= 4)
					{
						if(IS_IN_FREE_OR_LAMP(col-1,lin) && !IS_IN_FREE_OR_LAMP(col,lin-1)) COL_LAMP(col-1,lin);
						if(!IS_IN_FREE_OR_LAMP(col-1,lin) && IS_IN_FREE_OR_LAMP(col,lin-1))	COL_LAMP(col,lin-1);
						insLamps(col+1,lin+1,brd);
					}
				}
			}
		}
		
		else if(num==4)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 4)
			{
				insLamps(col,lin,brd);
				
				/* 4 - 3 */
				if(numDR == 3)
				{			
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3)
					{
						if(IS_IN_FREE_OR_LAMP(col+2,lin+1) && !IS_IN_FREE_OR_LAMP(col+1,lin+2)) COL_LAMP(col+2,lin+1);
						if(!IS_IN_FREE_OR_LAMP(col+2,lin+1) && IS_IN_FREE_OR_LAMP(col+1,lin+2))	COL_LAMP(col+1,lin+2);
					}
				}
				/* 4 - 4 */
				else if(numDR == 4)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) == 4) insLamps(col+1,lin+1,brd);
				}
			}	
		}
	}
	
	return brd;
}

#endif