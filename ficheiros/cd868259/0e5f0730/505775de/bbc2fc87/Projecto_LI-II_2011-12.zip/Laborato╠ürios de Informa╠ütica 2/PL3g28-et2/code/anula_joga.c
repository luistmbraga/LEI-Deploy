#ifndef ___ANULA_JOGA_C___
#define ___ANULA_JOGA_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "anula_joga.h"

BOARD *do_an(char *args, BOARD *brd)
/** Anula um comando.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	args=NULL;
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			if(brd->pilha)
			{	
				brd->pilha = pop(brd->pilha);
		
				while(brd->pilha && brd->pilha->undo.ilum!=-1)
				{
					col = brd->pilha->undo.col;
					lin = brd->pilha->undo.lin;
				
					if(brd->pilha->undo.state == FREE)			LETTER(col,lin) = '-';
					else if(brd->pilha->undo.state == LAMP)		LETTER(col,lin) = '@';
					else if(brd->pilha->undo.state == NO_LAMP)	LETTER(col,lin) = '.'; 
				
					ILUM(col,lin) = brd->pilha->undo.ilum;
					STATE(col,lin) = brd->pilha->undo.state;
				
					brd->pilha = pop(brd->pilha);
				}
			} else {mensagem_de_erro(E_NO_MOVES);} 
		} else {mensagem_de_erro(E_NO_BOARD);}		
	}
	
	/*
	 listaPilha(brd->pilha);
	 printf("\n");
	 */
	
	return brd;	
	
}

BOARD *do_joga(char *args, BOARD *brd)
/** Joga numa casa do tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin,i;
	
	if(brd->coluna!=-1 && brd->linha!=-1) 
	{
		if(sscanf(args,"%d %d",&col,&lin)==2)
		{	
			col--;
			lin--;
			if(IS_IN(col,lin))				
			{	
				brd->pilha = push(brd->pilha, col, lin, ILUM(col,lin), STATE(col,lin));
				
				if(IS_IN_FREE_OR_NO_LAMP(col,lin)) 
				{
					ILUM(col,lin) = 1;
					LETTER(col,lin) ='@';
					STATE(col,lin) = LAMP;
					
					for(i=col-1; (IS_IN_FREE_OR_NO_LAMP(i,lin) || IS_IN_LAMP(i,lin)); i--) 
					{ 
						brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),STATE(i,lin)); 
						ILUM(i,lin) = 1;
					}
					for(i=col+1; (IS_IN_FREE_OR_NO_LAMP(i,lin) || IS_IN_LAMP(i,lin)); i++) 
					{ 
						brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),STATE(i,lin)); 
						ILUM(i,lin) = 1;
					}
					for(i=lin-1; (IS_IN_FREE_OR_NO_LAMP(col,i) || IS_IN_LAMP(col,i)); i--) 
					{ 
						brd->pilha = push(brd->pilha,col,i,ILUM(col,i),STATE(col,i)); 
						ILUM(col,i) = 1;
					}
					for(i=lin+1; (IS_IN_FREE_OR_NO_LAMP(col,i) || IS_IN_LAMP(col,i)); i++) 
					{ 
						brd->pilha = push(brd->pilha,col,i,ILUM(col,i),STATE(col,i)); 
						ILUM(col,i) = 1;
					}	
				}
				else if(IS_LAMP(col,lin))
				{
					ILUM(col,lin) = 0;
					LETTER(col,lin) = '-';
					STATE(col,lin) = FREE;					
				}
				else {mensagem_de_erro(E_BLOC);}
				
	
				

				
			} else {mensagem_de_erro(E_COORDS);}			
		} else {mensagem_de_erro(E_ARGS);}		
	} else {mensagem_de_erro(E_NO_BOARD);}
	
	if(brd ->pilha && top(brd->pilha).ilum != -1) brd->pilha = push(brd->pilha,0,0,-1,0);
	
	return brd;
}	

#endif