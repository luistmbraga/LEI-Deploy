#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "comandos.h"
#include "erro.h"

#include "carrega_grava.h"
#include "anula_joga.h"
#include "est1.h"
#include "est2.h"
#include "est3.h"
#include "est4.h"
#include "est5.h"

#define MAX_BUF_SIZE	1024 /*!< Tamanho máximo do input */
#define TALVEZ_MENSAGEM(erro)	((cmd) ? mensagem_de_erro(erro) : (erro)) /*!< Mensagem de erro. */

void print_state(BOARD *brd)
/** Imprime o estado do tabuleiro.
 * \param *brd - Tabuleiro */	
{	
	int col,lin;
	
	if(brd->coluna==-1 || brd->linha==-1) return;
	printf("%d %d\n",brd->coluna,brd->linha);	
	for(lin=0; lin< brd->linha; lin++) 
	{
		for(col=0; col< brd->coluna-1; col++)
		{
			printf("%c ",LETTER(col,lin));
		}
		printf("%c\n",LETTER(col,lin));
	}
}

BOARD *cmd_quit(char *args, BOARD *brd)
/** Implementação do comando q, que sai da aplicação.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	args=NULL; 
	if(args==NULL)
		exit(0);
	return brd;
}

BOARD *cmd_load(char *args, BOARD *brd)
/** Implementação do comando cr, que carrega um tabuleiro a partir de um ficheiro. \n
 Esta função apenas lê os argumentos e invoca a função \a do_load, que vai carregar o tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int i = 0;
	while(args[i] && !isspace(args[i])) i++;
	args[i] = 0;
	return do_load(args, brd);
}

BOARD *cmd_save(char *args, BOARD *brd)
/** Implementação do comando gr, que grava o tabuleiro num ficheiro.
 * \param *args - Argumentos do comando 
 * \param *brd - Tabuleiro para gravação */
{
	return do_save(args,brd);
}

BOARD *cmd_joga(char *args, BOARD *brd) 
/** Implementação do comando jg, que coloca/remove uma lâmpada de uma casa do tabuleiro. \n
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	return do_joga(args,brd);
}

BOARD *cmd_est1(char *args, BOARD *brd)
/** Implementa a estratégia 1.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{	
	return do_est1(args,brd);
}	

BOARD *cmd_est2(char *args, BOARD *brd)
/** Implementa a estratégia 2.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	return do_est2(args,brd); 	
}

BOARD *cmd_est3(char *args, BOARD *brd)
/** Implementa a estratégia 3.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	return do_est3(args,brd,nAlts(brd->pilha));
}

BOARD *cmd_est4(char *args, BOARD *brd)
/** Implementa a estratégia 4.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	return do_est4(args,brd);
}

BOARD *cmd_est5(char *args, BOARD *brd)
/** Implementa a estratégia 5.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	return do_est5(args,brd,nAlts(brd->pilha));
}

BOARD *cmd_an(char *args, BOARD *brd)
/** Implementação do comando an, que anula um comando que alterou o tabuleiro. \n
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	return do_an(args,brd);
}