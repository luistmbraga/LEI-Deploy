#include "pilha.h"

PILHAUNDO push(PILHAUNDO pilha, int col, int lin, int ilum, STATE state)
/** Faz um push de um undo para a stack.
 * \param pilha - Stack
 * \param col - Coluna
 * \param lin - Linha
 * \param ilum anterior
 * \param state anterior
 */
{
	PILHAUNDO aux = malloc(sizeof(N_PILHAUNDO));
	
	aux->undo.col = col;
	aux->undo.lin = lin;
	aux->undo.ilum = ilum;
	aux->undo.state = state;
	aux->seg = pilha;
	
	return aux;
}

PILHAUNDO pop(PILHAUNDO pilha)
/** Faz um pop de um undo da stack.
 * \param pilha - Stack
 */
{
	PILHAUNDO aux=NULL;
	
	if(pilha)
	{	
		aux = malloc(sizeof(N_PILHAUNDO));
		aux = pilha;
		pilha = pilha->seg;
		free(aux);
	}
	
	return pilha;	
}

UNDO top(PILHAUNDO pilha)
/** Retorna o topo stack.
 * \param pilha - Stack
 */
{
	return (pilha->undo);
}

PILHAUNDO clearPilha(PILHAUNDO pilha)
/** Remove todos os elementos da stack.
 * \param pilha - Stack
 */
{
	while(pilha) pilha = pop(pilha);
	return pilha;
}

void listaPilha(PILHAUNDO pilha)
{
	while(pilha) 
	{
		printf("(%d,%d,%d,%d)",pilha->undo.col,pilha->undo.lin,pilha->undo.ilum,pilha->undo.state);
		pilha = pilha->seg;
	}	
}

int nAlts(PILHAUNDO pilha)
/** Retorna o número de undo's, até à primeira marca, da stack.
 * \param pilha - Stack
 */
{
	int res = 0;
	while(pilha && pilha->undo.ilum != -1)
	{
		res++;
		pilha = pilha->seg;
	}	
	return res;
}

