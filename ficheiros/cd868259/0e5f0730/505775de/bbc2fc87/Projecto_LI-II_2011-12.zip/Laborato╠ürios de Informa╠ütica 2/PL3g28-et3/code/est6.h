#ifndef ___EST6_H___
#define ___EST6_H___

BOARD *do_est6(BOARD *brd, int nAlts);
BOARD *comparaDiags(int col, int lin, BOARD *brd);
PILHAUNDO getCoords(int col, int lin, BOARD *brd);
int coordsIguais(PILHAUNDO p1, PILHAUNDO p2);

#endif