#ifndef ___EST5_H___
#define ___EST5_H___

BOARD *do_est5(BOARD *brd, int nAlts, int flagrsv);
int nCasasFreeNotIlum(int col, int lin, BOARD *brd);
BOARD *colLampCasaLivre(int col, int lin, BOARD *brd);

#endif