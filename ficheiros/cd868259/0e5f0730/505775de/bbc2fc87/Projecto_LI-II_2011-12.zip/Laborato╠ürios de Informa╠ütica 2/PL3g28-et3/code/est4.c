#ifndef ___EST4_C___
#define ___EST4_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est1.h"
#include "est3.h"
#include "est4.h"

BOARD *do_est4(BOARD *brd, int alts, int flagrsv)
/** Corre a estratégia 4.
 * \param *brd - Tabuleiro 
 * \param alts - Número de undo's na pilha de undo's (até à primeira marca)
 * \param flagrsv - Flag que indica se o comando foi invocado pelo comando rsv 
 */
{
	int col,lin;

	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
			if(IS_NUM(col,lin) && (IS_NUM(col-1,lin+1) || IS_NUM(col+1,lin+1))) 
				casosEst4(col,lin,getNUM(col,lin,brd),flagrsv,brd);
				
				
	if(alts != nAlts(brd->pilha)) return do_est4(brd,nAlts(brd->pilha),flagrsv);
	else 
	{
		if(brd->pilha && top(brd->pilha).ilum!=-1 && !flagrsv) brd->pilha = push(brd->pilha,0,0,-1,1,0);
		return brd;
	}
}

BOARD *casosEst4(int col, int lin, int num, int flagrsv, BOARD *brd)
/** Trata os casos da estratégia 4.
 * \param col - Coluna
 * \param lin - Linha
 * \param num - Número na coordenada recebida
 * \param flagrsv - Flag que indica se o comando foi invocado pelo comando rsv 
 * \param *brd - Tabuleiro 
 */
{
	/* DL- inferior esquerdo, DR- inferior direito */
	int numDL=0,numDR=0;
	
	/* Diagonal esquerda */
	if(IS_IN_NUM(col-1,lin+1)) 		
	{
		numDL = getNUM(col-1,lin+1,brd);
		
		if(num==0)
		{	
			/* 0 - 1 */
			if(numDL == 1)
			{	
				if(nFreeOrLamp(col-1,lin+1,brd) >= 1)
				{
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0;
					if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) COL_LAMP(col-2,lin+1);
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) COL_LAMP(col-1,lin+2);
				}
				else SOL = 0;
			}
			/* 0 - 2 */
			else if(numDL == 2)
			{
				if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0;
				else { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
			}
			/* 0 - 3 */
			else if(numDL == 3) SOL=0;
			/* 0 - 4 */
			else if(numDL == 4) SOL=0;
		}
		
		else if(num==1)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 1)
			{
				/* 1 - 0 */
				if(numDL == 0)
				{
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
					if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col+1,lin);
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col,lin-1);	
				}
				/* 1 - 1 */
				else if(numDL == 1)
				{	
					if(nFreeOrLamp(col-1,lin+1,brd) >= 1) 
					{
						if((IS_IN_LAMP(col+1,lin) || IS_IN_LAMP(col,lin-1)) && 
						   (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2)))) 	   
								{ COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						
					   if((IS_IN_LAMP(col-2,lin+1) || IS_IN_LAMP(col,lin-1)) && 
						  (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))))	   
								{ COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }	
						
						if(nFreeOrLamp(col,lin,brd) == 1)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 1) insLamps(col-1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 1 - 2 */
				else if(numDL == 2)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 2)
					{	
						if(nFreeOrLamp(col,lin,brd) == 1) insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 2)
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0; 
							else insLamps(col-1,lin+1,brd);
						}
					}
					else SOL = 0;
				}
				/* 1 - 3 */
				else if(numDL == 3)	
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0;
						else { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						
						if(IS_IN_LAMP(col+1,lin) || IS_IN_LAMP(col,lin-1)) SOL = 0;
						else if(flagrsv) { MARCA(col+1,lin); MARCA(col,lin-1); }
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0; 
						else	
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}
						
						if(nFreeOrLamp(col,lin,brd) == 1) insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 3) insLamps(col-1,lin+1,brd);
					}	
					else SOL=0;	
				}
				/* 1 - 4 */
				else if(numDL == 4) SOL = 0;
			}
		}
		
		else if(num==2)
		{
			if(nFreeOrLamp(col,lin,brd) >= 2)
			{
				/* 2 - 0 */
				if(numDL == 0)		
				{
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
					else { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }
				}
				/* 2 - 1 */
				else if(numDL == 1)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 1)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
						else
						{	
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col+1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col,lin-1);							
						}
						
						if(nFreeOrLamp(col-1,lin+1,brd) == 1) insLamps(col-1,lin+1,brd);
					}
					else SOL=0;
				}
				/* 2 - 2 */
				else if(numDL == 2)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 2) 
					{
						if(IS_IN_LAMP(col+1,lin) && IS_IN_LAMP(col,lin-1))
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0;
							else { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						}
						
						if(IS_IN_LAMP(col-2,lin+1) && IS_IN_LAMP(col-1,lin+2))
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
							else { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }
						}
						
						if((IS_IN_LAMP(col+1,lin) || IS_IN_LAMP(col,lin-1)) && 
						 (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2)))) 	   
								{ COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						
						if((IS_IN_LAMP(col-2,lin+1) || (IS_IN_LAMP(col,lin-1))) && 
						   (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1)))) 	   
								{ COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }
						
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 2) insLamps(col-1,lin+1,brd);
					}
					else SOL = 0;	
				}
				/* 2 - 3 */
				else if(numDL == 3)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3) 
					{
						if(IS_IN_LAMP(col+1,lin) || IS_IN_LAMP(col,lin-1))
						{
						   if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1) && IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2)) 
								{ COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						   else SOL = 0;
						}	
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}	
							
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 3) insLamps(col-1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 2 - 4 */
				else if(numDL == 4) 
				{
					if(nFreeOrLamp(col-1,lin+1,brd) == 4) insLamps(col-1,lin+1,brd);
					else SOL=0;
				}
			}
			else SOL=0;
		}
		
		else if(num==3)
		{
			if(nFreeOrLamp(col,lin,brd) >= 3)
			{
				/* 3 - 0 */
				if(numDL == 0) SOL=0;
				/* 3 - 1 */
				else if(numDL == 1) 
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 1)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
						else { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }
						
						if(IS_IN_LAMP(col-2,lin+1) || IS_IN_LAMP(col-1,lin+2)) SOL = 0;
						else if(flagrsv) { MARCA(col-2,lin+1); MARCA(col-1,lin+2); }
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}
						
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 1) insLamps(col-1,lin+1,brd);
					}	
					else SOL=0;
				}
				/* 3 - 2 */
				else if(numDL == 2)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 2) 
					{
						if(IS_IN_LAMP(col-2,lin+1) || IS_IN_LAMP(col-1,lin+2))
						{	
							if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin) && IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1)) { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }
							else SOL = 0;
						}	
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}	
							
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 2) insLamps(col-1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 3 - 3 */
				else if(numDL == 3)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3) 
					{
						if(IS_IN_LAMP(col+1,lin) && IS_IN_LAMP(col,lin-1)) 
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0;
							else { COL_LAMP(col-2,lin+1); COL_LAMP(col-1,lin+2); }
						}
						
						if(IS_IN_LAMP(col-2,lin+1) && IS_IN_LAMP(col-1,lin+2))
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
							else { COL_LAMP(col+1,lin); COL_LAMP(col,lin-1); }							
						}
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}	
						
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col-1,lin+1,brd) == 3) insLamps(col-1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 3 - 4 */
				else if(numDL == 4) 
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 4)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
						else
						{
							if( (IS_IN(col+1,lin) && ((IS_FREE(col+1,lin) && !ILUM(col+1,lin)) || IS_LAMP(col+1,lin))) &&
							   !(IS_IN(col,lin-1) && ((IS_FREE(col,lin-1) && !ILUM(col,lin-1)) || IS_LAMP(col,lin-1))))
									COL_LAMP(col+1,lin);
							
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col,lin-1);
						}
						
						insLamps(col-1,lin+1,brd);
					}
					else SOL = 0;
				}
			}
			else SOL = 0;
		}
		
		else if(num==4)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 4)
			{
				/* 4 - 0 */
				if(numDL == 0) SOL=0;
				/* 4 - 1 */
				else if(numDL == 1) SOL=0;
				/* 4 - 2 */
				else if(numDL == 2) 
				{
					if(nFreeOrLamp(col,lin,brd) == 4) insLamps(col,lin,brd);
					else SOL=0;
				}
				/* 4 - 3 */
				if(numDL == 3)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 3)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) COL_LAMP(col-2,lin+1);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-2,lin+1)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin+2))) COL_LAMP(col-1,lin+2);
						}

						insLamps(col,lin,brd);
					}
					else SOL=0;
				}
				/* 4 - 4 */
				else if(numDL == 4)
				{
					if(nFreeOrLamp(col-1,lin+1,brd) >= 4) insLamps(col-1,lin+1,brd);
					else SOL=0;
					insLamps(col,lin,brd);
				}
			}	
			else SOL=0;
		}
	}
	
	/* Diagonal direita */
	if(IS_IN_NUM(col+1,lin+1)) 		
	{
		numDR = getNUM(col+1,lin+1,brd);
		
		if(num==0)
		{	
			/* 0 - 1 */
			if(numDR == 1)
			{	
				if(nFreeOrLamp(col+1,lin+1,brd) >= 1)
				{
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0;
					if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) COL_LAMP(col+2,lin+1);
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) COL_LAMP(col+1,lin+2);
				}
				else SOL = 0;
			}
			/* 0 - 2 */
			else if(numDR == 2)
			{
				if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0;
				else { COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
			}
			/* 0 - 3 */
			else if(numDR == 3) SOL=0;
			/* 0 - 4 */
			else if(numDR == 4) SOL=0;
		}
		
		else if(num==1)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 1)
			{
				/* 1 - 0 */
				if(numDR == 0)
				{
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
					if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col-1,lin);
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col,lin-1);	
				}
				/* 1 - 1 */
				else if(numDR == 1)
				{	
					if(nFreeOrLamp(col+1,lin+1,brd) >= 1) 
					{
						if((IS_IN_LAMP(col-1,lin) || IS_IN_LAMP(col,lin-1)) && 
						   (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2)))) 	   
								{ COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
						
						if((IS_IN_LAMP(col+2,lin+1) || IS_IN_LAMP(col,lin-1)) && 
						   (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1)))) 	   
								{ COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }	
						
						if(nFreeOrLamp(col,lin,brd) == 1)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 1) insLamps(col+1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 1 - 2 */
				else if(numDR == 2)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 2)
					{	
						if(nFreeOrLamp(col,lin,brd) == 1) insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 2)
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0; 
							else insLamps(col+1,lin+1,brd);
						}
					}
					else SOL = 0;
				}
				/* 1 - 3 */
				else if(numDR == 3)	
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0;
						else { COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
						
						if(IS_IN_LAMP(col-1,lin) || IS_IN_LAMP(col,lin-1)) SOL = 0;
						else if(flagrsv) { MARCA(col-1,lin); MARCA(col,lin-1); }
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col+1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}
						
						if(nFreeOrLamp(col,lin,brd) == 1) insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 3) insLamps(col+1,lin+1,brd);
					}	
					else SOL=0;	
				}
				/* 1 - 4 */
				else if(numDR == 4) SOL = 0;
			}
		}
		
		else if(num==2)
		{
			if(nFreeOrLamp(col,lin,brd) >= 2)
			{
				/* 2 - 0 */
				if(numDR == 0)		
				{
					if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
					else { COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
				}
				/* 2 - 1 */
				else if(numDR == 1)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 1)
					{
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
						else
						{	
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col,lin-1);							
						}
						
						if(nFreeOrLamp(col+1,lin+1,brd) == 1) insLamps(col+1,lin+1,brd);
					}
					else SOL=0;
				}
				/* 2 - 2 */
				else if(numDR == 2)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 2) 
					{
						if(IS_IN_LAMP(col-1,lin) && IS_IN_LAMP(col,lin-1))
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0;
							else { COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
						}
						
						if(IS_IN_LAMP(col+2,lin+1) && IS_IN_LAMP(col+1,lin+2))
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
							else { COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
						}
						
						if((IS_IN_LAMP(col-1,lin) || IS_IN_LAMP(col,lin-1)) && 
						   (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2)))) 	   
								{ COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }

						if((IS_IN_LAMP(col+2,lin+1) || IS_IN_LAMP(col,lin-1)) && 
						   (!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))))	   
								{ COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
						
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 2) insLamps(col+1,lin+1,brd);
					}
					else SOL = 0;	
				}
				/* 2 - 3 */
				else if(numDR == 3)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3) 
					{
						if(IS_IN_LAMP(col-1,lin) || IS_IN_LAMP(col,lin-1))
						{
							if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1) && IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2)) 	   
								{ COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
							else SOL = 0;
						}	
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col+1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}	
						
						if(nFreeOrLamp(col,lin,brd) == 2)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 3) insLamps(col+1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 2 - 4 */
				else if(numDR == 4) 
				{
					if(nFreeOrLamp(col+1,lin+1,brd) == 4) insLamps(col+1,lin+1,brd);
					else SOL=0;
				}
			}
			else SOL=0;
		}
		
		else if(num==3)
		{
			if(nFreeOrLamp(col,lin,brd) >= 3)
			{
				/* 3 - 0 */
				if(numDR == 0) SOL=0;
				/* 3 - 1 */
				else if(numDR == 1) 
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 1)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
						else { COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
						
						if(IS_IN_LAMP(col+2,lin+1) || IS_IN_LAMP(col+1,lin+2)) SOL = 0;
						else if(flagrsv) { MARCA(col+2,lin+1); MARCA(col+1,lin+2); }
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col+1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}
						
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 1) insLamps(col+1,lin+1,brd);
					}	
					else SOL=0;
				}
				/* 3 - 2 */
				else if(numDR == 2)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 2) 
					{
						if(IS_IN_LAMP(col+2,lin+1) || IS_IN_LAMP(col+1,lin+2))
						{	
							if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin) && IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))   
								{ COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }
							else SOL = 0;
						}	
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col+1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}	
						
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 2) insLamps(col+1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 3 - 3 */
				else if(numDR == 3)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3) 
					{
						if(IS_IN_LAMP(col-1,lin) && IS_IN_LAMP(col,lin-1)) 
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0;
							else { COL_LAMP(col+2,lin+1); COL_LAMP(col+1,lin+2); }
						}
						
						if(IS_IN_LAMP(col+2,lin+1) && IS_IN_LAMP(col+1,lin+2))
						{
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) || !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
							else { COL_LAMP(col-1,lin); COL_LAMP(col,lin-1); }							
						}
						
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col+1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1))) COL_LAMP(col,lin+1);
						}	
						
						if(nFreeOrLamp(col,lin,brd) == 3)	  insLamps(col,lin,brd);
						if(nFreeOrLamp(col+1,lin+1,brd) == 3) insLamps(col+1,lin+1,brd);
					}
					else SOL = 0;
				}
				/* 3 - 4 */
				else if(numDR == 4) 
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 4)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col-1,lin);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1))) COL_LAMP(col,lin-1);
						}
						
						insLamps(col+1,lin+1,brd);
					}
					else SOL = 0;
				}
			}
			else SOL = 0;
		}
		
		else if(num==4)	
		{
			if(nFreeOrLamp(col,lin,brd) >= 4)
			{
				/* 4 - 0 */
				if(numDR == 0) SOL=0;
				/* 4 - 1 */
				else if(numDR == 1) SOL=0;
				/* 4 - 2 */
				else if(numDR == 2) 
				{
					if(nFreeOrLamp(col,lin,brd) == 4) insLamps(col,lin,brd);
					else SOL=0;
				}
				/* 4 - 3 */
				if(numDR == 3)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 3)
					{
						if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) SOL = 0;
						else
						{
							if( (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) && !(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) COL_LAMP(col+2,lin+1);
							if(!(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+2,lin+1)) &&  (IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin+2))) COL_LAMP(col+1,lin+2);
						}
						
						insLamps(col,lin,brd);
					}
					else SOL=0;
				}
				/* 4 - 4 */
				else if(numDR == 4)
				{
					if(nFreeOrLamp(col+1,lin+1,brd) >= 4) insLamps(col+1,lin+1,brd);
					else SOL=0;
					insLamps(col,lin,brd);
				}
			}	
			else SOL=0;
		}
	}

	return brd;
}

#endif