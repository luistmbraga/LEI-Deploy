#ifndef ___EST5_C___
#define ___EST5_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"
#include "est1.h"
#include "est5.h"

BOARD *do_est5(BOARD *brd, int alts, int flagrsv)
/** Corre a estratégia 5.
 * \param *brd - Tabuleiro 
 * \param alts - Número de undo's na pilha de undo's (até à primeira marca)
 * \param flagrsv - Flag que indica se o comando foi invocado pelo comando rsv 
 */
{
	int col,lin;
	
	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
		{
			if(IS_FREE_NOT_ILUM(col,lin) && nCasasFreeNotIlum(col,lin,brd) == 0) COL_LAMP(col,lin);
			else if(IS_NO_LAMP_NOT_ILUM(col,lin) && nCasasFreeNotIlum(col,lin,brd) == 1) colLampCasaLivre(col,lin,brd);
			else if(IS_NO_LAMP_NOT_ILUM(col,lin) && nCasasFreeNotIlum(col,lin,brd) == 0) SOL = 0;
		}
	
	if(alts != nAlts(brd->pilha)) return do_est5(brd,nAlts(brd->pilha),flagrsv);
	else 
	{
		if(brd->pilha && top(brd->pilha).ilum!=-1 && !flagrsv) brd->pilha = push(brd->pilha,0,0,-1,1,0);
		return brd; 
	}	
}

int nCasasFreeNotIlum(int col, int lin, BOARD *brd)
/** Retorna o número de casas na mesma linha e coluna da casa recebida, que estão livres (e não iluminadas) e dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	int i,n=0;
	
	for(i=col-1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(i,lin) && n<=2 && n!=-1; i--) 
	{
		if(IS_FREE_NOT_ILUM(i,lin)) n++;
		if(IS_LAMP(i,lin)) n = -1;
	}	
	for(i=col+1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(i,lin) && n<=2 && n!=-1; i++) 
	{	
		if(IS_FREE_NOT_ILUM(i,lin)) n++;
		if(IS_LAMP(i,lin)) n = -1;
	}	
	for(i=lin-1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(col,i) && n<=2 && n!=-1; i--) 
	{	
		if(IS_FREE_NOT_ILUM(col,i)) n++;
		if(IS_LAMP(col,i)) n = -1;
	}	
	for(i=lin+1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(col,i) && n<=2 && n!=-1; i++) 
	{	
		if(IS_FREE_NOT_ILUM(col,i)) n++;
		if(IS_LAMP(col,i)) n = -1;
	}	
	
	return n;

}

BOARD *colLampCasaLivre(int col, int lin, BOARD *brd)
/** Coloca uma lâmpada na primeira casa livre (e não iluminada) que encontrar na mesma linha ou coluna da casa recebida. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{	
	int i,lamp=0;
	
	for(i=col-1; IS_IN_FREE_OR_NO_LAMP(i,lin) && !lamp; i--) if(IS_FREE_NOT_ILUM(i,lin)) { COL_LAMP(i,lin); lamp = 1; }
	for(i=col+1; IS_IN_FREE_OR_NO_LAMP(i,lin) && !lamp; i++) if(IS_FREE_NOT_ILUM(i,lin)) { COL_LAMP(i,lin); lamp = 1; }
	for(i=lin-1; IS_IN_FREE_OR_NO_LAMP(col,i) && !lamp; i--) if(IS_FREE_NOT_ILUM(col,i)) { COL_LAMP(col,i); lamp = 1; }
	for(i=lin+1; IS_IN_FREE_OR_NO_LAMP(col,i) && !lamp; i++) if(IS_FREE_NOT_ILUM(col,i)) { COL_LAMP(col,i); lamp = 1; }
	
	return brd;	
}

#endif