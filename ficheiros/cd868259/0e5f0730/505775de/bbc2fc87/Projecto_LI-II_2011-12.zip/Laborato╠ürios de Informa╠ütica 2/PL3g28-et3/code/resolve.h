#ifndef ___RESOLVE_H___
#define ___RESOLVE_H___

BOARD *do_rsv(BOARD *brd);
BOARD *correrEsts(BOARD *brd, int alts, int flagQuantasAlt, int flaggera);
int isSolved(BOARD *brd);
int tudoJogado(BOARD *brd);
BOARD *quantasAlt(BOARD *brd);
BOARD *quantasAlt2(BOARD *brd);
BOARD *initHeuristic(BOARD *brd);
void printHeuristic(BOARD *brd);
BOARD *estsAndHeur(int alts, BOARD *brd);

#endif