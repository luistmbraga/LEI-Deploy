#ifndef ___EST4_H___
#define ___EST4_H___

BOARD *do_est4(BOARD *brd, int alts, int flagrsv);
BOARD *casosEst4(int col, int lin, int num, int flagrsv, BOARD *brd);

#endif