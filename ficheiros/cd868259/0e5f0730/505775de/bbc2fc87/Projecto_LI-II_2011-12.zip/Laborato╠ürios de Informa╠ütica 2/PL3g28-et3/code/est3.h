#ifndef ___EST3_H___
#define ___EST3_H___

BOARD *do_est3(BOARD *brd, int alts, int flagrsv);
BOARD *noLampsOrto(int col, int lin, BOARD *brd);
BOARD *noLampsDiag43(int col, int lin, BOARD *brd);
BOARD *noLampsDiag2(int col, int lin, int num, int lamps, BOARD *brd);
BOARD *noLampsDiag1(int col, int lin, int num, int lamps, BOARD *brd);
BOARD *lampsMarca(int col, int lin, BOARD *brd);
int todasMarcadas(int col, int lin, BOARD *brd);
BOARD *marca(int col, int lin, BOARD *brd);

#endif