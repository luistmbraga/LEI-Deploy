#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "lista_comandos.h"
#include "erro.h"

/** 
 * \file interpretador.c
 * \brief Programa principal
 * 
 * É o que está visível ao utilizador. Aqui, ele insere os comandos que lhe permitem jogar.
 */

/** 
 * \file comandos.c
 * \brief Comandos e estratégias
 * 
 * Chamada dos comandos e das estratégias.
 */

/** 
 * \file comandos.h
 * \brief Assinatura de comandos
 * 
 * Assinatura das funções relativas aos comandos, estratégias e funções auxiliares.
 */

/** 
 * \file erro.h
 * \brief Mensagens de erro
 * 
 * Assinatura da função \a mensagem_de_erro e definição dos erros possíveis.
 */

/** 
 * \file erro.c
 * \brief Estrutura de erro
 * 
 * Definição da estrutura de erro e implementação da função \a mensagem_de_erro. 
 */

/** 
 * \file lista_comandos.h
 * \brief Estrutura de comandos
 * 
 * Definição da estrutura de comando e lista de comandos disponíveis.
 */

/** 
 * \file tabuleiro.h
 * \brief Estrutura de tabuleiro
 * 
 *  Definição da estrutura de tabuleiro e de estado.
 */

/** 
 * \file anula_joga.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas ao comando anula e joga. 	
 */

/** 
 * \file anula_joga.c
 * \brief Anula e Joga
 * 
 * Implementação dos comandos anula e joga.
 */

/** 
 * \file carrega_grava.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas ao comando carrega e grava.
 */

/** 
 * \file carrega_grava.c
 * \brief Carrega e grava
 * 
 * Implementação dos comandos carrega e grava.
 */

/** 
 * \file est1.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas à estratégia 1.
 */

/** 
 * \file est1.c
 * \brief Estratégia 1
 * 
 * Implementação da estratégia 1.
 */

/** 
 * \file est2.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas à estratégia 2.
 */

/** 
 * \file est2.c
 * \brief Estratégia 2
 * 
 * Implementação da estratégia 2.
 */

/** 
 * \file est3.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas à estratégia 3.
 */

/** 
 * \file est3.c
 * \brief Estratégia 3
 * 
 * Implementação da estratégia 3.
 */

/** 
 * \file est4.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas à estratégia 4.
 */

/** 
 * \file est4.c
 * \brief Estratégia 4
 * 
 * Implementação da estratégia 4.
 */

/** 
 * \file est5.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas à estratégia 5.
 */

/** 
 * \file est5.c
 * \brief Estratégia 5
 * 
 * Implementação da estratégia 5.
 */

/** 
 * \file est6.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas à estratégia 5.
 */

/** 
 * \file est6.c
 * \brief Estratégia 6
 * 
 * Implementação da estratégia 6.
 */

/** 
 * \file resolve.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas ao resolve.
 */

/** 
 * \file resolve.c
 * \brief Resolve
 * 
 * Implementação do resolve.
 */

/** 
 * \file gera.h
 * \brief Assinaturas
 * 
 * Assinaturas das funções relativas ao gera.
 */

/** 
 * \file gera.c
 * \brief Gera
 * 
 * Implementação do gera.
 */

/** 
 * \file pilha.h 
 * \brief Estrutura de pilha
 * 
 * Definação da estrutra de pilha e assinaturas das funções de manipulação de pilha.
 */

/** 
 * \file pilha.c 
 * \brief
 * 
 * Implementação das funções de manipulação de pilha.
 */


/*! \mainpage Etapa 3
 *
 * \section Autores
 * Hugo Mendes e Tiago Conceição
 *
 * Para a terceira etapa foi implementada resolução de tabuleiros e um gerador de tabuleiros. \n  	
 * Foi ainda analisado o assembly gerado pela função contar_lampadas.\n
 *
*/ 

/** Prompt da aplicação. */
static char *prompt = "Illuminatus> "; 
/** Variável para guardar o input. */
static char *line_read = (char *)NULL;

char *rl_gets ()
/**
 * Função que lê o input do utilizador.
 */
{
  /* If the buffer has already been allocated,
     return the memory to the free pool. */
  if (line_read)
    {
      free (line_read);
      line_read = (char *)NULL;
    }

  /* Get a line from the user. */
  line_read = readline (prompt);

  /* If the line has any text in it,
     save it on the history. */
  if (line_read && *line_read)
    add_history (line_read);

  return (line_read);
}

FUNCTION *find_command(char *cmd) 
/**
 * Função que procura o comando e retorna o apontador para a função associada ou NULL caso o comando nao esteja na lista de comandos.
 */
{
	int i;
	for(i=0; command[i].name != NULL && strcmp(command[i].name, cmd) != 0; i++);

	if(command[i].name != NULL) 
	{
		/*if(command[i].undoable) fazer algo para saber como desfazer o estado*/
		return command[i].func;
	} else
		return NULL;
}


BOARD *cmd_help(char *args, BOARD *brd) 
/**
 * Implementação do comando ? que apenas imperime a função de cada comando.
 */
{
	int i;
	
	args = NULL; /* 'Set' e 'Use' de *args*/
	if(args==NULL)
		
	for(i = 0; command[i].name != NULL; i++)
		printf("%s: %s\n", command[i].name, command[i].doc);

	return brd;
}

int main() 
/**
 * Implementação do interpretador de comandos.
 */
{
	char *cmd = NULL;
	FUNCTION *fun = NULL;
	BOARD * brd = NULL;

	srand(time(NULL));
	brd = initialize_state();

	while(rl_gets() != NULL) {
		int i, j;

		/* Ignorar os espacos no inicio do comando */
		for(i=0; line_read[i] && isspace(line_read[i]); i++);

		/* Saltar a primeira palavra da linha */
		for(j = i; line_read[j] && !isspace(line_read[j]); j++);

		/* Delimitar o nome do comando */
		if(line_read[j]) line_read[j++] = 0;

		 /* Saltar os espacos mais uma vez */
		for(; line_read[j] && isspace(line_read[j]); j++);

		cmd = line_read + i;

		fun = find_command(cmd);
		
		if(fun != NULL) 
		{
			brd = fun(line_read + j, brd);
			print_state(brd);
		} 
		else 
		{
			mensagem_de_erro(E_COMMAND);
		}
	}

	return 0;
}
