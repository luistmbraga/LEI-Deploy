#ifndef ___ANULA_JOGA_C___
#define ___ANULA_JOGA_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"
#include "anula_joga.h"

BOARD *do_an(BOARD *brd, int flagrsv, int flaggera)
/** Anula um comando.
 * \param *brd - Tabuleiro 
 * \param flagrsv - Flag que indica se o comando foi chamado pelo comando rsv.
 * \param flaggera - Flag que indica se o comando foi chamado pelo comando gera. 
 */
{
	int col,lin;
	
	if(brd->pilha && !flagrsv)
	{
		if(top(brd->pilha).ilum==-1) brd->pilha = pop(brd->pilha);
		
		while(brd->pilha && brd->pilha->undo.ilum!=-1)
		{
			col = brd->pilha->undo.col;
			lin = brd->pilha->undo.lin;
			
			if(brd->pilha->undo.state == FREE)			LETTER(col,lin) = '-';
			else if(brd->pilha->undo.state == LAMP)		LETTER(col,lin) = '@';
			else if(brd->pilha->undo.state == NO_LAMP)	LETTER(col,lin) = '.'; 
			
			ILUM(col,lin) = brd->pilha->undo.ilum;
			SOL = brd->pilha->undo.sol;
			STATE(col,lin) = brd->pilha->undo.state;
			
			brd->pilha = pop(brd->pilha);
		}
	} 
	else if(brd->pilha && flagrsv == 1)
	{
		if(top(brd->pilha).ilum==-2) brd->pilha = pop(brd->pilha);
		
		while(brd->pilha && brd->pilha->undo.ilum!=-2 && brd->pilha->undo.ilum!=-3)
		{
			col = brd->pilha->undo.col;
			lin = brd->pilha->undo.lin;
			
			if(brd->pilha->undo.state == FREE)			LETTER(col,lin) = '-';
			else if(brd->pilha->undo.state == LAMP)		LETTER(col,lin) = '@';
			else if(brd->pilha->undo.state == NO_LAMP)	LETTER(col,lin) = '.'; 
			
			ILUM(col,lin) = brd->pilha->undo.ilum;
			SOL = brd->pilha->undo.sol;
			STATE(col,lin) = brd->pilha->undo.state;
			
			brd->pilha = pop(brd->pilha);
		}
	}
	else if(!flaggera) { mensagem_de_erro(E_NO_MOVES); }
	
	return brd;	
	
}

BOARD *do_joga(int col, int lin, BOARD *brd)
/** Joga numa casa do tabuleiro.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	int i;
	
	if(IS_FREE(col,lin) || IS_NO_LAMP(col,lin)) 
	{
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),SOL,STATE(col,lin));
		ILUM(col,lin) = 1;
		LETTER(col,lin) ='@';
		STATE(col,lin) = LAMP;
		
		for(i=col-1; IS_IN(i,lin) && (IS_FREE(i,lin) || IS_NO_LAMP(i,lin) || IS_LAMP(i,lin)) && SOL; i--) 
		{	
			brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),SOL,STATE(i,lin));
			if(IS_LAMP(i,lin)) SOL = 0;
			ILUM(i,lin) = 1;
		}
		for(i=col+1; IS_IN(i,lin) && (IS_FREE(i,lin) || IS_NO_LAMP(i,lin) || IS_LAMP(i,lin)) && SOL; i++) 
		{ 
			brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),SOL,STATE(i,lin)); 
			if(IS_LAMP(i,lin)) SOL = 0;
			ILUM(i,lin) = 1;
		}
		for(i=lin-1; IS_IN(col,i) && (IS_FREE(col,i) || IS_NO_LAMP(col,i) || IS_LAMP(col,i)) && SOL; i--) 
		{ 
			brd->pilha = push(brd->pilha,col,i,ILUM(col,i),SOL,STATE(col,i)); 
			if(IS_LAMP(col,i)) SOL = 0;
			ILUM(col,i) = 1;
		}
		for(i=lin+1; IS_IN(col,i) && (IS_FREE(col,i) || IS_NO_LAMP(col,i) || IS_LAMP(col,i)) && SOL; i++) 
		{ 
			brd->pilha = push(brd->pilha,col,i,ILUM(col,i),SOL,STATE(col,i)); 
			if(IS_LAMP(col,i)) SOL = 0;
			ILUM(col,i) = 1;
		}	
	}
	else if(IS_LAMP(col,lin))
	{
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),SOL,STATE(col,lin));
		ILUM(col,lin) = 0;
		LETTER(col,lin) ='-';
		STATE(col,lin) = FREE;
		
		for(i=col-1; IS_IN(i,lin) && (IS_FREE(i,lin) || IS_NO_LAMP(i,lin)); i--) 
		{	
			brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),SOL,STATE(i,lin));
			ILUM(i,lin) = 0;
		}
		for(i=col+1; IS_IN(i,i) && (IS_FREE(i,lin) || IS_NO_LAMP(i,lin)); i++) 
		{ 
			brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),SOL,STATE(i,lin)); 
			ILUM(i,lin) = 0;
		}
		for(i=lin-1; IS_IN(col,i) && (IS_FREE(col,i) || IS_NO_LAMP(col,i)); i--) 
		{ 
			brd->pilha = push(brd->pilha,col,i,ILUM(col,i),SOL,STATE(col,i)); 
			ILUM(col,i) = 0;
		}
		for(i=lin+1; IS_IN(col,i) && (IS_FREE(col,i) || IS_NO_LAMP(col,i)); i++) 
		{ 
			brd->pilha = push(brd->pilha,col,i,ILUM(col,i),SOL,STATE(col,i)); 
			ILUM(col,i) = 0;
		}		
	}
	else { mensagem_de_erro(E_BLOC); }

	if(brd->pilha && top(brd->pilha).ilum != -1) brd->pilha = push(brd->pilha,0,0,-1,1,0);
	
	return brd;
}	

#endif