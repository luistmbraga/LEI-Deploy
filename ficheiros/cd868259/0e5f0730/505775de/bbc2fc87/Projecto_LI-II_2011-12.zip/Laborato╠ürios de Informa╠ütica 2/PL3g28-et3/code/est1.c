#ifndef ___EST1_C___
#define ___EST1_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"
#include "est1.h"

BOARD *do_est1(BOARD *brd, int flagrsv)
/** Corre a estratégia 1.
 * \param *brd - Tabuleiro
 * \param flagrsv - Flag que indica se o comando foi invocado pelo comando rsv 
 */
{	
	int col,lin,num,nfl;

	for(lin=0; lin<brd->linha; lin++)
		for(col=0; col<brd->coluna; col++)
			if(IS_NUM(col,lin))
			{	
				num = getNUM(col,lin,brd);
				nfl = nFreeOrLamp(col,lin,brd);
				if((num > nfl || nCasasLamp(col,lin,brd) > num)) SOL = 0;
				if(num != 0 && num == nfl) insLamps(col,lin,brd);
			}
		
	if(brd->pilha && top(brd->pilha).ilum != -1 && !flagrsv) brd->pilha = push(brd->pilha,0,0,-1,1,0);

	return brd;
}

int getNUM(int col, int lin, BOARD *brd)
/** Retorna o número de uma casa.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=-1;
	
	if(IS_NUM(col,lin))
	{
		if(LETTER(col,lin)=='0') n=0;
		if(LETTER(col,lin)=='1') n=1;
		if(LETTER(col,lin)=='2') n=2;
		if(LETTER(col,lin)=='3') n=3;
		if(LETTER(col,lin)=='4') n=4;
	}
	
	return n;
}

int nFreeOrLamp(int col,int lin, BOARD *brd)
/** Retorna o número de casas à volta de uma casa que estão livres (e não iluminadas) ou têm uma lâmpada e que estão dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=0;
	
	if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin)) n++; 
	if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin)) n++;
	if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1)) n++;
	if(IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1)) n++;
	
	return n;	
}

int nCasasLamp(int col,int lin, BOARD *brd)
/** Retorna o número de casas à volta de uma casa que têm uma lâmpada e que estão dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=0;
	
	if(IS_IN_LAMP(col-1,lin)) n++;
	if(IS_IN_LAMP(col+1,lin)) n++;
	if(IS_IN_LAMP(col,lin-1)) n++;
	if(IS_IN_LAMP(col,lin+1)) n++;
	
	return n;
}

BOARD *insLamps(int col, int lin, BOARD *brd)
/** Insere lâmpadas á volta de uma casa, se ela estiver livre (e não iluminada) e dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	if(IS_IN_FREE_NOT_ILUM(col-1,lin)) COL_LAMP(col-1,lin);
	if(IS_IN_FREE_NOT_ILUM(col+1,lin)) COL_LAMP(col+1,lin); 
	if(IS_IN_FREE_NOT_ILUM(col,lin-1)) COL_LAMP(col,lin-1);	
	if(IS_IN_FREE_NOT_ILUM(col,lin+1)) COL_LAMP(col,lin+1);			
	
	return brd;
}

BOARD *colLamp(int col, int lin, BOARD *brd)
/** Coloca uma lâmpada numa casa, se ela estiver livre (e não iluminada) e dentro do tabuleiro. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	int i;
	
	if(IS_IN_FREE_NOT_ILUM(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),SOL,STATE(col,lin));
		ILUM(col,lin) = 1;
		LETTER(col,lin) = '@'; 
		STATE(col,lin) = LAMP;
		
		for(i=col-1; IS_IN(i,lin) && (IS_FREE(i,lin) || IS_NO_LAMP(i,lin) || IS_LAMP(i,lin)) && SOL; i--)
		{	
			if(IS_LAMP(i,lin)) SOL = 0;
			else if(!ILUM(i,lin))
			{ 
				brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),SOL,STATE(i,lin)); 
				ILUM(i,lin) = 1;
			}
		}	
		for(i=col+1; IS_IN(i,lin) && (IS_FREE(i,lin) || IS_NO_LAMP(i,lin) || IS_LAMP(i,lin)) && SOL; i++) 
		{	
			if(IS_LAMP(i,lin)) SOL = 0;	
			else if(!ILUM(i,lin))
			{ 
				brd->pilha = push(brd->pilha,i,lin,ILUM(i,lin),SOL,STATE(i,lin)); 
				ILUM(i,lin) = 1;
			}
			
		}	
		for(i=lin-1; IS_IN(col,i) && (IS_FREE(col,i) || IS_NO_LAMP(col,i) || IS_LAMP(col,i)) && SOL; i--) 
		{	
			if(IS_LAMP(col,i)) SOL = 0;
			else if(!ILUM(col,i))
			{ 
				brd->pilha = push(brd->pilha,col,i,ILUM(col,i),SOL,STATE(col,i)); 
				ILUM(col,i) = 1;
			}
			
		}	
		for(i=lin+1; IS_IN(col,i) && (IS_FREE(col,i) || IS_NO_LAMP(col,i) || IS_LAMP(col,i)) && SOL; i++) 
		{	
			if(IS_LAMP(col,i)) SOL = 0;	
			else if(!ILUM(col,i))
			{ 
				brd->pilha = push(brd->pilha,col,i,ILUM(col,i),SOL,STATE(col,i)); 
				ILUM(col,i) = 1;
			}		
			
		}
	}
	
	return brd;
}

#endif