#ifndef ___PILHA_H___
#define ___PILHA_H___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

typedef enum 
{
	FREE,	 /*!< Casa não bloqueada sem lâmpada. */ 
	BLOQ,	 /*!< Casa bloqueada. */
	NUM,	 /*!< Casa bloqueada com número. */
	LAMP,	 /*!< Casa com lâmpada. */
	NO_LAMP /*!< Casa que não pode conter uma lâmpada. */
} STATE;

typedef struct undo
/** Um Undo é composto por uma coordenada, o ilum anterior e o state anterior.
 */
{
	int col,	/*!< Coluna. */
		lin,	/*!< Linha. */
		ilum,	/*!< Iluminado anterior. */
		sol;	/*!< Solução anterior. */
	STATE state; /*!< Estado anterior. */
} UNDO;

typedef struct pilhaundo
/** Uma Pilha de Undo's é constituída por um undo, e o apontador para o Undo seguinte.
 */
{	
	UNDO undo;
	struct pilhaundo *seg;
} *PILHAUNDO, N_PILHAUNDO;

PILHAUNDO push(PILHAUNDO pilha, int col, int lin, int ilum, int sol, STATE state);
PILHAUNDO pop(PILHAUNDO pilha);
UNDO top(PILHAUNDO pilha);
PILHAUNDO clearPilha(PILHAUNDO pilha);
void listaPilha(PILHAUNDO pilha);
int nAlts(PILHAUNDO pilha);

#endif