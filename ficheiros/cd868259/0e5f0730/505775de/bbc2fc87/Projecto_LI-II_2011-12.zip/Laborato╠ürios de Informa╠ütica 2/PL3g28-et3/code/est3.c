#ifndef ___EST3_C___
#define ___EST3_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est1.h"
#include "est3.h"

BOARD *do_est3(BOARD *brd, int alts, int flagrsv)
/** Corre a estratégia 3.
 * \param *brd - Tabuleiro 
 * \param alts - Número de undo's na pilha de undo's (até à primeira marca)
 * \param flagrsv - Flag que indica se o comando foi invocado pelo comando rsv 
 */
{
	int col,lin,num,lamps;
	
	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
		{
			if(IS_NUM(col,lin) && !todasMarcadas(col,lin,brd))
			{	
				num = getNUM(col,lin,brd);
				lamps = nCasasLamp(col,lin,brd);
				
				lampsMarca(col,lin,brd);
				
				if(num == lamps && !todasMarcadas(col,lin,brd))			  noLampsOrto(col,lin,brd);
				if((num == 4 || num == 3) && !todasMarcadas(col,lin,brd)) noLampsDiag43(col,lin,brd);
				if(num == 2 && !todasMarcadas(col,lin,brd))				  noLampsDiag2(col,lin,num,lamps,brd);
				if(num == 1 && !todasMarcadas(col,lin,brd))				  noLampsDiag1(col,lin,num,lamps,brd);
			}	
		}	
	if(alts != nAlts(brd->pilha)) return do_est3(brd,nAlts(brd->pilha),flagrsv);
	else 
	{
		if(brd->pilha && top(brd->pilha).ilum!=-1 && !flagrsv) brd->pilha = push(brd->pilha,0,0,-1,1,0);
		return brd;
	}
				
}

BOARD *noLampsOrto(int col, int lin, BOARD *brd)
/** Marca as casas á volta de uma casa, ortogonalmente. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{	
	if(IS_IN_FREE(col-1,lin)) MARCA(col-1,lin); 	
	if(IS_IN_FREE(col+1,lin)) MARCA(col+1,lin); 
	if(IS_IN_FREE(col,lin-1)) MARCA(col,lin-1); 			
	if(IS_IN_FREE(col,lin+1)) MARCA(col,lin+1); 			
	
	return brd;	
}

BOARD *noLampsDiag43(int col, int lin, BOARD *brd)
/** Marca as casas á volta de uma casa, diagonalmente. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{	
	if(IS_IN_FREE(col-1,lin-1)) MARCA(col-1,lin-1);			
	if(IS_IN_FREE(col+1,lin-1)) MARCA(col+1,lin-1); 	
	if(IS_IN_FREE(col-1,lin+1)) MARCA(col-1,lin+1);			
	if(IS_IN_FREE(col+1,lin+1)) MARCA(col+1,lin+1);		
	
	return brd;	
}

BOARD *noLampsDiag2(int col, int lin, int num, int lamps, BOARD *brd)
/** Marca as casas á volta de uma casa, diagonalmente, caso o número da casa recebida seja 2. 
 * \param col - Coluna
 * \param lin - Linha
 * \param num - Número na coordenada recebida
 * \param lamps - Número de lâmpadas à volta da coordenada recebida, ortogonalmente
 * \param *brd - Tabuleiro 
 */
{	
	/* lt->esquerda, rt->direita, up->cima, dn->baixo, f->livre */
	int lt,rt,up,dn,ltf,rtf,upf,dnf;
	
	lt = IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin);
	rt = IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin);
	up = IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1);
	dn = IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1);
	
	ltf = IS_IN_FREE_NOT_ILUM(col-1,lin);
	rtf = IS_IN_FREE_NOT_ILUM(col+1,lin);
	upf = IS_IN_FREE_NOT_ILUM(col,lin-1);
	dnf = IS_IN_FREE_NOT_ILUM(col,lin+1);
	
	if(num != lamps)
	{	
		if((!lt && !rt) || (!up && !dn)) noLampsDiag43(col,lin,brd);
		if(!lt && !up) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); MARCA(col-1,lin+1); }
		if(!lt && !dn) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
		if(!rt && !up) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
		if(!rt && !dn) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); MARCA(col-1,lin+1); }
		
		if(!lt) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
		if(!rt) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); }
		if(!up) { MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
		if(!dn) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); }
		
		if(!ltf && !upf) MARCA(col+1,lin+1);
		if(!ltf && !dnf) MARCA(col+1,lin-1);
		if(!rtf && !upf) MARCA(col-1,lin+1); 
		if(!rtf && !dnf) MARCA(col+1,lin-1);		
	}
	
	return brd;	
}

BOARD *noLampsDiag1(int col, int lin, int num, int lamps, BOARD *brd)
/** Marca as casas á volta de uma casa, diagonalmente, caso o número da casa recebida seja 1. 
 * \param col - Coluna
 * \param lin - Linha
 * \param num - Número na coordenada recebida
 * \param lamps - Número de lâmpadas à volta da coordenada recebida, ortogonalmente
 * \param *brd - Tabuleiro 
 */
{	
	/* lt->esquerda, rt->direita, up->cima, dn->baixo, f->livre */
	int lt,rt,up,dn,ltf,rtf,upf,dnf;
	
	lt = IS_IN_FREE_NOT_ILUM_OR_LAMP(col-1,lin);
	rt = IS_IN_FREE_NOT_ILUM_OR_LAMP(col+1,lin);
	up = IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin-1);
	dn = IS_IN_FREE_NOT_ILUM_OR_LAMP(col,lin+1);
	
	ltf = IS_IN_FREE_NOT_ILUM(col-1,lin);
	rtf = IS_IN_FREE_NOT_ILUM(col+1,lin);
	upf = IS_IN_FREE_NOT_ILUM(col,lin-1);
	dnf = IS_IN_FREE_NOT_ILUM(col,lin+1);
	
	if(num != lamps)
	{	
		if(!upf && !rtf && !dnf) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); }	
		if(!ltf && !upf && !rtf) { MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
		if(!upf && !ltf && !dnf) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
		if(!ltf && !dnf && !rtf) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); }
	
		if(!lt && !up) MARCA(col+1,lin+1);
		if(!lt && !dn) MARCA(col+1,lin-1);
		if(!rt && !up) MARCA(col-1,lin+1);			
		if(!rt && !dn) MARCA(col-1,lin-1);	
	}
	
	return brd;	
}	

BOARD *lampsMarca(int col, int lin, BOARD *brd)
/** Marca as casas á volta de uma casa, se houver lâmpadas á volta da casa recebida. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{	
	if(IS_IN_LAMP(col-1,lin)) { MARCA(col-1,lin-1); MARCA(col-1,lin+1); }
	if(IS_IN_LAMP(col+1,lin)) { MARCA(col+1,lin-1); MARCA(col+1,lin+1); }
	if(IS_IN_LAMP(col,lin-1)) { MARCA(col-1,lin-1); MARCA(col+1,lin-1); }
	if(IS_IN_LAMP(col,lin+1)) { MARCA(col-1,lin+1); MARCA(col+1,lin+1); }
	
	if(IS_IN(col-1,lin-1) && IS_LAMP(col-1,lin-1)) 
	{ 
		MARCA(col-1,lin); 
		if(!(IS_NUM_OR_BLOQ(col-1,lin))	MARCA(col-1,lin+1); 		
		MARCA(col,lin-1); 
		if(!(IS_NUM_OR_BLOQ(col,lin-1))	MARCA(col+1,lin-1); 
	}
	if(IS_IN(col+1,lin-1) && IS_LAMP(col+1,lin-1)) 
	{ 
		MARCA(col+1,lin); 
		if(!(IS_NUM_OR_BLOQ(col+1,lin))	MARCA(col+1,lin+1); 
		MARCA(col,lin-1); 
		if(!(IS_NUM_OR_BLOQ(col,lin-1))	MARCA(col-1,lin-1); 
	}
	if(IS_IN(col-1,lin+1) && IS_LAMP(col-1,lin+1)) 
	{ 
		MARCA(col-1,lin); 
		if(!(IS_NUM_OR_BLOQ(col-1,lin))	MARCA(col-1,lin-1); 
		MARCA(col,lin+1); 
		if(!(IS_NUM_OR_BLOQ(col,lin+1))	MARCA(col+1,lin+1); 
	}
	if(IS_IN(col+1,lin+1) && IS_LAMP(col+1,lin+1)) 
	{ 
		MARCA(col+1,lin); 
		if(!(IS_NUM_OR_BLOQ(col+1,lin))	MARCA(col+1,lin-1); 
		MARCA(col,lin+1); 
		if(!(IS_NUM_OR_BLOQ(col,lin+1))	MARCA(col-1,lin+1); 
	}
	
	return brd;
}

int todasMarcadas(int col, int lin, BOARD *brd)
/** Retorna 1 se as casas à volta de uma casa estiverem todas marcadas, 0 caso contrátio.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	
	if(!(IS_IN_FREE_NOT_ILUM(col-1,lin)) && !(IS_IN_FREE_NOT_ILUM(col+1,lin)) && !(IS_IN_FREE_NOT_ILUM(col,lin-1)) && !(IS_IN_FREE_NOT_ILUM(col,lin+1))
	   && !(IS_IN_FREE_NOT_ILUM(col-1,lin-1)) && !(IS_IN_FREE_NOT_ILUM(col+1,lin-1)) && !(IS_IN_FREE_NOT_ILUM(col-1,lin+1)) && !(IS_IN_FREE_NOT_ILUM(col+1,lin+1)))
		return 1;
	else return 0;
}

BOARD *marca(int col, int lin, BOARD *brd)
/** Marca uma casa, se ela estiver livre e dentro do tabuleiro.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	if(IS_IN_FREE(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),SOL,STATE(col,lin));
		LETTER(col,lin) = '.'; 
		STATE(col,lin) = NO_LAMP;		
	}
	
	return brd;	
}

#endif