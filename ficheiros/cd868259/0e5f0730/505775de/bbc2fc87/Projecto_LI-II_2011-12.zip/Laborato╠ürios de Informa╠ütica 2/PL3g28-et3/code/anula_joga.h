#ifndef ___ANULA_JOGA_H___
#define ___ANULA_JOGA_H___

BOARD *do_joga(int col, int lin, BOARD *brd);
BOARD *do_an(BOARD *brd, int flagrsv, int flaggera);

#endif
