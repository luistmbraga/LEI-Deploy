#ifndef ___EST6_C___
#define ___EST6_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"
#include "est1.h"
#include "est5.h"
#include "est6.h"

BOARD *do_est6(BOARD *brd, int alts)
/** Corre a estratégia 6.
 * \param *brd - Tabuleiro 
 * \param alts - Número de undo's na pilha de undo's (até à primeira marca)
 */
{
	int col,lin;
	
	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
			if(IS_NO_LAMP_NOT_ILUM(col,lin) && nCasasFreeNotIlum(col,lin,brd) == 2) 
				comparaDiags(col,lin,brd);
	
	if(alts != nAlts(brd->pilha)) return do_est6(brd,nAlts(brd->pilha));
	else return brd;
}

BOARD *comparaDiags(int col, int lin, BOARD *brd)
/** Compara as 4 diagonais possíveis de um possível quadrilátero definido por uma casa marcada e 3 livres (nenhuma iluminada).
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	int x,y,lamps=0;
	PILHAUNDO aux,aux2;
	
	aux = getCoords(col,lin,brd);
	x = abs(aux->undo.col-aux->seg->undo.col);
	y = abs(aux->undo.lin-aux->seg->undo.lin);
	
	if(IS_IN_FREE(col-x,lin-y) && nCasasFreeNotIlum(col-x,lin-y,brd) == 2 && !lamps) 
	{ 
		aux2 = (PILHAUNDO) malloc(sizeof(N_PILHAUNDO));
		aux2 = getCoords(col-x,lin-y,brd);
		if(coordsIguais(aux,aux2))
		{	
			lamps=1; 
			COL_LAMP(aux->undo.col,aux->undo.lin); 
			COL_LAMP(aux->seg->undo.col,aux->seg->undo.lin);
		}	
		clearPilha(aux2);
	}
	
	if(IS_IN_FREE(col+x,lin-y) && nCasasFreeNotIlum(col+x,lin-y,brd) == 2 && !lamps) 
	{ 
		aux2 = (PILHAUNDO) malloc(sizeof(N_PILHAUNDO));
		aux2 = getCoords(col+x,lin-y,brd);
		if(coordsIguais(aux,aux2))
		{	
			lamps=1; 
			COL_LAMP(aux->undo.col,aux->undo.lin);			
			COL_LAMP(aux->seg->undo.col,aux->seg->undo.lin);
		}	
		clearPilha(aux2);
	}
	
	if(IS_IN_FREE(col-x,lin+y) && nCasasFreeNotIlum(col-x,lin+y,brd) == 2 && !lamps)
	{ 
		aux2 = (PILHAUNDO) malloc(sizeof(N_PILHAUNDO));
		aux2 = getCoords(col-x,lin+y,brd);
		if(coordsIguais(aux,aux2))
		{	
			lamps=1; 
			COL_LAMP(aux->undo.col,aux->undo.lin); 
			COL_LAMP(aux->seg->undo.col,aux->seg->undo.lin);
		}	
		clearPilha(aux2);
	}
	
	if(IS_IN_FREE(col+x,lin+y) && nCasasFreeNotIlum(col+x,lin+y,brd) == 2 && !lamps)  
	{ 
		aux2 = (PILHAUNDO) malloc(sizeof(N_PILHAUNDO));
		aux2 = getCoords(col+x,lin+y,brd);		
		if(coordsIguais(aux,aux2))
		{	
			lamps=1; 
			COL_LAMP(aux->undo.col,aux->undo.lin); 
			COL_LAMP(aux->seg->undo.col,aux->seg->undo.lin);
		}	
		clearPilha(aux2);
	}	

	return brd;
}

PILHAUNDO getCoords(int col, int lin, BOARD *brd)
/** Insere as coordenadas das duas casas livres (e não iluminadas) numa pilha de undo's.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	int i,col1=-1,col2=-1,lin1=-1,lin2=-1,flag=0;
	PILHAUNDO aux = malloc(sizeof(N_PILHAUNDO));
	
	for(i=col-1; IS_IN_FREE_OR_NO_LAMP(i,lin) && !flag; i--) 
	{
		if(IS_FREE(i,lin))
		{
			if(col1 == -1 && lin1 == -1) { col1 = i; lin1 = lin; }
			else { col2 = i; lin2 = lin; flag = 1; }
		}
	}
		
	for(i=col+1; IS_IN_FREE_OR_NO_LAMP(i,lin) && !flag; i++) 
	{	
		if(IS_FREE(i,lin))
		{
			if(col1 == -1 && lin1 == -1) { col1 = i; lin1 = lin; }
			else { col2 = i; lin2 = lin; flag = 1; }
		}
	}
			
	for(i=lin-1; IS_IN_FREE_OR_NO_LAMP(col,i) && !flag; i--) 
	{	
		if(IS_FREE(col,i))
		{
			if(col1 == -1 && lin1 == -1) { col1 = col; lin1 = i; }
			else { col2 = col; lin2 = i; flag = 1; }
		}
	}	
				
	for(i=lin+1; IS_IN_FREE_OR_NO_LAMP(col,i) && !flag; i++) 
	{	
		if(IS_FREE(col,i))
		{
			if(col1 == -1 && lin1 == -1) { col1 = col; lin1 = i; }
			else { col2 = col; lin2 = i; flag = 1; }
		}
	}	

	aux = push(aux,col1,lin1,0,0,0);	
	aux = push(aux,col2,lin2,0,0,0);
		
	return aux;
}
		
int coordsIguais(PILHAUNDO p1, PILHAUNDO p2)
/** Compara duas pilhas, e retorna 1 se as coordenadas forem iguais e 0, caso contrário.
 * \param p1 - Pilha 1
 * \param p2 - Pilha 2
 */
{
	int	a,b,c,d,e,f,g,h;	
	
	a = p1->undo.col;
	b = p1->undo.lin;	
		
	c = p1->seg->undo.col;
	d = p1->seg->undo.lin;	
	
	e = p2->undo.col;
	f = p2->undo.lin;
		
	g = p2->seg->undo.col;
	h = p2->seg->undo.lin;				
	
	if((((a==e && b==f) && !(a==g && b==h)) || (!(a==e && b==f) && (a==g && b==h))) &&	
	   (((c==e && d==f) && !(c==g && d==h)) || (!(c==e && d==f) && (c==g && d==h)))	&&
	   !(a==c && b==d) && !(e==g && f==h)) return 1;
	else return 0;
}
		
#endif