#ifndef ___EST2_C___
#define ___EST2_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "est2.h"

BOARD *do_est2(BOARD *brd, int flagrsv)
/** Corre a estratégia 2.
 * \param *brd - Tabuleiro 
 * \param flagrsv - Flag que indica se o comando foi invocado pelo comando rsv 
 */
{
	int col,lin;
		
	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
			if(IS_LAMP(col,lin))
				ilumCasas(col,lin,brd);
	
	if(brd->pilha && top(brd->pilha).ilum!=-1 && !flagrsv) brd->pilha = push(brd->pilha,0,0,-1,1,0);

	return brd;	
}

BOARD *ilumCasas(int col, int lin, BOARD* brd)
/** Ilumina as casas na mesma linha e coluna da casa recebida. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int i;
	
	for(i=col-1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(i,lin) && SOL; i--) 
	{
		if(IS_LAMP(i,lin)) SOL = 0;
		else ilumina(i,lin,brd); 
	}	
	for(i=col+1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(i,lin) && SOL; i++) 
	{
		if(IS_LAMP(i,lin)) SOL = 0;
		else ilumina(i,lin,brd); 
	}
	for(i=lin-1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(col,i) && SOL; i--) 
	{
		if(IS_LAMP(col,i)) SOL = 0;
		ilumina(col,i,brd);
	}	
	for(i=lin+1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(col,i) && SOL; i++) 
	{
		if(IS_LAMP(col,i)) SOL = 0;
		ilumina(col,i,brd);
	}		
	
	return brd;
}

BOARD *ilumina(int col, int lin, BOARD *brd) 
/** Ilumina uma casa. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(IS_NO_LAMP(col,lin) && !ILUM(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),SOL,STATE(col,lin));
		ILUM(col,lin) = 1;
		LETTER(col,lin) = '.'; 
		STATE(col,lin) = NO_LAMP;
	}	
	else if(IS_FREE(col,lin))
	{	
		brd->pilha = push(brd->pilha,col,lin,ILUM(col,lin),SOL,STATE(col,lin));
		ILUM(col,lin) = 1;
		LETTER(col,lin) = '.'; 
		STATE(col,lin) = NO_LAMP;
	}	
	
	return brd;	
}

#endif