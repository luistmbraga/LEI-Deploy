#ifndef ___GERA_H___
#define ___GERA_H___

BOARD *do_gera(int col, int lin, BOARD *brd);
BOARD *geraSubLin(int subLin, BOARD *brd);
BOARD *geraSubCol(int subLin, int subCol, BOARD *brd);
BOARD *initialize_tab(int col, int lin);
BOARD *initialize_sub(int subLin, int subCol, BOARD *brd);
BOARD *colLamps(int subLin, int subCol, BOARD *brd);
BOARD *remLamps(int subLin, int subCol, BOARD *brd);
BOARD* colNums(int subLin, int subCol, BOARD *brd);
int noNumsAround(int col, int lin, BOARD *brd);
BOARD* colBloqs(int subLin, int subCol, BOARD *brd);
BOARD* col4s(int subLin, int subCol, BOARD *brd);

#endif
