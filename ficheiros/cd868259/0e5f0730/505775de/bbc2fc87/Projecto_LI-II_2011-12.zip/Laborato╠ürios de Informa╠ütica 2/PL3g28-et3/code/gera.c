#ifndef ___GERA_C___
#define ___GERA_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include <math.h>
#include <time.h>

#include "tabuleiro.h"
#include "erro.h"

#include "anula_joga.h"
#include "est1.h"
#include "est2.h"
#include "est3.h"
#include "est4.h"
#include "est5.h"
#include "resolve.h"
#include "gera.h"

BOARD *do_gera(int col, int lin, BOARD *brd)
/** Gera um tabuleiro.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro 
 */
{
	int subLin=0;
	
	if(brd->pilha) clearPilha(brd->pilha);
	if(brd) free(brd);
	brd = NULL;

	brd = initialize_tab(col,lin);

	while(brd->linha-subLin > 10) 
	{ 
		brd = geraSubLin(subLin,brd);
		subLin = subLin+11;
	}
	if(subLin< brd->linha) brd = geraSubLin(subLin,brd);
	do_an(brd,0,1);
	
	return brd;
}

BOARD *geraSubLin(int subLin, BOARD *brd)
/** Gera 10 linhas de um tabuleiro.
 * \param subLin - Linha onde começa
 * \param *brd - Tabuleiro 
 */
{
	int subCol=0;
	
	while(brd->coluna-subCol > 10) 
	{ 
		brd = geraSubCol(subLin,subCol,brd);\
		subCol = subCol+11;
	}
	if(subCol< brd->coluna) brd = geraSubCol(subLin,subCol,brd);
	
	return brd;
}

BOARD *geraSubCol(int subLin, int subCol, BOARD *brd)
/** Gera 10 colunas de um tabuleiro.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{	
	brd = initialize_sub(subLin,subCol,brd);
	
	brd = colLamps(subLin,subCol,brd);
	brd = col4s(subLin,subCol,brd);
	brd = colNums(subLin,subCol,brd);
	brd = colBloqs(subLin,subCol,brd);
	brd = remLamps(subLin,subCol,brd);
	
	if(brd->pilha && top(brd->pilha).ilum!=-3 && SOL && !isSolved(brd)) brd->pilha = push(brd->pilha,0,0,-3,1,0);
	correrEsts(brd,nAlts(brd->pilha),1,1);
	if(SOL && isSolved(brd)) { return brd; }
	else { do_an(brd,1,1); return geraSubCol(subLin,subCol,brd);}
}

BOARD *initialize_tab(int col, int lin)
/** Inicializa um tabuleiro. Difere do initialize_state() pois coloca todas as casas bloqueadas em vez de livres. 
 *	\param col - Número de linhas
 *	\param lin - Número de colunas
 */
{
	BOARD *brd = NULL;
	int i,j;
	
	brd = (BOARD *) malloc(sizeof(BOARD));
	if(brd!=NULL) 
	{
		brd->coluna = col;
		brd->linha = lin;
		for(j = 0; j < col; j++)
			for(i = 0; i < lin; i++) 
			{
				LETTER(i,j) = 'x';
				STATE(i,j) = BLOQ;
				SOL = 1;
				ILUM(i,j) = 0;
				HEURISTIC(i,j) = 0;
				brd->pilha = NULL;
			}
	}
	
	return brd;	
}

BOARD *initialize_sub(int subLin, int subCol, BOARD *brd)
/** Inicializa um sub tabuleiro 10x10 com casas livres.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{
	int col,lin;
	
	for(lin=subLin; lin< subLin+10 && lin< brd->linha; lin++)
		for(col=subCol; col< subCol+10 && col< brd->coluna; col++)
		{
			LETTER(col,lin) = '-';
			STATE(col,lin) = FREE;
		}
	
	return brd;
}

BOARD *colLamps(int subLin, int subCol, BOARD *brd)
/** Gera lâmpadas num sub tabuleiro.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{
	int lin,col,lamp;
	
	for(lin=subLin; lin< subLin+10 && lin< brd->linha; lin++)
		for(col=subCol; col< subCol+10 && col< brd->coluna; col++)
		{
			lamp = rand() % 10 + 1;
			if(lamp <= 4 && !IS_LAMP(col-1,lin) && !IS_LAMP(col+1,lin) && !IS_LAMP(col,lin-1) && !IS_LAMP(col,lin+1)) 
				{ STATE(col,lin) = LAMP; LETTER(col,lin) = '@'; }	
			else 
				{ STATE(col,lin) = FREE; LETTER(col,lin) = '-'; }
		}
	
	return brd;
}

BOARD *remLamps(int subLin, int subCol, BOARD *brd)
/** Remove lâmpadas de um sub tabuleiro.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{
	int col,lin;
	
	for(lin=subLin; lin< subLin+10 && lin< brd->linha; lin++)
		for(col=subCol; col< subCol+10 && col< brd->coluna; col++)
			if(IS_LAMP(col,lin)) 
				{ 
					STATE(col,lin) = FREE; 
					LETTER(col,lin) = '-'; 
				}	

	return brd;
}

BOARD* col4s(int subLin, int subCol, BOARD *brd)
/** Coloca 4's num sub tabuleiro.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{
	int lin,col;
	
	for(lin=subLin; lin< subLin+10 && lin< brd->linha; lin++)
		for(col=subCol; col< subCol+10 && col< brd->coluna; col++)
			if(IS_FREE(col,lin) && nCasasLamp(col,lin,brd)==4)
				{ 
					STATE(col,lin) = NUM; 
					LETTER(col,lin) = '4'; 
				}	
				
	return brd;
}

BOARD* colNums(int subLin, int subCol, BOARD *brd)
/** Gera números (0..3) num sub tabuleiro.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{
	int lin,col,num,lamps,notaround;
	
	for(lin=subLin; lin< subLin+10 && lin< brd->linha; lin++)
		for(col=subCol; col< subCol+10 && col< brd->coluna; col++)
			if(IS_FREE(col,lin))
			{
				notaround = noNumsAround(col,lin,brd);
				lamps = nCasasLamp(col,lin,brd);
				
				if(lamps==3 && notaround) 
				{ 
					num = rand() % 10 + 1;
					if(num <= 4) { STATE(col,lin) = NUM; LETTER(col,lin) = '3'; }	
				}		
				else if(lamps==2 && notaround) 
				{
					num = rand() % 10 + 1;
					if(num <= 4) { STATE(col,lin) = NUM; LETTER(col,lin) = '2'; }	
				}	
				else if(lamps==1 && notaround)
				{
					num = rand() % 10 + 1;
					if(num <= 4)
					{ STATE(col,lin) = NUM; LETTER(col,lin) = '1'; }
				}
				else if(lamps==0 && notaround)
				{
					num = rand() % 10 + 1;
					if(num <= 2)
					{ STATE(col,lin) = NUM; LETTER(col,lin) = '0'; }
				}	
		}
	
	return brd;
}

int noNumsAround(int col, int lin, BOARD *brd)
/** Testa se há números á volta de um dada casa. Retorna 1 caso NÃO haja e 0 caso contrário. 
 * \param col - Coluna
 * \param lin - Linha 
 * \param *brd - Tabuleiro 
 */
{
	int res=0;
	
	if(!(IS_IN_NUM(col-1,lin)) && !(IS_IN_NUM(col+1,lin)) && !(IS_IN_NUM(col,lin-1)) && !(IS_IN_NUM(col,lin+1)) && 
	   !(IS_IN_NUM(col-1,lin-1)) && !(IS_IN_NUM(col+1,lin-1)) && !(IS_IN_NUM(col-1,lin+1)) && !(IS_IN_NUM(col+1,lin+1)))
		res = 1;
	else res = 0;
	   
	return res;   
}

BOARD *colBloqs(int subLin, int subCol, BOARD *brd)
/** Coloca bloqs num sub tabuleiro.
 * \param subLin - Linha onde começa
 * \param subCol - Coluna onde começa 
 * \param *brd - Tabuleiro 
 */
{
	int lin,col,lamp=0,i;
	
	for(lin=subLin; lin< subLin+10 && lin< brd->linha; lin++)
		for(col=subCol; col< subCol+10 && col< brd->coluna; col++)
			if(IS_LAMP(col,lin))
			{	
				for(i=col-1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(i,lin) && !lamp; i--) 
					if(IS_LAMP(i,lin)) 
						{ 
							lamp = 1;
							STATE(i+((col-i)/2),lin) = BLOQ; 
							LETTER(i+((col-i)/2),lin) = 'x'; 
						}
				
				lamp = 0;
				for(i=col+1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(i,lin) && !lamp; i++) 
					if(IS_LAMP(i,lin))	
					{ 
						lamp = 1;
						STATE(i-((i-col)/2),lin) = BLOQ;
						LETTER(i-((i-col)/2),lin) = 'x'; 
					}
				
				lamp = 0;
				for(i=lin-1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(col,i) && !lamp; i--) 
					if(IS_LAMP(col,i)) 
					{ 
						lamp = 1;
						STATE(col,i+((lin-i)/2)) = BLOQ; 
						LETTER(col,i+((lin-i)/2)) = 'x';
					}
				
				lamp = 0;
				for(i=lin+1; IS_IN_FREE_OR_NO_LAMP_OR_LAMP(col,i) && !lamp; i++) 
					if(IS_LAMP(col,i)) 
					{ 
						lamp = 1;
						STATE(col,i-((i-lin)/2)) = BLOQ; 
						LETTER(col,i-((i-lin)/2)) = 'x'; 
					}	
			}
	
	return brd;
}

#endif
