#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "comandos.h"
#include "erro.h"
#include "carrega_grava.h"
#include "anula_joga.h"
#include "est1.h"
#include "est2.h"
#include "est3.h"
#include "est4.h"
#include "est5.h"
#include "resolve.h"
#include "gera.h"

#define MAX_BUF_SIZE	1024 /*!< Tamanho máximo do input */
#define TALVEZ_MENSAGEM(erro)	((cmd) ? mensagem_de_erro(erro) : (erro)) /*!< Mensagem de erro. */

void print_state(BOARD *brd)
/** Imprime o estado do tabuleiro.
 * \param *brd - Tabuleiro 
 */	
{	
	int col,lin;
	
	if(brd->coluna==-1 || brd->linha==-1) return;
	printf("%d %d\n",brd->coluna,brd->linha);	
	for(lin=0; lin< brd->linha; lin++) 
	{
		for(col=0; col< brd->coluna-1; col++)
		{
			printf("%c ",LETTER(col,lin));
		}
		printf("%c\n",LETTER(col,lin));
	}
}

BOARD *cmd_quit(char *args, BOARD *brd)
/** Implementação do comando q, que sai da aplicação.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		if(brd->pilha) clearPilha(brd->pilha);
		if(brd) free(brd);
		exit(0);
	} else { mensagem_de_erro(E_ARGS); }
	
	return brd;
}

BOARD *cmd_load(char *args, BOARD *brd)
/** Implementação do comando cr, que carrega um tabuleiro a partir de um ficheiro. \n
 Esta função apenas lê os argumentos e invoca a função \a do_load, que vai carregar o tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{
	int i = 0;
	while(args[i] && !isspace(args[i])) i++;
	args[i] = 0;
	return do_load(args, brd);
}

BOARD *cmd_save(char *args, BOARD *brd)
/** Implementação do comando gr, que grava o tabuleiro num ficheiro.
 * \param *args - Argumentos do comando 
 * \param *brd - Tabuleiro para gravação 
 */
{
	return do_save(args,brd);
}

BOARD *cmd_an(char *args, BOARD *brd)
{
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			brd = do_an(brd,0,0);
		} else { mensagem_de_erro(E_NO_BOARD); }		
	} else { mensagem_de_erro(E_ARGS); }	
	
	return brd;
}

BOARD *cmd_joga(char *args, BOARD *brd)
/** Implementação do comando jg, que joga numa casa do tabuleiro.
 * \param *args - Argumentos do comando 
 * \param *brd - Tabuleiro para gravação 
 */
{
	int col,lin;
	char *str=(char*)malloc(sizeof(1024));
	
	if(brd->coluna!=-1 && brd->linha!=-1) 
	{
		if(sscanf(args,"%d %d %[^\n]",&col,&lin,str)==2)
		{	
			free(str);
			col--;
			lin--;
			if(IS_IN(col,lin))				
			{	
				brd = do_joga(col,lin,brd);
			} else { mensagem_de_erro(E_COORDS); }	
		} else { mensagem_de_erro(E_ARGS); }		
	} else { mensagem_de_erro(E_NO_BOARD); }
	
	return brd;
}

BOARD *cmd_est1(char *args, BOARD *brd)
/** Implementação do comando est1, que corre a estratégia 1.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{	
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			brd = do_est1(brd,0);
		} else {mensagem_de_erro(E_NO_BOARD);}
	} else { mensagem_de_erro(E_ARGS); }
	
	return brd;
}	

BOARD *cmd_est2(char *args, BOARD *brd)
/**Implementação do comando est2, que corre a estratégia 2.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{	
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			brd = do_est2(brd,0);
		} else {mensagem_de_erro(E_NO_BOARD);}
	} else { mensagem_de_erro(E_ARGS); }
	
	return brd;
}

BOARD *cmd_est3(char *args, BOARD *brd)
/** Implementação do comando est3, que corre a estratégia 3.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{	
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			brd = do_est3(brd,nAlts(brd->pilha),0);
		} else {mensagem_de_erro(E_NO_BOARD);}
	} else { mensagem_de_erro(E_ARGS); }
	
	return brd;
}

BOARD *cmd_est4(char *args, BOARD *brd)
/** Implementação do comando est4, que corre a estratégia 4.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{	
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			brd = do_est4(brd,nAlts(brd->pilha),0);
		} else {mensagem_de_erro(E_NO_BOARD);}
	}  else { mensagem_de_erro(E_ARGS); }	
	
	return brd;
}

BOARD *cmd_est5(char *args, BOARD *brd)
/** Implementação do comando est5, que corre a estratégia 5.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{	
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			brd = do_est5(brd,nAlts(brd->pilha),0);
		} else {mensagem_de_erro(E_NO_BOARD);}
	} else { mensagem_de_erro(E_ARGS); }
	
	return brd;
}

BOARD *cmd_rsv(char *args, BOARD *brd)
/** Implementação do comando rsv, que resolve um tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{	
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%s",str)==-1)
	{
		free(str);
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			brd = do_rsv(brd);	
		} else {mensagem_de_erro(E_NO_BOARD);}
	} else { mensagem_de_erro(E_ARGS); }	

	return brd;
}

BOARD *cmd_gera(char *args, BOARD *brd)
/** Implementação do comando gera, que gera um tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro 
 */
{
	int col,lin;
	char *str=(char*)malloc(sizeof(1024));
	
	if(sscanf(args,"%d %d %[^\n]",&col,&lin,str)==2)
	{	
		free(str);
		if(col>=6 && col<=MAX && lin>=6 && lin<=MAX)				
		{	
			brd = do_gera(col,lin,brd);
		} else { mensagem_de_erro(E_COORDS); }	
	} else { mensagem_de_erro(E_ARGS); }		
	
	return brd;
}

int contar_lampadas(BOARD *brd)
/** Conta o número de lâmpadas num tabuleiro. Para análisar o assembly gerado.
 * \param *brd - Tabuleiro 
 */
{
	int col=0,lin=0,res=0;
	
	while(lin<brd->linha)
	{	
		while(col<brd->coluna)
		{	
			if(brd->state[col][lin]==LAMP) { res++; }
			col++;
		}
		lin++;
	}
	
	return res;
}
