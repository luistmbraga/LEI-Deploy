#ifndef ___RESOLVE_C___
#define ___RESOLVE_C___

#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "erro.h"

#include "anula_joga.h"
#include "est1.h"
#include "est2.h"
#include "est3.h"
#include "est4.h"
#include "est5.h"
#include "est6.h"
#include "resolve.h"

BOARD *do_rsv(BOARD *brd)
{
	if(!isSolved(brd) && SOL)
	{	
		estsAndHeur(nAlts(brd->pilha),brd);
		if(brd->pilha && top(brd->pilha).ilum!=-1 && SOL && isSolved(brd)) brd->pilha = push(brd->pilha,0,0,-1,1,0);
		else if(brd->pilha && top(brd->pilha).ilum!=-3 && SOL && !isSolved(brd)) brd->pilha = push(brd->pilha,0,0,-3,1,0);
		printf("SOL: %d, SOLVED: %d\n",SOL,isSolved(brd));
	}

	if(brd->pilha && top(brd->pilha).ilum!=-1 && isSolved(brd)) brd->pilha = push(brd->pilha,0,0,-1,1,0);
	return brd;
}

BOARD *estsAndHeur(int alts, BOARD *brd)
{
	correrEsts(brd,nAlts(brd->pilha),1,0);
	initHeuristic(brd);
	quantasAlt(brd);
	quantasAlt2(brd);
	
	if(brd->pilha && top(brd->pilha).ilum==-2) brd->pilha = pop(brd->pilha);
	if((alts != nAlts(brd->pilha)) && SOL && !isSolved(brd)) estsAndHeur(nAlts(brd->pilha),brd);
	
	return brd;
}

BOARD *correrEsts(BOARD *brd, int alts, int flagQuantasAlt, int flaggera)
{
	if(SOL) do_est1(brd,1);
	if(SOL) do_est2(brd,1);
	if(SOL) do_est3(brd,nAlts(brd->pilha),1);
	if(SOL && !flaggera) do_est4(brd,nAlts(brd->pilha),1);
	if(SOL) do_est5(brd,nAlts(brd->pilha),1);
	if(SOL && !flaggera) do_est6(brd,nAlts(brd->pilha));
	if(!SOL && !flagQuantasAlt) { ;mensagem_de_erro(E_WRONG_SOLUTION); }
	
	if((alts != nAlts(brd->pilha)) && SOL && !isSolved(brd)) return correrEsts(brd,nAlts(brd->pilha),flagQuantasAlt,flaggera);
	else return brd;
}

int isSolved(BOARD *brd)
{
	int col,lin,res=1,flag=0;

	for(lin=0; lin< brd->linha && !flag; lin++)
		for(col=0; col< brd->coluna && !flag; col++)
			if(IS_FREE(col,lin) || (IS_NO_LAMP_NOT_ILUM(col,lin)))
			{
				res = 0;
				flag = 1;
			}
	
	return res;
}

int tudoJogado(BOARD *brd)
{
	int col,lin,res=1;
	
	for(lin=0; lin< brd->linha; lin++)
		for(col=0; col< brd->coluna; col++)
			if(IS_FREE(col,lin))
				res = 0;
	
	return res;
}

BOARD *quantasAlt(BOARD *brd)
{
	int col,lin;
	
	for(lin=0; lin<brd->linha; lin++)
		for(col=0; col<brd->coluna; col++)
			if(HEURISTIC(col,lin) != -1)
			{
				if(brd->pilha && top(brd->pilha).ilum!=-2) brd->pilha = push(brd->pilha,0,0,-2,1,0);
				
				COL_LAMP(col,lin);
				correrEsts(brd,nAlts(brd->pilha),1,0);
				
				if(SOL) HEURISTIC(col,lin) = nAlts(brd->pilha); 
				else if(tudoJogado(brd) && !isSolved(brd)) HEURISTIC(col,lin) = 0;
				else HEURISTIC(col,lin) = 0;
				
				if(brd->pilha && top(brd->pilha).ilum!=-2) brd->pilha = push(brd->pilha,0,0,-2,1,0);
				if(!isSolved(brd)) do_an(brd,1,1);
				if(brd->pilha && top(brd->pilha).ilum==-2) brd->pilha = pop(brd->pilha);
				
				if(HEURISTIC(col,lin) == 0) 
				{ 
					MARCA(col,lin); 
					HEURISTIC(col,lin) = -1; 
				}
			}	
	
	return brd;
}

BOARD *quantasAlt2(BOARD *brd)
{
	int col,lin;
	
	for(lin=0; lin<brd->linha; lin++)
		for(col=0; col<brd->coluna; col++)
			if(HEURISTIC(col,lin) != -1)
			{
				if(brd->pilha && top(brd->pilha).ilum!=-2) brd->pilha = push(brd->pilha,0,0,-2,1,0);
				
				MARCA(col,lin);
				correrEsts(brd,nAlts(brd->pilha),1,0);
				
				if(SOL) HEURISTIC(col,lin) = nAlts(brd->pilha); 
				else if(tudoJogado(brd) && !isSolved(brd)) HEURISTIC(col,lin) = 0;
				else HEURISTIC(col,lin) = 0;
				
				if(brd->pilha && top(brd->pilha).ilum!=-2) brd->pilha = push(brd->pilha,0,0,-2,1,0);
				if(!isSolved(brd)) do_an(brd,1,1);
				if(brd->pilha && top(brd->pilha).ilum==-2) brd->pilha = pop(brd->pilha);
				
				if(HEURISTIC(col,lin) == 0) 
				{ 
					COL_LAMP(col,lin); 
					HEURISTIC(col,lin) = -1; 
				}
			}	
	
	return brd;
}

BOARD *initHeuristic(BOARD *brd)
{
	int col,lin;
	
	for(lin=0; lin<brd->linha; lin++)
		for(col=0; col<brd->coluna; col++)
		{	
			if(IS_FREE_NOT_ILUM(col,lin)) HEURISTIC(col,lin) = 0;
			else HEURISTIC(col,lin) = -1;
		}	
				
	return brd;			
}

#endif