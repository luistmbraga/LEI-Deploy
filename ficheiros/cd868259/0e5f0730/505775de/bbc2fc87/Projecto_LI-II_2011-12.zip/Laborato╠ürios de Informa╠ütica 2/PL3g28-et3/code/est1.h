#ifndef ___EST1_H___
#define ___EST1_H___

int getNUM(int col, int lin, BOARD *brd);
BOARD *do_est1(BOARD *brd, int flagrsv);
int nFreeOrLamp(int col,int lin, BOARD *brd);
int nCasasLamp(int col,int lin, BOARD *brd);
BOARD *insLamps(int col, int lin, BOARD *brd);
BOARD *colLamp(int col, int lin, BOARD *brd);

#endif
