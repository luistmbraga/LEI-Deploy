#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "comandos.h"
#include "erro.h"

#define DEBUG	0
#define MAX_BUF_SIZE	1024

#define TALVEZ_MENSAGEM(erro)	((cmd) ? mensagem_de_erro(erro) : (erro))

#define print_undef(letter) printf("\033[46m %c \033[0m", letter)
#define print_black(letter) printf("\033[40m %c \033[0m", letter)
#define print_white(letter) printf("\033[47;30m %c \033[0m", letter)

BOARD *initialize_state() {
	BOARD *brd = NULL;
	int i, j;

	brd = (BOARD *) malloc (sizeof(BOARD));
	if(brd != NULL) {
		brd->size = -1;
		for(i = 0; i < MAX; i++)
			for(j = 0; j < MAX; j++) {
				brd->letter[i][j] = '#';
				brd->state[i][j] = UNDEF;
			}
	}
	return brd;
}

void print_state(BOARD *brd) {
	int i, j;

	if(brd->size == -1)
		return;

	printf("    ");
	for(i = 0; i < brd->size; i++)
		printf("%3d", i + 1);
	printf("\n");

	for(j = 0; j < brd->size; j++) {
		printf("%3d ", j + 1); 
		for(i = 0; i < brd->size; i++)
			printf("%d",brd->state[i][j]);
			switch(brd->state[i][j]) {
				case UNDEF: print_undef(brd->letter[i][j]); break;
				case BLACK: print_black(brd->letter[i][j]); break;
				case WHITE: print_white(brd->letter[i][j]); break;
			}
		printf("\n");
		
	}
}

BOARD *cmd_save(char *args, BOARD *brd) {
	int i, j;
	char filename[MAX_BUF_SIZE];
	FILE *f;

	if(brd->size == -1) {
		mensagem_de_erro(E_NO_BOARD);
	} else {
		sscanf(args, "%s", filename);
		strcat(filename, ".ltr");

		f = fopen(filename, "w");
		if(f == NULL) {
			mensagem_de_erro(E_SAVE);
		} else {
			fprintf(f, "%d\n", brd->size);
			for(j = 0; j < brd->size; j++) {
				for(i = 0; i < brd->size; i++) {
					switch(brd->state[i][j]) {
						case UNDEF: fprintf(f, " %c ", brd->letter[i][j]); break;
						case WHITE: fprintf(f, "(%c)", brd->letter[i][j]); break;
						case BLACK: fprintf(f, "[%c]", brd->letter[i][j]); break;
					}
				}
				fprintf(f, "\n");
			}
			fclose(f);
		}
	}

	return brd;
}

BOARD *do_load(char *args, BOARD *brd) {
	char filename[MAX_BUF_SIZE];
	int sz;
	FILE *f;
	char c, buf[4];
	int i, j;
	int erro = E_NOERR;
	BOARD *nbrd = NULL;

	strcpy(filename, args);
	strcat(filename, ".ltr");
	f = fopen(filename, "r");

	if(f == NULL) {
		erro = mensagem_de_erro(E_NO_FILE);
	}

	if(!erro && fscanf(f, "%d", &sz) != 1) {
		erro = mensagem_de_erro(E_FILE_FORMAT);
	}

	if(!erro && sz > 0 && sz < MAX) {
		if((nbrd = initialize_state()) != NULL)
			nbrd->size = sz;
		else
			erro = mensagem_de_erro(E_MEM);
	} else {
		erro = erro || mensagem_de_erro(E_COORDS);
	}

	for(j = 0; !erro && j < nbrd->size; j++)
		for(i = 0; !erro && i < nbrd->size; i++) {
			if(fscanf(f, "%3s", buf) != 1) {
				erro = mensagem_de_erro(E_FILE_FORMAT);
			}

			if(strlen(buf) == 1) {
				nbrd->letter[i][j] = buf[0];
				nbrd->state[i][j] = UNDEF;
			} else if(sscanf(buf, "(%c)", &c)) {
				nbrd->letter[i][j] = c;
				nbrd->state[i][j] = WHITE;
			} else if(sscanf(buf, "[%c]", &c)) {
				nbrd->letter[i][j] = c;
				nbrd->state[i][j] = BLACK;
			}
			else {
				fprintf(stderr, "Formato do valor na posicao (%d, %d): '%s' invalido\n", i, j, buf);
				erro = mensagem_de_erro(E_FILE_FORMAT);
			}
		}

	/* Se nao houve erro na leitura entao deitamos fora o tabuleiro anterior e substituimo-lo pelo que acabamos de ler */
	if(!erro) {
		free(brd);
		brd = nbrd;
	}

	if(f != NULL)
		fclose(f);

	return brd;
}

BOARD *cmd_load(char *args, BOARD *brd) {
	int i = 0;

	while(args[i] && !isspace(args[i]))
			i++;
	args[i] = 0;

	return do_load(args, brd);
}

BOARD *cmd_quit(char *args, BOARD *brd) {
	args = NULL;
	exit(0);
	return brd;
}
