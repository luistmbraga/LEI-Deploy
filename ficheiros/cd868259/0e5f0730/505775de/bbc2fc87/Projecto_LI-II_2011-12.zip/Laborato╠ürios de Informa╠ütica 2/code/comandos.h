#ifndef ___COMANDOS_H___
#define ___COMANDOS_H___

#include "tabuleiro.h"

/**
* Esta macro pretende facilitar a criacao de prototipos de comandos
* Um comando chamado cmd tem o seguinte prototipo:
*	BOARD *cmd(char *, BOARD *);
*/
#define PROTOTIPO(_proto)	BOARD *_proto(char *, BOARD *)

BOARD *initialize_state();
void print_state(BOARD *);

PROTOTIPO(cmd_save);
PROTOTIPO(cmd_load);
PROTOTIPO(cmd_help);
PROTOTIPO(cmd_quit);

#endif
