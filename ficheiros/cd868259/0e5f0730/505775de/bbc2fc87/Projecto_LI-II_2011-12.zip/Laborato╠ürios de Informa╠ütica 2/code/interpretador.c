#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "lista_comandos.h"
#include "erro.h"

/* Uma variavel estatica para guardar o prompt. */
static char *prompt = "Letrorium> ";
static char *line_read = (char *)NULL;

/* Read a string, and return a pointer to it.
   Returns NULL on EOF. */
char *rl_gets ()
{
  /* If the buffer has already been allocated,
     return the memory to the free pool. */
  if (line_read)
    {
      free (line_read);
      line_read = (char *)NULL;
    }

  /* Get a line from the user. */
  line_read = readline (prompt);

  /* If the line has any text in it,
     save it on the history. */
  if (line_read && *line_read)
    add_history (line_read);

  return (line_read);
}

/* Procura o comando e retorna o apontador para a funcao associada ou NULL caso o comando nao esteja na lista de comandos */
FUNCTION *find_command(char *cmd) {
	int i;

	for(i = 0; command[i].name != NULL && strcmp(command[i].name, cmd) != 0; i++);

	if(command[i].name != NULL) {
		/*
		if(command[i].undoable) fazer algo para saber como desfazer o estado
		*/

		return command[i].func;
	} else
		return NULL;
}

/* O comando ajuda */
BOARD *cmd_help(char *args, BOARD *brd) {
	int i;
	args = NULL;

	for(i = 0; command[i].name != NULL; i++)
		printf("%s: %s\n", command[i].name, command[i].doc);

	return brd;
}

int main() {
	char *cmd = NULL;
	FUNCTION *fun = NULL;
	BOARD * brd = NULL;

	srand(time(NULL));
	brd = initialize_state();

	while(rl_gets() != NULL) {
		int i, j;

		/* Ignorar os espacos no inicio do comando */
		for(i = 0; line_read[i] && isspace(line_read[i]); i++);

		/* Saltar a primeira palavra da linha */
		for(j = i; line_read[j] && !isspace(line_read[j]); j++);

		/* Delimitar o nome do comando */
		if(line_read[j])
			line_read[j++] = 0;

		 /* Saltar os espacos mais uma vez */
		for(; line_read[j] && isspace(line_read[j]); j++);

		cmd = line_read + i;

		fun = find_command(cmd);
		if(fun != NULL) {
			brd = fun(line_read + j, brd);
			print_state(brd);
		} else {
			mensagem_de_erro(E_COMMAND);
		}
	}

	return 0;
}
