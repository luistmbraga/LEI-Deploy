#ifndef ___TABULEIRO_H___
#define ___TABULEIRO_H___

#define MAX	30

typedef enum {UNDEF, WHITE, BLACK} STATE;

typedef struct board {
	int size;
	char letter[MAX][MAX];
	STATE state[MAX][MAX];
	int heuristic[MAX][MAX];
} BOARD;

#endif
