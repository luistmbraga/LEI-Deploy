#ifndef ___LISTA_COMANDOS_H___
#define ___LISTA_COMANDOS_H___

#include "tabuleiro.h"
#include "comandos.h"

/**
* Tipo de dados de uma funcao que implementa um comando
*/
typedef BOARD *(FUNCTION)(char *, BOARD *);

/**
* Estrutura de dados que contem um comando
*/
typedef struct {
	char *name;			/* Nome do comando */
	FUNCTION *func;		/* Funcao a chamar */
	int args;			/* Numero de argumentos do comando */
	char *doc;			/* O texto que aparece quando se usa o comando de ajuda */
	char undoable;		/* Diz se o comando pode ser desfeito */
} COMMAND;

/**
* Esta estrutura de dados contem uma linha por cada comando
* A grande vantagem deste sistema consiste na separacao entre
* o codigo do interpretador de comandos e a sua implementacao
*/
COMMAND command [] = {
	{"gr", cmd_save, 1, "Grava o estado do puzzle num ficheiro utilizando o formato LTR", 0},
	{"cr", cmd_load, 1, "Carrega o estado do puzzle a partir de um ficheiro no formato LTR", 0},
	{"?", cmd_help, 0, "Mostra a ajuda", 0},
	{"q", cmd_quit, 0, "Sai do programa", 0},
	{(char *)NULL, NULL, 0, (char *)NULL, 0} 
};

#endif
