#ifndef ___TABULEIRO_H___
#define ___TABULEIRO_H___

/** Tamanho máximo, quer para linhas, quer para colunas. */
#define MAX	40
/** Tamanho máximo do input. */
#define MAX_BUF_SIZE	1024

typedef enum 
{
	FREE, /*!< Casa não bloqueada sem lâmpada. */ 
	BLOQ, /*!< Casa bloqueada. */
	NUM, /*!< Casa bloqueada com número. */
	LAMP, /*!< Casa com lâmpada. */
	NOLAMP /*!< Casa que não pode conter uma lâmpada. */
} STATE;

typedef struct board 
/** Um tabuleiro é composto pelo número de linhas e colunas e a 
 * cada uma casas está associado um caracter e um estado.
 */
{
	int coluna, /*!< Número de colunas. */
	linha; /*!< Número de linhas. */
	char letter[MAX][MAX]; /*!< O caracter presente em cada casa. */
	STATE state[MAX][MAX]; /*!< O estado presente em cada casa. */
} BOARD;

#endif
