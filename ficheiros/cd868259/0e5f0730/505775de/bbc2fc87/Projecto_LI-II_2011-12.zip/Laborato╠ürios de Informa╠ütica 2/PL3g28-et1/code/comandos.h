#ifndef ___COMANDOS_H___
#define ___COMANDOS_H___

#include "tabuleiro.h"

/**
* Esta macro pretende facilitar a criação de protótipos de comandos. \n
* Um comando chamado \a cmd tem o protótipo \a BOARD *cmd(char *, BOARD *);
*/
#define PROTOTIPO(_proto)	BOARD *_proto(char *, BOARD *)

BOARD *initialize_state();

void print_state(BOARD *);
PROTOTIPO(cmd_save);
/*!< Protótipo do comando gr.*/
PROTOTIPO(cmd_load);
/*!< Protótipo do comando cr.*/
PROTOTIPO(cmd_help);
/*!< Protótipo do comando ?.*/
PROTOTIPO(cmd_quit);
/*!< Protótipo do comando q.*/
PROTOTIPO(cmd_joga);
/*!< Protótipo do comando jg.*/
PROTOTIPO(cmd_est1);
/*!< Protótipo do comando est1.*/
PROTOTIPO(cmd_est2);
/*!< Protótipo do comando est2.*/
PROTOTIPO(cmd_est3);
/*!< Protótipo do comando est3.*/
PROTOTIPO(cmd_mc);
/*!< Protótipo do comando mc.*/

BOARD *do_load(char *args, BOARD *brd);
int onCasas(int col,int lin, BOARD *brd);
int offCasas(int col,int lin, BOARD *brd);
BOARD *insLamp(int col, int lin, BOARD *brd);
int podeLamp(int col, int lin, BOARD *brd);
BOARD *colocaLamp(int col, int lin, BOARD *brd);
BOARD *ilum(int col, int lin, BOARD* brd);
BOARD *noLamps(int col, int lin, BOARD *brd);
BOARD *marca(int col, int lin, BOARD *brd);

int estaDentro(int col, int lin, BOARD *brd);
int isFREE(int col,int lin, BOARD *brd);
int isBLOQ(int col,int lin, BOARD *brd);
int isNUM(int col,int lin, BOARD *brd);
int isLAMP(int col,int lin, BOARD *brd);
int isNOLAMP(int col,int lin, BOARD *brd);

#endif
