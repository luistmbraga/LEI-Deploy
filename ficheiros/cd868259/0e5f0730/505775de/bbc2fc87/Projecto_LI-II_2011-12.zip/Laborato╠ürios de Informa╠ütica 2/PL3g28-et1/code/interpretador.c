#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "lista_comandos.h"
#include "erro.h"

/** 
 * \file interpretador.c
 * \brief Programa principal
 * 
 * É o que está visível ao utilizador. Aqui, ele insere os comandos que lhe permitem jogar.
 */

/** 
 * \file comandos.c
 * \brief Comandos e estratégias
 * 
 * Implementação dos comandos e das estratégias.
 */

/** 
 * \file comandos.h
 * \brief Assinatura de comandos
 * 
 * Assinatura das funções relativas aos comandos, estratégias e funções auxiliares.
 */

/** 
 * \file erro.h
 * \brief Mensagens de erro
 * 
 * Assinatura da função \a mensagem_de_erro e definição dos erros possíveis.
 */

/** 
 * \file erro.c
 * \brief Estrutura de erro
 * 
 * Definição da estrutura de erro e implementação da função \a mensagem_de_erro. 
 */

/** 
 * \file lista_comandos.h
 * \brief Estrutura de comandos
 * 
 * Definição da estrutura de comando e lista de comandos disponíveis.
 */

/** 
 * \file tabuleiro.h
 * \brief Estrutura de tabuleiro
 * 
 *  Definição da estrutura de tabuleiro e de estado.
 */

/*! \mainpage Etapa 1
 *
 * \section Autores
 * Hugo Mendes e Tiago Conceição
 * 
 *
 * \section Etapa1
 *
 * Nesta etapa inicial foi criada a ferramenta que permite ao utilizador carregar um tabuleiro e começar a jogar. \n
 * Assim, foi implementada a leitura e a escrita dos comandos básicos e ainda as duas primeiras estratégias 
 * para resolver um puzzle. \n
*/ 

/** Prompt da aplicação. */
static char *prompt = "Letrorium> "; 
/** Variável para guardar o input. */
static char *line_read = (char *)NULL; 


char *rl_gets ()
/**
 * Função que lê o input do utilizador.
 */
{
  /* If the buffer has already been allocated,
     return the memory to the free pool. */
  if (line_read)
    {
      free (line_read);
      line_read = (char *)NULL;
    }

  /* Get a line from the user. */
  line_read = readline (prompt);

  /* If the line has any text in it,
     save it on the history. */
  if (line_read && *line_read)
    add_history (line_read);

  return (line_read);
}

FUNCTION *find_command(char *cmd) 
/**
 * Função que procura o comando e retorna o apontador para a função associada ou NULL caso o comando nao esteja na lista de comandos.
 */
{
	int i;
	for(i=0; command[i].name != NULL && strcmp(command[i].name, cmd) != 0; i++);

	if(command[i].name != NULL) 
	{
		/*if(command[i].undoable) fazer algo para saber como desfazer o estado*/
		return command[i].func;
	} else
		return NULL;
}


BOARD *cmd_help(char *args, BOARD *brd) 
/**
 * Implementação do comando ? que apenas imperime a função de cada comando.
 */
{
	int i;
	
	args = NULL; /* 'Set' e 'Use' de *args*/
	if(args==NULL)
		
	for(i = 0; command[i].name != NULL; i++)
		printf("%s: %s\n", command[i].name, command[i].doc);

	return brd;
}

int main() 
/**
 * Implementação do interpretador de comandos.
 */
{
	char *cmd = NULL;
	FUNCTION *fun = NULL;
	BOARD * brd = NULL;

	srand(time(NULL));
	brd = initialize_state();

	while(rl_gets() != NULL) {
		int i, j;

		/* Ignorar os espacos no inicio do comando */
		for(i=0; line_read[i] && isspace(line_read[i]); i++);

		/* Saltar a primeira palavra da linha */
		for(j = i; line_read[j] && !isspace(line_read[j]); j++);

		/* Delimitar o nome do comando */
		if(line_read[j]) line_read[j++] = 0;

		 /* Saltar os espacos mais uma vez */
		for(; line_read[j] && isspace(line_read[j]); j++);

		cmd = line_read + i;

		fun = find_command(cmd);
		
		if(fun != NULL) 
		{
			brd = fun(line_read + j, brd);
			print_state(brd);
		} 
		else 
		{
			mensagem_de_erro(E_COMMAND);
		}
	}

	return 0;
}
