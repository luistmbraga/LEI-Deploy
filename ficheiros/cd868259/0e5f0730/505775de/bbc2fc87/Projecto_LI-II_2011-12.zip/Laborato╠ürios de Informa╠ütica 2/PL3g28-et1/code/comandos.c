#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <string.h>
#include <ctype.h>

#include "tabuleiro.h"
#include "comandos.h"
#include "erro.h"

#define DEBUG	0 /*!< Debug. */

#define MAX_BUF_SIZE	1024 /*!< Tamanho máximo do input */

#define TALVEZ_MENSAGEM(erro)	((cmd) ? mensagem_de_erro(erro) : (erro)) /*!< Mensagem de erro. */

		/*---------------------INICIALIZAR--------------------*/	
BOARD *initialize_state() 
/** Inicializa um tabuleiro com todas as casas livres. */
{
	BOARD *brd=NULL;
	int col,lin;

	brd=(BOARD *) malloc(sizeof(BOARD));
	if(brd!=NULL) 
	{
		brd->coluna = -1;
		brd->linha = -1;
		for(lin=0; lin<MAX; lin++)
			for(col=0; col<MAX; col++) 
			{
				brd->letter[col][lin]='-';
				brd->state[col][lin]=FREE;
			}
	}
	return brd;	
}

/*---------------------IMPRIMIR--------------------*/	
void print_state(BOARD *brd) 
/** Imprime o estado do tabuleiro. Não retorna nada.
* \param *brd - Tabuleiro para imprimir */	
{	
	int col,lin;

	if(brd->coluna==-1 || brd->linha==-1) return;
	
	printf("%d %d\n",brd->coluna,brd->linha);

	for(lin=0; lin< brd->linha; lin++) 
	{
		for(col=0; col<brd->coluna-1; col++)
		{
			printf("%c ", brd->letter[col][lin]);
		}
		printf("%c\n", brd->letter[col][lin]);
	}
}

		/*---------------------FUNCÕES AUXILIARES--------------------*/	
int estaDentro(int col, int lin, BOARD *brd)
/** Verifica se uma dada coordenada está dentro dos limites do tabuleiro.
* \param col - Coluna 
* \param lin - Linha 
* \param *brd - Tabuleiro para teste */
{
	if(col>0 && col<=brd->coluna && lin>0 && lin<=brd->linha) return 1;
	else return 0;	
}

int isFREE(int col,int lin, BOARD *brd)
/** Verifica se numa dada coordenada a casa está livre.
* \param col - Coluna 
* \param lin - Linha 
* \param *brd - Tabuleiro para teste */	
{
	if(brd->state[col-1][lin-1]==FREE) return 1;
	else return 0; 
}

int isBLOQ(int col,int lin, BOARD *brd)
/** Verifica se numa dada coordenada a casa está bloqueada.
 * \param col - Coluna 
 * \param lin - Linha 
 * \param *brd - Tabuleiro para teste */	
{
	if(brd->state[col-1][lin-1]==BLOQ) return 1;
	else return 0;	
}

int isNUM(int col,int lin, BOARD *brd)
/** Verifica se numa dada coordenada a casa está bloqueada com número.
 * \param col - Coluna 
 * \param lin - Linha 
 * \param *brd - Tabuleiro para teste */	
{
	if(brd->state[col-1][lin-1]==NUM) return 1;
	else return 0;	
}

int isLAMP(int col,int lin, BOARD *brd)
/** Verifica se numa dada coordenada a casa tem lâmpada.
 * \param col - Coluna 
 * \param lin - Linha 
 * \param *brd - Tabuleiro para teste */	
{
	if(brd->state[col-1][lin-1]==LAMP) return 1;
	else return 0;
}

int isNOLAMP(int col,int lin, BOARD *brd)
/** Verifica se numa dada coordenada a casa tem a marca que indica que não pode ter lâmpada.
 * \param col - Coluna 
 * \param lin - Linha 
 * \param *brd - Tabuleiro para teste */	
{
	if(brd->state[col-1][lin-1]==NOLAMP) return 1;
	else return 0;	
}

		/*---------------------GRAVAR--------------------*/	
BOARD *cmd_save(char *args, BOARD *brd) 
/** Implementação do comando gr, que grava o tabuleiro num ficheiro.
* \param *args - Argumentos do comando 
* \param *brd - Tabuleiro para gravação */
{
	int col,lin;
	char filename[MAX_BUF_SIZE];
	FILE *f;
	
	if(brd->coluna!=-1 && brd->linha!=-1) 
	{
		sscanf(args, "%s", filename);
		strcat(filename, ".ill");
		f = fopen(filename, "w");
		if(f!=NULL)
		{
			fprintf(f,"%d %d\n",brd->coluna,brd->linha);
			for(lin = 0; lin< brd->linha; lin++) 
			{
				for(col=0; col<brd->coluna-1; col++) 
				{	
					fprintf(f, "%c ", brd->letter[col][lin]);
				}
				fprintf(f, "%c\n", brd->letter[col][lin]);
			}
			fclose(f);
		} else {mensagem_de_erro(E_SAVE);} 
	} else {mensagem_de_erro(E_NO_BOARD);}
	
	return brd;
}

		/*---------------------CARREGAR--------------------*/	
BOARD *cmd_load(char *args, BOARD *brd) 
/** Implementação do comando cr, que carrega um tabuleiro a partir de um ficheiro. \n
 Esta função apenas lê os argumentos e invoca a função \a do_load, que vai carregar o tabuleiro.
* \param *args - Argumentos do comando
* \param *brd - Tabuleiro */
{
	int i = 0;
	while(args[i] && !isspace(args[i])) i++;
	args[i] = 0;
	return do_load(args, brd);	
}

BOARD *do_load(char *args, BOARD *brd) 
/** Carrega o tabuleiro.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	char filename[MAX_BUF_SIZE],c,buf[1];
	int coluna,linha,col,lin,erro=E_NOERR;
	FILE *f;
	BOARD *nbrd = initialize_state();
	
	strcpy(filename, args);	
	strcat(filename,".ill");
	f = fopen(filename, "r");
	
	if(f==NULL) {erro = mensagem_de_erro(E_NO_FILE);}
	
	if(!erro && fscanf(f,"%d %d",&coluna,&linha) != 2) {erro = mensagem_de_erro(E_FILE_FORMAT);}
	
	if(!erro && (coluna>0 && coluna<=MAX) && (linha>0 && linha<=MAX))
	{
		if(nbrd != NULL)
		{
			nbrd->coluna = coluna;
			nbrd->linha = linha;
		}
		else erro = mensagem_de_erro(E_MEM);
	} 
	else {erro = erro || mensagem_de_erro(E_COORDS);}
	
	for(lin=0; !erro && lin<nbrd->linha; lin++)
		for(col=0; !erro && col<nbrd->coluna; col++) 
		{
			if(fscanf(f,"%1s", buf) != 1) {erro = mensagem_de_erro(E_FILE_FORMAT);}
			
			if(sscanf(buf, "%c", &c) && c=='-') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = FREE;
			} 
			else if(sscanf(buf, "%c", &c) && c=='x') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = BLOQ;
			} 
			else if(sscanf(buf, "%c", &c) && (c=='0'||c=='1'||c=='2'||c=='3'||c=='4')) 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = NUM;
			}
			else if(sscanf(buf, "%c", &c) && c=='@') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = LAMP;
			}
			else if(sscanf(buf, "%c", &c) && c=='.') 
			{
				nbrd->letter[col][lin] = c;
				nbrd->state[col][lin] = NOLAMP;
			}
			else 
			{
				fprintf(stderr,"Formato do valor na posicao (%d, %d): '%s' invalido\n",col+1,lin+1,buf);
				erro = mensagem_de_erro(E_FILE_FORMAT);
			}
		}
	
	if(!erro) 
	{
		free(brd);
		brd = nbrd;
	}	
	if(f!=NULL) fclose(f);
	return brd;
}

		/*---------------------SAIR--------------------*/
BOARD *cmd_quit(char *args, BOARD *brd) 
/** Implementação do comando q, que sai da aplicação.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	args=NULL; /* 'Set' e 'Use' de *args*/
	if(args==NULL)
	exit(0);
	return brd;
}

		/*---------------------JOGAR--------------------*/
BOARD *cmd_joga(char *args, BOARD *brd) 
/** Implementação do comando jg, que coloca/remove uma lâmpada de uma casa do tabuleiro. \n
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	if(brd->coluna!=-1 && brd->linha!=-1) 
	{
		if(sscanf(args,"%d %d",&col,&lin)==2)
		{	
			if(estaDentro(col,lin,brd))				
			{	
				if(isFREE(col,lin,brd) || isNOLAMP(col,lin,brd)) 
				{
					brd->letter[col-1][lin-1]='@'; 
					brd->state[col-1][lin-1]=LAMP;
				}
				else if(isLAMP(col,lin,brd))
				{	
					brd->letter[col-1][lin-1]='-';
					brd->state[col-1][lin-1]=FREE;
				}
				else {mensagem_de_erro(E_BLOC);}
			} else {mensagem_de_erro(E_COORDS);}
			
		} else {mensagem_de_erro(E_ARGS);}		
	} else {mensagem_de_erro(E_NO_BOARD);}
	
	return brd;
}

		/*---------------------ESTRATÉGIA 1--------------------*/
BOARD *cmd_est1(char *args, BOARD *brd)
/** Implementa a estratégia 1.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	int col,lin,l;
	
	args=NULL; /* 'Set' e 'Use' de *args*/
	if(args==NULL)
	
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{	
			for(lin=0; lin<brd->linha; lin++)
				for(col=0; col<brd->coluna; col++)
					if(isNUM(col+1,lin+1,brd) && brd->letter[col][lin]!='0') 				
					{	
						l=(brd->letter[col][lin])-'0';
						if(l==onCasas(col+1,lin+1,brd)) 
							brd=insLamp(col+1,lin+1,brd);
					}
		} else {mensagem_de_erro(E_NO_BOARD);}
	}

return brd;
}

int onCasas(int col,int lin, BOARD *brd)
/** Retorna o número de casas à volta da coordenada recebida que podem conter uma lâmpada. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=0;
	
	if(col-1>0 && podeLamp(col-1,lin,brd)) n++;
	if(col+1<=brd->coluna && podeLamp(col+1,lin,brd)) n++;
	if(lin-1>0 && podeLamp(col,lin-1,brd)) n++;
	if(lin+1<=brd->linha && podeLamp(col,lin+1,brd)) n++;
	
	return n;	
}

BOARD *insLamp(int col, int lin, BOARD *brd)
/** Insere lâmpadas á volta da coordenada recebida, caso as possa colocar. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{		
	if(podeLamp(col-1,lin,brd))	colocaLamp(col-1,lin,brd);			
	if(podeLamp(col+1,lin,brd))	colocaLamp(col+1,lin,brd);
	if(podeLamp(col,lin-1,brd))	colocaLamp(col,lin-1,brd);			
	if(podeLamp(col,lin+1,brd))	colocaLamp(col,lin+1,brd);			

	return brd;		
}

int podeLamp(int col, int lin, BOARD *brd)
/** Verifica se pode colocar uma lâmpada na coordenada recebida. \n
 Como podemos remover uma lâmpada, a função retorna 1 (True), se a casa tiver uma lâmpada.  
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(estaDentro(col,lin,brd))
	{
		if(isLAMP(col,lin,brd) || isFREE(col,lin,brd)) return 1;
	}	
	return 0;
}

BOARD *colocaLamp(int col, int lin, BOARD *brd)
/** Coloca a lâmpada na coordenada recebida.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{	
	if(estaDentro(col,lin,brd))				
	{
		if(podeLamp(col,lin,brd) || isNOLAMP(col,lin,brd))
		{	
			if(isFREE(col,lin,brd) || isNOLAMP(col,lin,brd)) 
			{
				brd->letter[col-1][lin-1]='@'; 
				brd->state[col-1][lin-1]=LAMP;
			}
		} else {mensagem_de_erro(E_BLOC);}
	} else {mensagem_de_erro(E_COORDS);}
	
	return brd;	
}

/*---------------------MARCAR--------------------*/
BOARD *cmd_mc(char *args, BOARD *brd)
/** Implementação do comando mc, que marca uma casa, indicando que não pode conter uma lâmpada.\n
 Esta função apenas lê os argumentos e invoca a função \a marca que vai pôr a marca na casa.
 * \param *args - Argumentos do comando
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	if(brd->coluna!=-1 && brd->linha!=-1) 
	{
		if(sscanf(args,"%d %d",&col,&lin)==2)
		{	
			brd=marca(col,lin,brd);
		} else {mensagem_de_erro(E_ARGS);}		
	} else {mensagem_de_erro(E_NO_BOARD);}
	
	return brd;
}

BOARD *marca(int col, int lin, BOARD *brd) 
/** Marca a casa da coordenada recebida, indicando que não pode conter uma lâmpada.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(estaDentro(col,lin,brd))				
	{
		if(isFREE(col,lin,brd))
		{	
			brd->letter[col-1][lin-1]='.'; 
			brd->state[col-1][lin-1]=NOLAMP;
		}
	} else {mensagem_de_erro(E_COORDS);}
	
	return brd;	
}

		/*---------------------ESTRATÉGIA 2--------------------*/
BOARD *cmd_est2(char *args, BOARD *brd)
/** Implementação da estratégia 2. 
 * \param *args - Argumentos a receber
 * \param *brd - Tabuleiro */
{
	int col,lin;
	
	args=NULL;	/* 'Set' e 'Use' de *args*/
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{			
			for(lin=0; lin< brd->linha; lin++)
				for(col=0; col< brd->coluna; col++)
					if(isLAMP(col+1,lin+1,brd)) 				
						brd=ilum(col+1,lin+1,brd);
		} else {mensagem_de_erro(E_NO_BOARD);} 
	}
	return brd;	
}
	
BOARD *ilum(int col, int lin, BOARD* brd)
/** Função que recebe uma coordenada, e "ilumina" as casas na mesma linha e coluna dessa casa de acordo com a estratégia 2.\n
 Por "ilumina" entenda-se marca as casas, indicando que não podem conter lâmpadas.
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int i,j;
	
	for(j=lin-1; j>0 && (isFREE(col,j,brd) || isNOLAMP(col,j,brd)); j--) marca(col,j,brd);
	for(j=lin+1; j<=brd->linha && (isFREE(col,j,brd) || isNOLAMP(col,j,brd)); j++) marca(col,j,brd);
	for(i=col-1; i>0 && (isFREE(i,lin,brd) || isNOLAMP(i,lin,brd)); i--) marca(i,lin,brd);
	for(i=col+1; i<=brd->coluna && (isFREE(i,lin,brd) || isNOLAMP(i,lin,brd)); i++) marca(i,lin,brd);
	
	return brd;
}

		/*---------------------ESTRATÉGIA 3--------------------*/
/** Implementação da estratégia 3.
 * \param *args - Argumentos a receber
 * \param *brd - Tabuleiro */
BOARD *cmd_est3(char *args, BOARD *brd)
{
	int col,lin,l;
	
	args=NULL; /* 'Set' e 'Use' de *args*/
	if(args==NULL)
	{
		if(brd->coluna!=-1 && brd->linha!=-1) 
		{
			for(lin=0; lin< brd->linha; lin++)
				for(col=0; col< brd->coluna; col++)
				{
					if(brd->letter[col][lin]=='0') brd=noLamps(col+1,lin+1,brd);
					if(isNUM(col+1,lin+1,brd) && brd->letter[col][lin]!='0') 
					{
						l=(brd->letter[col][lin])-'0';
						if(offCasas(col+1,lin+1,brd)>0 && l==offCasas(col+1,lin+1,brd))
							brd=noLamps(col+1,lin+1,brd);
					}		
				}
		} else {mensagem_de_erro(E_NO_BOARD);}
	}
	return brd;	
}

int offCasas(int col,int lin, BOARD *brd)
/** Retorna o número de casas à volta da coordenada recebida que já têm uma lâmpada. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	int n=0;
	
	if(col-1>0 && isLAMP(col-1,lin,brd)) n++;
	if(col+1<=brd->coluna && isLAMP(col+1,lin,brd)) n++;
	if(lin-1>0 && isLAMP(col,lin-1,brd)) n++;
	if(lin+1<=brd->linha && isLAMP(col,lin+1,brd)) n++;
	
	return n;
}

BOARD *noLamps(int col, int lin, BOARD *brd)
/** Marca as casas á volta da coordenada recebida, indicando que não podem ter lâmpadas. 
 * \param col - Coluna
 * \param lin - Linha
 * \param *brd - Tabuleiro */
{
	if(podeLamp(col-1,lin,brd))	marca(col-1,lin,brd);			
	if(podeLamp(col+1,lin,brd))	marca(col+1,lin,brd);
	if(podeLamp(col,lin-1,brd))	marca(col,lin-1,brd);			
	if(podeLamp(col,lin+1,brd))	marca(col,lin+1,brd);			
	
	return brd;	
}