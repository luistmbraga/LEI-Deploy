package main.data;

public class DocenteDAO {
}