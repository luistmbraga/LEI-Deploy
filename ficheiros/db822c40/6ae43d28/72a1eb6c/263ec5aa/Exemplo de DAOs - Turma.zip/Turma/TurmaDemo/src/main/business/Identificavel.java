package main.business;

public interface Identificavel {

	public String getId();
}