package main.business;

import java.util.Vector;
import main.business.Turma;

public class UnidadeCurricular {
	private String _descr;
	private int _ects;
	public Vector<Turma> _turmas = new Vector<Turma>();
}