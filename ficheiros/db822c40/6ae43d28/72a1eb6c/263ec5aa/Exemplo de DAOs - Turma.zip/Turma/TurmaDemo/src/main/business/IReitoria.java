package main.business;

public class IReitoria {
}