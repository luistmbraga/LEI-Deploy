package main.business;

import java.util.Date;

public class Falta {
	private Date _data;
}