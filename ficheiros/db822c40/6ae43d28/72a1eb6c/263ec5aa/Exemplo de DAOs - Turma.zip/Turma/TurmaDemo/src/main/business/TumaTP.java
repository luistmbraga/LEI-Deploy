package main.business;

public class TumaTP extends Turma {

    public TumaTP(String _descr) {
        super(_descr);
    }
    
}