package main.business;

import java.util.Date;

public class RegistoCurricular {
	private Date _data;
	public Aluno _aluno;
}