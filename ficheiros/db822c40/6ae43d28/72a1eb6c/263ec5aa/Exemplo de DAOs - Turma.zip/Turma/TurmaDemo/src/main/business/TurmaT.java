package main.business;

public class TurmaT extends Turma {

    public TurmaT(String _descr) {
        super(_descr);
    }
    
    
}