package main.business;

public class Avaliacao {
	private double _valor;
}