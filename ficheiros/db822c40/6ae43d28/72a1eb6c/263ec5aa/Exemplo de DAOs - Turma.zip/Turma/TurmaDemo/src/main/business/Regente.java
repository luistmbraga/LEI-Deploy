package main.business;

public class Regente extends Docente {
	public IReitoria _reitoria;
	public IServicosAcademicos _academicos;
	public IDirectorCurso _direccao;
}