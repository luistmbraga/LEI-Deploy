package main.data;

public class RegistosDAO {
}