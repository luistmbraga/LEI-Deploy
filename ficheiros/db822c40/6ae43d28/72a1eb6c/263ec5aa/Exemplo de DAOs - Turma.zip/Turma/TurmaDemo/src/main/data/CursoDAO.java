package main.data;

import main.business.Curso;

public class CursoDAO {
	public Curso _unnamed_Curso_;
}