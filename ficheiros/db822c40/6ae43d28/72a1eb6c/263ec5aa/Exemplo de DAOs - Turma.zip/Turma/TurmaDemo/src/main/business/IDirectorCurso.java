package main.business;

public class IDirectorCurso {
}