package main.business;

import java.util.Vector;
import main.business.UnidadeCurricular;

public class Curso {
	private String _nome;
	public Vector<UnidadeCurricular> _ucs = new Vector<UnidadeCurricular>();
}