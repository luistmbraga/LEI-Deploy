#ifndef __CONVOLVE
#define __CONVOLVE

void convolve2D (int *h, int *I, int W, int H, int *f, int U);

#endif
