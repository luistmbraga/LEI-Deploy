#ifndef PAPI_INST_H_
#define PAPI_INST_H_

#include <papi.h>

void startPAPI();
void stopPAPI();


#endif