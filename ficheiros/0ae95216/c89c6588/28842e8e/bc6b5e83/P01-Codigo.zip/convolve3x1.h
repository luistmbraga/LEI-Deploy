
void convolve3x1 (int h[], int I[], int W, int H);
