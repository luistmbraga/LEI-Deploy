#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "papi_inst.h"

#include "convolve.h"
#include "convolve3x1.h"
#include "ppm.h"
#include "gauss.h"

static int verify_command_line (int argc, char *argv[], char *infile, char *outfile, int *fcode, int *f_width);
static int read_inp_image (char *infile, image *img);
static int write_out_image (char *outfile, image res_img);
static void print_usage (char *msg);




int main (int argc, char *argv[]) {
  image img, res_img, filter;
  int f_width, i, fcode;
  char infile[256], outfile[256];

  if (!verify_command_line (argc, argv, infile, outfile, &fcode, &f_width)) {
	return 0;
  }

  // Read input file
  if (!read_inp_image (infile, &img)) return 0;

  // create output image
  res_img = new_img (img->width, img->height, BW);
  if (!res_img) {
	fprintf (stderr, "Error creating result image\n");
	return 0;
  } 

  // compute the filter for the desired width
  if (fcode==0)  {  // used only with convolve2D
    filter = new_img(f_width, f_width, BW);
    if (!filter) {
	fprintf (stderr, "Error creating filter\n");
	return 0;
    }
    if (!gauss(filter->buf, f_width)) return 0;
    //print_gauss (filter->buf, f_width);
  }

  // Initialize Papi and its events
	startPAPI();
     switch (fcode) {
       case 0:     // convolve2D
	  convolve2D(res_img->buf, img->buf, img->width, img->height, filter->buf, f_width);
	  break;
       case 1:
	  convolve3x1 (res_img->buf, img->buf, img->width, img->height);
	  break;
       default:
	    print_usage ((char *)"Unknown function code!");
	    return 0;
	    break;
     }	 
	stopPAPI();


  if (!write_out_image (outfile, res_img)) return 0;

  free_img (filter); 
  free_img (img);
  free_img (res_img); 

  printf ("\nThat's all, folks\n");
}

static int verify_command_line (int argc, char *argv[], char *infile, char *outfile, int *fcode, int *f_width) {
	if (argc<4) {
		print_usage ((char *)"At least 3 arguments are required!");
		return 0;
	}
	strcpy (infile, argv[1]);
	strcpy (outfile, argv[2]);
	*fcode = atoi (argv[3]);
	switch (*fcode) {
	  case 0:
	    if (argc<5) {
		print_usage ((char *)"convolve2D requires the filter_width parameter!");
		return 0;
	    }
	    *f_width = atoi (argv[4]);
	    if (*(f_width)%2==0) {
		print_usage ((char *)"Filter width must be an odd number!");
		return 0;
	    }
	    break;
	  case 1:
	    break;
	  default:
	    print_usage ((char *)"Unknown function code!");
	    return 0;
	    break;
	}
	return 1;
}

static void print_usage (char *msg) {
	fprintf (stderr, "Command Line Error! %s\n", msg);
	fprintf (stderr, "Usage:\tconvolve2D <input filename> <output filename> <function code> [Specific Parameters] <filter_width>\n\n");
	fprintf (stderr, "\t<function code> = 0 : convolve2D [Specific Parameters] = <filter_width>\n");
	fprintf (stderr, "\t<function code> = 1 : convolve3x1 [Specific Parameters] = NULL\n");
	fprintf (stderr, "\n");
}

static int read_inp_image (char *infile, image *img) {
	FILE *f;
	
	// open input file
	// NOTE: it must be open as binary, otherwise reading might stop at \0 chars
	f = fopen (infile, "rb");
	if (!f) {
		fprintf (stderr, "Error opening input file: %s\n", infile);
		return 0;
	}

	// read file
	*img = read_ppm(f);
	if (!(*img)) {
		fclose (f);
		fprintf (stderr, "Error reading image file:%s\n", infile);
		return 0;
	}
	fclose (f);
	return 1;
}

static int write_out_image (char *outfile, image res_img) {
	FILE *f;
	
	// open output file
	// NOTE: it must be open as binary, otherwise errors arise with the CR+LF and the LF convention of Win/Unix
	f = fopen (outfile, "wb");
	if (!f) {
		fprintf (stderr, "Error opening output file: %s\n", outfile);
		return 0;
	}
	output_ppm(f, res_img);
	fclose (f);
}
