#include <stdio.h>

void convolve2D (int *h, int *I, int W, int H, int *f, int U) {
	int x, y, i, j;
	int halfU;
	int sumW;

	halfU = U/2;
	for (x=0 ; x<W ; x++) { // for each column of I
		for (y=0 ; y<H ; y++) { // for each row of I

			// compute h[y][x]
			sumW = h[y*W+x] = 0;
			for (i=-halfU ; i<=halfU ; i++) {
				// verify I horizontal bounds
				if (x+i<0 || x+i>=W) continue;

				for (j=-halfU ; j<=halfU ; j++) {
					// verify I vertical bounds
					if (y+j<0 || y+j>=H) continue;

					h[y*W+x] += (f[(j+halfU)*U+i+halfU] * I[(y+j)*W + (x+i)]);
					sumW += f[(j+halfU)*U+i+halfU];
				}
			}
			h[y*W+x] /= (sumW ? sumW : 1);
		} // y loop
	} // x loop
}