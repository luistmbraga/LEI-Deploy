#ifndef __GAUSS
#define __GAUSS

int gauss (int *f, int U);
void print_gauss (int *f, int U);

#endif