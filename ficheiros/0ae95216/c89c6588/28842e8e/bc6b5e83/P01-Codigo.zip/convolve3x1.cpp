static void kernel (int res[], int inp[], int ndx) {
  res[ndx] = (inp[ndx-1] + inp[ndx] + inp[ndx+1])/3;
}

void convolve3x1 (int h[], int I[], int W, int H) {
	register int x, y;

	for (x=1 ; x<(W-1) ; x++) { // for each column of I
		for (y=0 ; y<H ; y++) { // for each row of I

			kernel (h, I, y*W+x);

		} // y loop
	} // x loop
}
