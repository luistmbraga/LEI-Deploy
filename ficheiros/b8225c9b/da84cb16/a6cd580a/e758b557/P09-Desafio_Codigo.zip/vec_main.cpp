#include <stdio.h>
#include <math.h>

#include "papi_inst.h"

#define REPEATS 10

#define SIZE 1000000

typedef struct {float a, c} MY_DATA;

MY_DATA d[SIZE] __attribute__ ((aligned(16)));

void loop () {
  int i;
 
 for (i=1 ; i<SIZE; i++) {
    d[i].c = powf(d[i-1].a, 3.f) + 10.0f/d[i-1].a + 100.f/(d[i-1].a*d[i-1].a) + d[i-1].c;
  }
}


main () {
  long long start_usec, end_usec;
  long long inst, cyc;
  float f;

  // Initialize Papi and its events

  for (int n=0 , f=1.0; n<SIZE ;  n++ , f=f+1.0f) d[n].a = f;

  // use PAPI  (usecs + cyc)
  startPAPI();
  start_usec = PAPI_get_real_usec();

  for (int n=0 ; n<REPEATS ; n++) {
    loop ();
  }

  end_usec = PAPI_get_real_usec();
  stopPAPI(&inst, &cyc);

  printf ("CPI= %.2f\t (#cc= %lld /#I= %lld)\tTexec: %lld usecs\t\n", ((float)cyc)/((float)inst), cyc/REPEATS, inst/REPEATS, (end_usec - start_usec)/REPEATS);

}


