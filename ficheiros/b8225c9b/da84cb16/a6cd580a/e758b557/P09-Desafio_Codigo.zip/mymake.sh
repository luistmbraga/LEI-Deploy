
make -f MakefileO3 clean


make -f MakefileO3

